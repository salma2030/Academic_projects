
package royal.hotel;

import javax.swing.JFrame;


public class RoyalHotel {

   
    public static void main(String[] args) {
       interfaceFrame frm=new interfaceFrame();
        frm.setVisible(true);
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frm.setSize(2090,1000);
        frm.setLocationRelativeTo(null);
    }
    
}
