/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package royal.hotel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Admin_activities extends JFrame implements ActionListener{
    
  
  JButton button_Radd1 =new JButton ("ADD Room");
 // JButton button_Rdelete1 =new JButton ("Delete Room");
  JButton button_Rupdate1=new JButton ("Update Room");
  JButton button_exit1=new JButton ("Exit");
  
  JButton button_view_room =new JButton ("View all Rooms");
 // JButton button_view_employees =new JButton ("View all Employee");
  JButton button_view_reservations=new JButton ("view all Reservation");
  
 
 JPanel BasePanel=new JPanel(); 
 
 JPanel fristPanel=new JPanel(); 
 JPanel secondPanel=new JPanel();  
  public  Admin_activities (){
 
    BasePanel.setLayout(new BoxLayout(BasePanel,BoxLayout.Y_AXIS));
   fristPanel.setLayout(new GridLayout(2,2,5,5));
   fristPanel.setBorder(new EmptyBorder(100,200,100,200));
 
   fristPanel.setBackground(new Color(184,223,255));//255,192,219)>>pink (184,223,255)>>blue
  
   secondPanel.setBackground(new Color(184,223,255));
   
   BasePanel.setBackground(new Color(184,223,255));
 
   button_Radd1.setFont(new Font("DialogInput",Font.BOLD,40));
   button_Radd1.add(Box.createRigidArea(new Dimension(400,80)));
  
   button_Rupdate1.setFont(new Font("DialogInput",Font.BOLD,40));
   button_Rupdate1.add(Box.createRigidArea(new Dimension(400,80)));
   
   button_view_room.setFont(new Font("DialogInput",Font.BOLD,40));
   button_view_room.add(Box.createRigidArea(new Dimension(400,80)));
   
  
   button_view_reservations.setFont(new Font("DialogInput",Font.BOLD,40));
   button_view_reservations.add(Box.createRigidArea(new Dimension(400,80)));
   
   button_exit1.setFont(new Font("DialogInput",Font.BOLD,40));
   button_exit1.add(Box.createRigidArea(new Dimension(400,80)));
   
   
   
 
   fristPanel.add(button_Radd1);
   fristPanel.add(button_Rupdate1);
   
   
   fristPanel.add(button_view_room);
   fristPanel.add(button_view_reservations);
   secondPanel.add(button_exit1);
   BasePanel.add(fristPanel);
   BasePanel.add(Box.createVerticalStrut(20));
   BasePanel.add(secondPanel);
   
   
      add(BasePanel); 
      
    
      button_Radd1.addActionListener(this);
      button_Rupdate1.addActionListener(this);
      
      
      button_view_room.addActionListener(this);
      button_view_reservations.addActionListener(this);
      
      
      button_exit1.addActionListener(this);
       
  } 

    @Override
    public void actionPerformed(ActionEvent e) {
        
         
         if (e.getSource()==button_Radd1){
            Room_add room_add =new Room_add();
            room_add.setVisible(true);
            room_add.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            room_add.setSize(1800,1300);
            room_add.setLocationRelativeTo(null);
            
            
        }
         
        
         
         if (e.getSource()==button_Rupdate1){
            Room_update updateR =new Room_update();
            
            updateR.setVisible(true);
            updateR.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            updateR.setSize(1800,1300);
            updateR.setLocationRelativeTo(null);
            this.setVisible(false);  
        } 
         
         if (e.getSource()==button_view_room){
             
            View_all_hotalroom view_room =new View_all_hotalroom();
            view_room.setVisible(true);
            view_room.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            view_room.setSize(1800,1300);
            view_room.setLocationRelativeTo(null);
            this.setVisible(false); 
          
            
        }
      
          if (e.getSource()==button_view_reservations){
              
            View_all_reservation view_r =new View_all_reservation();
            view_r.setVisible(true);
            view_r.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            view_r.setSize(1800,1300);
            view_r.setLocationRelativeTo(null);
            this.setVisible(false); 
            
        }
         
         
         if (e.getSource()==button_exit1){
            
          this.setVisible(false);   
        } 
      
    }
    
}
