package royal.hotel;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

public class Bill_afterBook extends JFrame implements ActionListener{
    
   JPanel BasePanel=new JPanel();
 JPanel upPanel=new JPanel();
  JPanel fristPanel=new JPanel();
  
  JLabel  label = new JLabel(" Bill Information");
  
  
 JPanel secondPanel=new JPanel();   
 JTextArea report=new JTextArea(13,30);//10,30
 JScrollPane scroll =new JScrollPane( report,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
 JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
 Connection connect;
 double Price=000.00;
 int flag=0;
 
 
 
 
 
 JButton button_ok=new JButton ("Ok");
 Font font=new Font("DialogInput",1+2,40);
 int Cid;
   String check="not working";
  public  Bill_afterBook(){
      
  label.setFont(new Font("DialogInput",1+2,60));
  
  upPanel.add(label);
  
  
    BasePanel.setLayout(new BoxLayout(BasePanel,BoxLayout.Y_AXIS));
      BasePanel.setBackground(new Color(255,192,219));
      fristPanel.setBackground(new Color(255,192,219));
       
      secondPanel.setBackground(new Color(255,192,219));
      
      
      BasePanel.add(fristPanel);
      BasePanel.add(secondPanel);
      secondPanel.add(button_ok);
 
  
  
  
  secondPanel.setBackground(new Color(255,192,219));
  upPanel.setBackground(new Color(255,192,219));
  
  report.setFont(font);
 
  fristPanel.add(scroll);
  
    button_ok.add(Box.createRigidArea(new Dimension(400,80)));
    button_ok.setFont(new Font("DialogInput",Font.BOLD,40)); 
    
  
  secondPanel.add(button_ok);
    
  BasePanel.add(label);
  BasePanel.add(Box.createVerticalStrut(20));
  BasePanel.add(fristPanel);
  BasePanel.add(Box.createVerticalStrut(20));
  BasePanel.add(secondPanel);
  this.add(BasePanel);
  
  //Print bill
  
  report.setText("                  Royal Hotel        \n");
  report.setText(report.getText()+"            ******************************\n\n");
  
  try{ 

                String url="jdbc:mysql://localhost:3306/hms?useSSL=true";
                String username="root";
                String password="1234";

                connect=DriverManager.getConnection(url, username, password);
                System.out.print("Connected successfully\n");


                
                String sql_1=String.format("SELECT customer_id from customer where f_name='%s' and national_id=%d",Customer.userName,Customer.Password);
                Statement statement1=connect.createStatement();
                ResultSet rs=statement1.executeQuery(sql_1);
                
                if(rs.next()){
                    check="Perfect\n";
                    Cid=Integer.parseInt(rs.getObject(1).toString());
                
                }
                
                System.out.print(check);
       
                
                String sql_2=String.format("SELECT F_name, L_name, numofnight, check_in, check_out,price from customer JOIN reservation ON customer.customer_id=reservation.customer_id JOIN room ON reservation.room_id=room.room_num\n "+
                            "where customer.customer_id=%d\n" ,Cid);
                Statement statement2=connect.createStatement();
                ResultSet rs2=statement2.executeQuery(sql_2); 


                //print columns name
                
                report.setText(report.getText()+"Customer name");
                report.setText(report.getText()+ "            number of nights");
                report.setText(report.getText()+ "         check in ");
                report.setText(report.getText()+ "         check out "); 
                report.setText(report.getText()+ "         price\n\n ");


                  while(rs2.next())
                   {

                        
                        //customer first name
                        report.setText(report.getText()+" "+ rs2.getObject(1)+" ");
                        //customer last name
                        report.setText(report.getText()+rs2.getObject(2)+"   ");
                        //number of nights
                        report.setText(report.getText()+ "           "+rs2.getObject(3)+"    ");
                        //check in
                        report.setText(report.getText()+"                 "+rs2.getObject(4).toString().substring(0, 10)+"    ");
                        //check out
                        report.setText(report.getText()+"      "+rs2.getObject(5).toString().substring(0, 10)+"     ");
                        //price
                        report.setText(report.getText()+"  "+rs2.getObject(6)+"\n\n");
                        Price+=Double.parseDouble(rs2.getObject(6).toString());
                        System.out.print(Price);
                  }//loop
                 
                  
                   String sql_3=String.format("SELECT meal, price from meal where customer_id=%d" , Cid);
                    Statement statement3=connect.createStatement();
                    ResultSet rs3=statement3.executeQuery(sql_3); 
                  
                   
                   if (rs3.next()){
                       report.setText(report.getText()+"   *************************  \n");
                       report.setText(report.getText()+ "  Meals included:      "); 
                       report.setText(report.getText()+rs3.getObject(1)+"\n");
                       Price+=Double.parseDouble(rs3.getObject(2).toString());
                       flag=1;
                       report.setText(report.getText()+"*** The total is "+ Price+"  ***");

                   }//if
                  

                  if(flag==0){
                     //report_AR.setText("");
                      report.setText(report.getText()+"   *************************  \n");
                     report.setText(report.getText()+ "  Meal is not included   \n"); 
                     report.setText(report.getText()+"\n"+"*** The total is "+ Price+"  ***");
                     
                     
                   }//if

                     }//try
  
                      catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }//catch
             
                button_ok.addActionListener(this);
             
         }
        //.................................................
       
             
    
   
      
  

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==button_ok){
            
            this.setVisible(false); 
            
        } 
    

    }//aactionPerformed
}//class
    
    

