/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package royal.hotel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;


public class Check_room_Availabilty extends JFrame implements ActionListener {
    
  JPanel leftPanel=new JPanel(); 
  JPanel centerPanel=new JPanel(); 
  
  JLabel  label = new JLabel("       View All Available Rooms");

  JLabel  label1 = new JLabel("Price: ");
 
  
  JRadioButton  price1=new JRadioButton("From 200SR-500SR");
  JRadioButton  price2=new JRadioButton("From 600SR-1000SR");
  JRadioButton  price3=new JRadioButton("From 1001SR-2000SR");
  ButtonGroup group =new ButtonGroup();
  
  JLabel  label2 = new JLabel("Type: ");
  JRadioButton  type1=new JRadioButton("Twin");
  JRadioButton  type2=new JRadioButton("Single");
  JRadioButton  type3=new JRadioButton("King");
  JRadioButton  type4=new JRadioButton("Meeting Room");
  JRadioButton  type5=new JRadioButton("Festival Hall"); 
  ButtonGroup group2 =new ButtonGroup();
  
  
 JTextArea report_AR=new JTextArea(13,50);//10,30
 JScrollPane scroll =new JScrollPane( report_AR,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
 JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
 Connection connect;
 int flag=0;
 
 public  Check_room_Availabilty(){
    leftPanel.setLayout(new BoxLayout(leftPanel,BoxLayout.Y_AXIS)); 
    centerPanel.setLayout(new BoxLayout(centerPanel,BoxLayout.Y_AXIS)); 
    leftPanel.setBorder(BorderFactory.createTitledBorder("Filter"));
     
     
     leftPanel.setBackground(new Color(255,192,219));
     centerPanel.setBackground(new Color(255,192,219));
     
     label.setFont(new Font("DialogInput",1+2,60));
     
     report_AR.setFont(new Font("DialogInput",1+2,40));
     centerPanel.add(label);
     centerPanel.add(scroll);
     
        
     
     label1.setFont(new Font("DialogInput",1+2,40));
     
     price1.setFont(new Font("DialogInput",1+2,30));
     price2.setFont(new Font("DialogInput",1+2,30));
     price3.setFont(new Font("DialogInput",1+2,30));
    
     //color
     price1.setBackground(new Color(255,192,219));
     price2.setBackground(new Color(255,192,219));
     price3.setBackground(new Color(255,192,219));
     
     
    leftPanel.add(Box.createVerticalStrut(80));
    leftPanel.add(label1);
    leftPanel.add(price1);
    leftPanel.add(price2);
    leftPanel.add(price3);
    
    
    group.add( price1);
    group.add( price2);
    group.add( price3);
    /*group.add( type1);
    group.add( type2);
    group.add( type3);
    group.add( type4);
    group.add( type5);*/
    
    
    label2.setFont(new Font("DialogInput",1+2,40));
     type1.setFont(new Font("DialogInput",1+2,30));
     type2.setFont(new Font("DialogInput",1+2,30));
     type3.setFont(new Font("DialogInput",1+2,30));
     type4.setFont(new Font("DialogInput",1+2,30));
     type5.setFont(new Font("DialogInput",1+2,30));
     
     //color
     type1.setBackground(new Color(255,192,219));
     type2.setBackground(new Color(255,192,219));
     type3.setBackground(new Color(255,192,219));
     type4.setBackground(new Color(255,192,219));
     type5.setBackground(new Color(255,192,219));
     
     
    leftPanel.add(Box.createVerticalStrut(50));
    leftPanel.add(label2);
    leftPanel.add(type1);
    leftPanel.add(type2);
    leftPanel.add(type3);
    leftPanel.add(type4);
    leftPanel.add(type5);
    
    group2.add( type1);
    group2.add( type2);
    group2.add( type3);
    group2.add( type4);
    group2.add( type5);
    
    
    
    this.add(leftPanel, BorderLayout.WEST);
    this.add(centerPanel, BorderLayout.CENTER);
    
    //connection
    try{
        
        
        
        String url="jdbc:mysql://localhost:3306/hms?useSSL=true";
        String username="root";
        String password="1234";
 
        connect=DriverManager.getConnection(url, username, password);
        System.out.print("Connected successfully\n");
       
        
        String sql="select room_num,room_type,floor_num,price from room where state='Available'";
        Statement statement=connect.createStatement();
        ResultSet rs=statement.executeQuery(sql); 
        
        

        if(rs.next()){
            //print columns name
        report_AR.setText("Room number ");
        report_AR.setText(report_AR.getText()+ "   Room type  ");
        report_AR.setText(report_AR.getText()+ "    Floor number  ");
        report_AR.setText(report_AR.getText()+ "      price\n\n ");
        
        
          while(rs.next())
           {
               flag+=1;
             
                report_AR.setText(report_AR.getText()+""+ rs.getObject(1));
                //room type
                report_AR.setText(report_AR.getText()+"             "+ rs.getObject(2)+"   ");
                //floor number
                report_AR.setText(report_AR.getText()+ "          "+rs.getObject(3));
                //price 
                report_AR.setText(report_AR.getText()+"               "+rs.getObject(4)+"\n\n");
                
          }//loop
       }//if
        
          if(flag==0){
             report_AR.setText(" **** No available rooms **** ");
           }
             
             
    }//try
              catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }//catch
    
    price1.addActionListener(this);
    price2.addActionListener(this);
    price3.addActionListener(this);
    
    
    type1.addActionListener(this);
    type2.addActionListener(this);
    type3.addActionListener(this);
    type4.addActionListener(this);
    type5.addActionListener(this);
             
 }
 
 
 
 
    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(  e.getSource()==price1 && price1.isSelected()){
            
            //connection
            try{

                String url="jdbc:mysql://localhost:3306/hms?useSSL=true";
                String username="root";
                String password="1234";

                connect=DriverManager.getConnection(url, username, password);
                System.out.print("Connected successfully\n");


                String sql="select room_num,room_type,floor_num,price from room where state='Available' and price between 200 and 500";
                Statement statement=connect.createStatement();
                ResultSet rs=statement.executeQuery(sql); 
                
                //print columns name
                
                
                report_AR.setText( " Room number ");
                report_AR.setText(report_AR.getText()+ "   Room type  ");
                report_AR.setText(report_AR.getText()+ "     Floor number  ");
                report_AR.setText(report_AR.getText()+ "      price\n\n ");
                
                
                  while(rs.next())
                   {
                        
                        flag+=1;
                       //room number
                        report_AR.setText(report_AR.getText()+" "+ rs.getObject(1));
                        //room type
                        report_AR.setText(report_AR.getText()+"              "+ rs.getObject(2)+"   ");
                        //floor number
                        report_AR.setText(report_AR.getText()+ "           "+rs.getObject(3));
                        //price
                        report_AR.setText(report_AR.getText()+"              "+rs.getObject(4)+"\n\n");

                  }//loop
                  
                  
                  if(flag==0){
                    // report_AR.setText("");
                     report_AR.setText("**** No available rooms ****");
                   }

                     }//try
                      catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }//catch

         }
      //................................................. 
        if( e.getSource()== price2 &&price2.isSelected()){
            try{

                String url="jdbc:mysql://localhost:3306/hms?useSSL=true";
                String username="root";
                String password="1234";

                connect=DriverManager.getConnection(url, username, password);
                System.out.print("Connected successfully\n");


                String sql="select room_num,room_type,floor_num,price from room where state='Available' and price between 600 and 1000";
                Statement statement=connect.createStatement();
                ResultSet rs=statement.executeQuery(sql); 
                
                report_AR.setText( " Room number ");
                report_AR.setText(report_AR.getText()+ "   Room type  ");
                report_AR.setText(report_AR.getText()+ "     Floor number  ");
                report_AR.setText(report_AR.getText()+ "      price\n\n ");


                  while(rs.next())
                   {
                   

                        flag+=1;
                        //room number
                        report_AR.setText(report_AR.getText()+" "+ rs.getObject(1));
                        //room type
                        report_AR.setText(report_AR.getText()+"             "+ rs.getObject(2)+"   ");
                        //floor number
                        report_AR.setText(report_AR.getText()+ "              "+rs.getObject(3));
                        //price
                        report_AR.setText(report_AR.getText()+"              "+rs.getObject(4)+"\n\n");

                  }//loop

                  if(flag==0){
                     
                     report_AR.setText("**** No available rooms **** ");
                   }

                     }//try
                      catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }//catch
            
             
         }
        //...............................................
        if( e.getSource()== price3 && price3.isSelected()){
            
            try{

                String url="jdbc:mysql://localhost:3306/hms?useSSL=true";
                String username="root";
                String password="1234";

                connect=DriverManager.getConnection(url, username, password);
                System.out.print("Connected successfully\n");


                String sql="select room_num,room_type,floor_num,price from room where state='Available' and price between 1001 and 2000";
                Statement statement=connect.createStatement();
                ResultSet rs=statement.executeQuery(sql); 


                //print columns name
                //report_AR.setText("");
                report_AR.setText( " Room number ");
                report_AR.setText(report_AR.getText()+ "   Room type  ");
                report_AR.setText(report_AR.getText()+ "     Floor number  ");
                report_AR.setText(report_AR.getText()+ "      price\n\n ");


                  while(rs.next())
                   {

                        flag+=1;
                        //room number
                        report_AR.setText(report_AR.getText()+" "+ rs.getObject(1));
                        //room type
                        report_AR.setText(report_AR.getText()+"            "+ rs.getObject(2)+"   ");
                        //floor number
                        report_AR.setText(report_AR.getText()+ "        "+rs.getObject(3));
                        //price
                        report_AR.setText(report_AR.getText()+"           "+rs.getObject(4)+"\n\n");

                  }//loop

                  if(flag==0){
                    
                     report_AR.setText(" **** No available rooms **** ");
                   }

                     }//try
                      catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }//catch
             
         }
        //.................................................
        if(e.getSource()== type1 && type1 .isSelected()){
            
              
            
            try{

                String url="jdbc:mysql://localhost:3306/hms?useSSL=true";
                String username="root";
                String password="1234";

                connect=DriverManager.getConnection(url, username, password);
                System.out.print("Connected successfully\n");


                String sql="select room_num,room_type,floor_num,price from room where state='Available' and room_type='twin'";
                Statement statement=connect.createStatement();
                ResultSet rs=statement.executeQuery(sql); 


                //print columns name
               
                report_AR.setText( " Room number ");
                report_AR.setText(report_AR.getText()+ "   Room type  ");
                report_AR.setText(report_AR.getText()+ "     Floor number  ");
                report_AR.setText(report_AR.getText()+ "      price\n\n ");


                  while(rs.next())
                   {

                        flag+=1;
                        //room number
                        report_AR.setText(report_AR.getText()+" "+ rs.getObject(1));
                        //room type
                        report_AR.setText(report_AR.getText()+"             "+ rs.getObject(2)+"   ");
                        //floor number
                        report_AR.setText(report_AR.getText()+ "            "+rs.getObject(3));
                        //price
                        report_AR.setText(report_AR.getText()+"               "+rs.getObject(4)+"\n\n");

                  }//loop

                  if(flag==0){
                     
                     report_AR.setText(" **** No available rooms **** ");
                   }

                     }//try
                      catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }//catch
             
            
             
         }
        if(e.getSource()==type2 && type2 .isSelected()){
            try{

                String url="jdbc:mysql://localhost:3306/hms?useSSL=true";
                String username="root";
                String password="1234";

                connect=DriverManager.getConnection(url, username, password);
                System.out.print("Connected successfully\n");


                String sql="select room_num,room_type,floor_num,price from room where state='Available' and room_type='single'";
                Statement statement=connect.createStatement();
                ResultSet rs=statement.executeQuery(sql); 


                //print columns name
                //report_AR.setText("");
                report_AR.setText( " Room number ");
                report_AR.setText(report_AR.getText()+ "   Room type  ");
                report_AR.setText(report_AR.getText()+ "     Floor number  ");
                report_AR.setText(report_AR.getText()+ "      price\n\n ");


                  while(rs.next())
                   {

                        flag+=1;
                        //room number
                        report_AR.setText(report_AR.getText()+" "+ rs.getObject(1));
                        //room type
                        report_AR.setText(report_AR.getText()+"             "+ rs.getObject(2)+"   ");
                        //floor number
                        report_AR.setText(report_AR.getText()+ "           "+rs.getObject(3));
                        //price
                        report_AR.setText(report_AR.getText()+"               "+rs.getObject(4)+"\n\n");

                  }//loop

                  if(flag==0){
                     report_AR.setText(" **** No available rooms **** ");
                   }

                     }//try
                      catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }//catch
             
             
         }
        //.................................................
        if(e.getSource()==type3 && type3 .isSelected()){
            try{

                String url="jdbc:mysql://localhost:3306/hms?useSSL=true";
                String username="root";
                String password="1234";

                connect=DriverManager.getConnection(url, username, password);
                System.out.print("Connected successfully\n");


                String sql="select room_num,room_type,floor_num,price from room where state='Available' and room_type='king'";
                Statement statement=connect.createStatement();
                ResultSet rs=statement.executeQuery(sql); 


                //print columns name
                //report_AR.setText("");
                report_AR.setText( " Room number ");
                report_AR.setText(report_AR.getText()+ "   Room type  ");
                report_AR.setText(report_AR.getText()+ "     Floor number  ");
                report_AR.setText(report_AR.getText()+ "      price\n\n ");


                  while(rs.next())
                   {

                        flag+=1;
                        //room number
                        report_AR.setText(report_AR.getText()+" "+ rs.getObject(1));
                        //room type
                        report_AR.setText(report_AR.getText()+"             "+ rs.getObject(2)+"   ");
                        //floor number
                        report_AR.setText(report_AR.getText()+ "             "+rs.getObject(3));
                        //price
                        report_AR.setText(report_AR.getText()+"               "+rs.getObject(4)+"\n\n");

                  }//loop

                  if(flag==0){
                     //report_AR.setText("");
                     report_AR.setText(" **** No available rooms **** ");
                   }

                     }//try
                      catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }//catch
             
             
         }
        //.................................................
        if(e.getSource()==type4 && type4.isSelected()){
            try{

                String url="jdbc:mysql://localhost:3306/hms?useSSL=true";
                String username="root";
                String password="1234";

                connect=DriverManager.getConnection(url, username, password);
                System.out.print("Connected successfully\n");


                String sql="select room_num,room_type,floor_num,price from room where state='Available' and room_type='meeting'";
                Statement statement=connect.createStatement();
                ResultSet rs=statement.executeQuery(sql); 


                //print columns name
                //report_AR.setText("");
                report_AR.setText( " Room number ");
                report_AR.setText(report_AR.getText()+ "   Room type  ");
                report_AR.setText(report_AR.getText()+ "     Floor number  ");
                report_AR.setText(report_AR.getText()+ "      price\n\n ");


                  while(rs.next())
                   {

                        flag+=1;
                        //room number
                        report_AR.setText(report_AR.getText()+" "+ rs.getObject(1));
                        //room type
                        report_AR.setText(report_AR.getText()+"            "+ rs.getObject(2)+"   ");
                        //floor number
                        report_AR.setText(report_AR.getText()+ "           "+rs.getObject(3));
                        //price
                        report_AR.setText(report_AR.getText()+"            "+rs.getObject(4)+"\n\n");

                  }//loop

                  if(flag==0){
                     //report_AR.setText("");
                     report_AR.setText(" **** No available rooms **** ");
                   }

                     }//try
                      catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }//catch
             
             
         }
        //.................................................
        if(e.getSource()==type5&& type5 .isSelected()){
            
            try{

                String url="jdbc:mysql://localhost:3306/hms?useSSL=true";
                String username="root";
                String password="1234";

                connect=DriverManager.getConnection(url, username, password);
                System.out.print("Connected successfully\n");


                String sql="select room_num,room_type,floor_num,price from room where state='Available' and room_type='festival hall'";
                Statement statement=connect.createStatement();
                ResultSet rs=statement.executeQuery(sql); 


                //print columns name
                //report_AR.setText("");
                report_AR.setText( " Room number ");
                report_AR.setText(report_AR.getText()+ "   Room type  ");
                report_AR.setText(report_AR.getText()+ "     Floor number  ");
                report_AR.setText(report_AR.getText()+ "      price\n\n ");


                  while(rs.next())
                   {

                        flag+=1;
                        //room number
                        report_AR.setText(report_AR.getText()+" "+ rs.getObject(1));
                        //room type
                        report_AR.setText(report_AR.getText()+"           "+ rs.getObject(2)+"   ");
                        //floor number
                        report_AR.setText(report_AR.getText()+ "         "+rs.getObject(3));
                        //price
                        report_AR.setText(report_AR.getText()+"          "+rs.getObject(4)+"\n\n");

                  }//loop

                  if(flag==0){
                     //report_AR.setText("");
                     report_AR.setText(" **** No available rooms **** ");
                   }

                     }//try
                      catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }//catch
             
             
         }
        //.................................................
    }
        
    
    
    
    
}
