/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package royal.hotel;

import com.toedter.calendar.JDateChooser;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;



public class Customer_info extends JFrame implements ActionListener{

    
    JLocaleChooser lo =new JLocaleChooser();
     JPanel BasePanel=new JPanel();
     JPanel upPanel=new JPanel();
     JPanel fristPanel=new JPanel();
     JPanel secondPanel=new JPanel();
    
     JLabel  label = new JLabel("Customer Information");
     
     JLabel  cus_LastN = new JLabel("Last Name");
   JLabel  cus_fristN = new JLabel("Frist Name");
   
   JLabel  cus_national = new JLabel("National_ID");
   JLabel  cus_gender = new JLabel("Gender");//combo box
   JLabel  cus_BD = new JLabel("Birth Date");//jdate chooser
   JLabel  Email = new JLabel("Email");
   JLabel  phone = new JLabel("Phone");
   JLabel  address = new JLabel("Address");//jlocation
   
   JTextField txt_Lname =new JTextField(15);
   JTextField txt_Fname =new JTextField(15);
   
   JTextField txt_national =new JTextField(15);
   String gender []={"Choose Gender","Male","Female"};
   JComboBox combobox_gender =new JComboBox(gender);
   JDateChooser date =new JDateChooser();//.........jdate chooser
   JTextField txt_email =new JTextField(15);
   JTextField txt_phone =new JTextField(15);
   
   
    

   JButton button_ok=new JButton ("Ok");
   JButton button_Exit2=new JButton ("Exit");
   public Connection connect=null;
   
    
  public  Customer_info (){
      
      label.setFont(new Font("DialogInput",1+2,60));
      upPanel.add(label);
      fristPanel.setBorder(new EmptyBorder(100,300,100,300));//top left bottom right //to put empty border around centerpanelt
      BasePanel.setLayout(new BoxLayout(BasePanel,BoxLayout.Y_AXIS));
      BasePanel.setBackground(new Color(255,192,219));//255,192,219)>>pink (184,223,255)>>blue
      fristPanel.setBackground(new Color(255,192,219));
      fristPanel.setLayout(new GridLayout(8,2,5,5));
       Font font=new Font("DialogInput",1+2,40);
       cus_LastN.setFont(new Font("DialogInput",1+2,50));
       cus_fristN.setFont(new Font("DialogInput",1+2,50));
       cus_national.setFont(new Font("DialogInput",1+2,50));
       cus_gender.setFont(new Font("DialogInput",1+2,50));
       cus_BD.setFont(new Font("DialogInput",1+2,50));
       Email.setFont(new Font("DialogInput",1+2,50));
       phone.setFont(new Font("DialogInput",1+2,50));
       address.setFont(new Font("DialogInput",1+2,50));
       
       
   //................................................. 
       fristPanel.add(cus_fristN);
       txt_Fname.setFont(font);
       fristPanel.add(txt_Fname);
       
       fristPanel.add(cus_LastN);
       txt_Lname.setFont(font);
       fristPanel.add(txt_Lname);
       
       
       
       fristPanel.add(cus_national);
      txt_national.setFont(font);
       fristPanel.add(txt_national);
       fristPanel.add(cus_gender);
       combobox_gender.setFont(font);
       fristPanel.add(combobox_gender);
       
       
       fristPanel.add(cus_BD);
       date.setFont(font);
       fristPanel.add(date);
       fristPanel.add(Email);
       txt_email.setFont(font);
       fristPanel.add(txt_email);
       
       fristPanel.add(phone);
       txt_phone.setFont(font);
       fristPanel.add(txt_phone);
       
       
       fristPanel.add( address);
       
       lo .setFont(font);
       fristPanel.add(lo );
       
       
       
       secondPanel.setLayout(new FlowLayout());
       button_ok.add(Box.createRigidArea(new Dimension(400,80)));
       button_ok.setFont(new Font("DialogInput",Font.BOLD,40));
       
       button_Exit2.add(Box.createRigidArea(new Dimension(400,80)));
       button_Exit2.setFont(new Font("DialogInput",Font.BOLD,40));
       
       secondPanel.setBackground(new Color(255,192,219));
       upPanel.setBackground(new Color(255,192,219));
       secondPanel.add(button_ok);
       secondPanel.add(button_Exit2);
               
       BasePanel.add(upPanel);
       BasePanel.add(fristPanel);
       BasePanel.add(Box.createVerticalStrut(10));
       BasePanel.add(secondPanel);
       this.add(BasePanel);
       button_ok.addActionListener(this);
       button_Exit2.addActionListener(this);
    
    
  
}//constructor

    @Override
    public void actionPerformed(ActionEvent e) {
        
       
       if (e.getSource()==button_ok){
           
           if(txt_Fname.getText().equals("")||txt_Lname.getText( ).equals("")|| txt_national.getText().equals("")
                   ||combobox_gender.getSelectedItem().equals("")||date.getDate().equals("")|| txt_email.getText().equals("")
                   ||txt_phone.getText().equals("")|| lo.getSelectedItem().equals("") ){
           
             JOptionPane.showMessageDialog(this, "You should fill the missing blanks!!!","Warning" , JOptionPane.WARNING_MESSAGE);
           
           
           }//if
           
           else{
             try{
        String url="jdbc:mysql://localhost:3306/hms?useSSL=true";
        String username="root";
        String password="1234";
 
        connect=DriverManager.getConnection(url, username, password);
        System.out.print("Connected successfully\n");
        
        
        //get customer information from text fields
        String f_name=txt_Fname.getText();
        String l_name=txt_Lname.getText();
        int id=Integer.parseInt(txt_national.getText());
        
        //get user selection(gender) from combo, then convert to string
        Object gender_combo=combobox_gender.getSelectedItem();
        String gender_string =gender_combo.toString();
        
        //get date to then convert to string
        Date BD_date=date.getDate();
        String string_date =BD_date.toString();
        
        //get user selection(gender) from combo, then convert to string
        String email= txt_email.getText();
        String phone=txt_phone.getText();
        
        //get user selection(country) from combo, then convert to string
        Object country_combo=lo.getSelectedItem();
        String country_string= country_combo.toString();
        
        System.out.print(Customer.customer_count+"\n");
        String sql=String.format("insert into customer(customer_id,F_name,L_name,National_ID,gender,B_date,Email,Phone,address)"
          + "values('%d','%s','%s','%d','%s','%s','%s','%s','%s')", Customer.customer_count,f_name,l_name,id,gender_string,string_date,email,phone,country_string);
    
        Statement statement=connect.createStatement();
        statement.executeUpdate(sql);
        JOptionPane.showMessageDialog(this, "Added successfully"," ",JOptionPane.INFORMATION_MESSAGE); 
        //customer_count=customer_count++;
       
        }//try 
        
        catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }//catch
        
         //customer_count=customer_count++;
        
            Customer ser=new Customer();
            ser.setVisible(true);
            ser.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            ser.setSize(1800,1200);
            ser.setLocationRelativeTo(null);
             
             
            
           }//else
        }//ok_button
      
         
         if (e.getSource()==button_Exit2){
           this.setVisible(false); 
            
        }
    }
}