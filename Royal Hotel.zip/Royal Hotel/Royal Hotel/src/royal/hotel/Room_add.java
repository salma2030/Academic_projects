
package royal.hotel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


public class Room_add extends JFrame implements ActionListener{
   JPanel BasePanel=new JPanel();
      JPanel upPanel=new JPanel();
     JPanel fristPanel=new JPanel();
     JPanel secondPanel=new JPanel();
     
     JLabel  label= new JLabel("ROOM DITAILES");
   JLabel  room_num = new JLabel("Room Number");
   
   
   JLabel  room_type = new JLabel("Room Type");
   JLabel  Flour_num = new JLabel("Flour Number");
   JLabel  Price= new JLabel("Price");
   JLabel  state = new JLabel("State");
   
   
   String room_t []={"Choose type","twin","single","king","meeting","festival hall"};
   JComboBox combobox_type =new JComboBox(room_t); 
  
   String flour []={"Choose Foulr","1","2","3"};
   JComboBox combobox_flour =new JComboBox(flour); 
   
   JTextField txt_numroom =new JTextField(15);
   //JTextField txt_typeroom =new JTextField(15);
   //JTextField txt_flour =new JTextField(15);
   JTextField txt_price =new JTextField(15);
   
   //JTextField txt_serch=new JTextField(15);
  
   String room_state []={"Choose State","Available","Unavailable","Under maintenance"};
   JComboBox combobox_state =new JComboBox(room_state); 
   
   JButton button_Add2=new JButton ("ADD");
   JButton button_Exit2=new JButton ("Exit");
   
   Connection connect;
   
   public Room_add(){
       
       
    BasePanel.setLayout(new BoxLayout(BasePanel,BoxLayout.Y_AXIS));
    
    upPanel.setBackground(new Color(184,223,255)); 
    
    BasePanel.setBackground(new Color(184,223,255)); 
    fristPanel.setBorder(new EmptyBorder(100,200,100,200));
    
    fristPanel.setBackground(new Color(184,223,255));
    fristPanel.setLayout(new GridLayout(5,2,5,5));
    
    Font font=new Font("DialogInput",1+2,40);
    Font font1=new Font("DialogInput",1+2,50);
    
    room_num.setFont(font1);
    room_type.setFont(font1); 
    Flour_num.setFont(font1);
    Price.setFont(font1);
    state .setFont(font1);
   
   txt_numroom.setFont(font); 
    combobox_type .setFont(font); 
    combobox_flour.setFont(font); 
    txt_price .setFont(font); 
    combobox_state.setFont(font);
  
    
    
    fristPanel.add(room_num);
    fristPanel.add(txt_numroom);  
    fristPanel.add(room_type); 
    fristPanel.add(combobox_type);
    
    fristPanel.add(Flour_num);  
    fristPanel.add(combobox_flour); 
    
    fristPanel.add(Flour_num);  
    fristPanel.add(combobox_flour);
    
    fristPanel.add(Price);  
    fristPanel.add(txt_price);
    
    fristPanel.add(state);  
    fristPanel.add(combobox_state);
    
   
    
    secondPanel.setLayout(new FlowLayout());
    button_Add2.add(Box.createRigidArea(new Dimension(400,80)));
    button_Add2.setFont(new Font("DialogInput",Font.BOLD,40));
       
    button_Exit2.add(Box.createRigidArea(new Dimension(400,80)));
    button_Exit2.setFont(new Font("DialogInput",Font.BOLD,40));
    
    
    
    secondPanel.setBackground(new Color(184,223,255));
    secondPanel.add(button_Add2);
    secondPanel.add(button_Exit2);
    
    label.setFont(font);

    upPanel.add(label);
    
    BasePanel.add(Box.createVerticalStrut(30));
    BasePanel.add(upPanel);
    BasePanel.add(Box.createVerticalStrut(10));
    BasePanel.add(fristPanel);
    BasePanel.add(Box.createVerticalStrut(30));
    BasePanel.add(secondPanel);
    
    
    add(BasePanel);
     button_Add2.addActionListener(this);
     button_Exit2.addActionListener(this);  
   }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==button_Exit2){
            this.setVisible(false);
            
        }
        
        
         
         if (e.getSource()==button_Add2){
             
             if(txt_numroom.getText().equals("")||combobox_type.getSelectedItem().equals("")|| combobox_flour.getSelectedItem().equals("")
                   ||txt_price.getText().equals("")||combobox_state.getSelectedItem().equals("") ){
           
             JOptionPane.showMessageDialog(this, "You should fill the missing blanks!!!","Warning" , JOptionPane.WARNING_MESSAGE);
           
           
           }//if
           
           else{
             try{
        String url="jdbc:mysql://localhost:3306/hms?useSSL=true";
        String username="root";
        String password="1234";
 
        connect=DriverManager.getConnection(url, username, password);
        System.out.print("Connected successfully\n");
        
        
        //get customer information from text fields
        String room_numS=txt_numroom.getText();
        int room_numInt=Integer.parseInt(room_numS);
        
        Object room_type=combobox_type.getSelectedItem();
         String type_string=room_type.toString();
        
        //int id=Integer.parseInt(txt_national.getText());
        
        //get user selection(gender) from combo, then convert to string
        Object floor_combo=combobox_flour.getSelectedItem();
        int floor_num=Integer.parseInt(floor_combo.toString());
        
        
        //get date to then convert to string
        Double price =Double.parseDouble(txt_price.getText());
        
        //get user selection(gender) from combo, then convert to string
        Object state_combo= combobox_state.getSelectedItem();
        String state_string=state_combo.toString();
        
      
        
        
        String sql=String.format("insert into room(room_num,room_type,floor_num,Price,state)"
          + "values('%d','%s','%d','%f','%s')",room_numInt,type_string,floor_num,price,state_string);
         
        Statement statement=connect.createStatement();
        statement.executeUpdate(sql);
        JOptionPane.showMessageDialog(this, "Added successfully"," ",JOptionPane.INFORMATION_MESSAGE);
        txt_numroom.setText("");
        combobox_type.setSelectedIndex(0);
        combobox_flour.setSelectedIndex(0);
        txt_price.setText("");
        combobox_state.setSelectedIndex(0);
        
        
        
        
       
        }//try 
        
        catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }//catch
        
         
        
            
           }//else
             
         
         }//add
    }
}
