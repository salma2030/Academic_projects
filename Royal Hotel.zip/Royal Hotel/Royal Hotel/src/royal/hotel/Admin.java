/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package royal.hotel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.BoxLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JTextFieldDateEditor;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;


public class Admin extends JFrame implements ActionListener{
    
 
 ImageIcon logo =new  ImageIcon(getClass().getResource("logo1.png"));
  JLabel  admin_login = new JLabel(" Admin Login     ",logo,SwingConstants.LEFT); 
  JLabel  admin_username = new JLabel("UserName");
  JTextField txt1 =new JTextField(15);
  
  JLabel  admin_password = new JLabel("PassWord"); 
  JPasswordField txt2 =new JPasswordField(15);
    
    
 ImageIcon background_icon =new  ImageIcon(getClass().getResource("bussiness.jpg"));
 JLabel background_label=new JLabel(background_icon);
 
  JButton button_login=new JButton ("Login");
  JButton button_exit1=new JButton ("Exit");
 
   JPanel upPanel=new JPanel();
   JPanel BasePanel=new JPanel();
   JPanel FristPanel=new JPanel();
   JPanel SecondPanel=new JPanel();
    
    
 public Admin(){
  add(background_label);  
  
   admin_login.setFont(new Font("DialogInput",1+2,70));
   upPanel.setLayout(new FlowLayout());
   upPanel.add(admin_login);
   upPanel.setBackground(new Color(0,0,0,0));
   
   BasePanel.setBounds(130, 100, 1500, 950);//x,y,width,hight
   BasePanel.setLayout(new BoxLayout(BasePanel,BoxLayout.Y_AXIS));
   
   BasePanel.add(upPanel);
  
   admin_username.setFont(new Font("DialogInput",1+2,70));
   admin_password.setFont(new Font("DialogInput",1+2,70));
   FristPanel.setLayout(new GridLayout(2,2,5,5));
   
   Font font=new Font("DialogInput",1+2,70);
   
   FristPanel.add(admin_username);
   
   FristPanel.setBackground(new Color(0,0,0,0));
   txt1.setFont(font);
   txt1.setPreferredSize(new Dimension(100,70));
   FristPanel.add(txt1);
   
  
   FristPanel.add(admin_password);
  
   FristPanel.add(txt2);
   FristPanel.setBounds(130, 100, 1500, 90);//x,y,width,hight
   txt2.setFont(font);
   txt2.setPreferredSize(new Dimension(100,70));
   BasePanel.add(FristPanel);
   
   button_login.add(Box.createRigidArea(new Dimension(400,80)));
   button_login.setFont(new Font("DialogInput",Font.BOLD,40));
   button_exit1.add(Box.createRigidArea(new Dimension(400,80)));
   button_exit1.setFont(new Font("DialogInput",Font.BOLD,40));
   SecondPanel.add(button_login);
   SecondPanel.add(Box.createHorizontalStrut(25));
   SecondPanel.add(button_exit1);
   SecondPanel.setBackground(new Color(0,0,0,0));
   
   BasePanel.add(Box.createVerticalStrut(30));
   BasePanel.add(SecondPanel);
   
   BasePanel.setBackground(new Color(0,0,0,0));
   background_label.add(BasePanel);
   
   
   button_login.addActionListener(this);
  button_exit1.addActionListener(this);
    
    }
    
    

    @Override
    public void actionPerformed(ActionEvent e) {
         if (e.getSource()==button_login){
             
              String username=txt1.getText();
              String pass=txt2.getText();
             if(username.equals("maryam")&&pass.equals("1111")){
               JOptionPane.showMessageDialog(rootPane, "Welcom "+username, "Login",JOptionPane.INFORMATION_MESSAGE );
               
                Admin_activities m =new Admin_activities();
                m.setVisible(true);
                m.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                m.setSize(1500,800);
                m.setLocationRelativeTo(null);
                 this.setVisible(false);
                }
        
              else  {
              JOptionPane.showMessageDialog(rootPane, "UserName or Password is not correct", "Login",JOptionPane.ERROR_MESSAGE );
              }
         }
         if (e.getSource()==button_exit1){
             this.setVisible(false);
         }
         
         
         
    }
}