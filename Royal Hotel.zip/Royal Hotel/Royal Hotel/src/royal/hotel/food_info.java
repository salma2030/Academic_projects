/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package royal.hotel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class food_info extends JFrame implements ActionListener {
    
    
 JPanel BasePanel=new JPanel();
 JPanel upPanel=new JPanel();
 JPanel fristPanel=new JPanel();
  
 JLabel  label = new JLabel("Food Information");
  JLabel  label1 = new JLabel("Number Of Person:");
  
 JPanel secondPanel=new JPanel();  
 JPanel therdPanel=new JPanel();  
 JTextField  num_of_person=new JTextField (15);
 JCheckBox breakfast=new JCheckBox("BreakFast---->15 SAR per person (Time:from 7:00AM to 9:00AM)");
 JCheckBox lunch=new JCheckBox("Lunch---->20 SAR per person (Time:from 1:00PM to 3:00PM)");
 JCheckBox dinner=new JCheckBox("Dinner---->15 SAR per person (Time:from 7:00PM to 9:00PM)");
 
 JButton button_ok=new JButton ("Ok");
 Font font=new Font("DialogInput",1+2,50);
 public int meal_count=1;
 Connection connect;
 int Cid;
 String check="not working";
 
    
    
  public  food_info(){
      
  label.setFont(new Font("DialogInput",1+2,60));
  label1.setFont(new Font("DialogInput",1+2,50));
  upPanel.add(label);
  
  fristPanel.setBorder(new EmptyBorder(100,100,100,150));//top left bottom right //to put empty border around centerpanelt
  BasePanel.setLayout(new BoxLayout(BasePanel,BoxLayout.Y_AXIS));
  BasePanel.setBackground(new Color(255,192,219));//255,192,219)>>pink (184,223,255)>>blue
  fristPanel.setBackground(new Color(255,192,219));
  fristPanel.setLayout(new BoxLayout(fristPanel,BoxLayout.Y_AXIS));
  
  
  secondPanel.setBackground(new Color(255,192,219));
  
  therdPanel.setBackground(new Color(255,192,219));
  upPanel.setBackground(new Color(255,192,219));
  breakfast.setFont(new Font("DialogInput",1+2,30));
  lunch.setFont(new Font("DialogInput",1+2,30));
  dinner.setFont(new Font("DialogInput",1+2,30));
  num_of_person.setFont(font);
  
  
  breakfast.setBackground(new Color(255,192,219));
  lunch.setBackground(new Color(255,192,219));
  dinner.setBackground(new Color(255,192,219));
  fristPanel.add(breakfast);
   fristPanel.add(Box.createVerticalStrut(20));
  fristPanel.add(lunch);
   fristPanel.add(Box.createVerticalStrut(20));
  fristPanel.add(dinner);
  
  secondPanel.add(label1);
  secondPanel.add(num_of_person);
  
  
    button_ok.add(Box.createRigidArea(new Dimension(400,80)));
    button_ok.setFont(new Font("DialogInput",Font.BOLD,40)); 
    
    therdPanel.add(button_ok);
   BasePanel.add(Box.createVerticalStrut(30)); 
  BasePanel.add(upPanel);
  BasePanel.add(fristPanel);
  BasePanel.add(Box.createVerticalStrut(30));
  BasePanel.add(secondPanel);
   BasePanel.add(therdPanel);
   
    this.add(BasePanel);
    button_ok.addActionListener(this);
  
    
      
  }  
 
    @Override
    public void actionPerformed(ActionEvent e) {
        String meal="";
        double Price=000.00;
        int person=Integer.parseInt(num_of_person.getText());
        
        if (breakfast.isSelected()){
                meal+="breakfast ";
                Price+=15.0;
                
            }
            
            
            
            if(lunch.isSelected()){
                meal+=" lunch";
                Price+=20.0;
            }
            
            if(dinner.isSelected()){
                meal+=" dinner";
                Price+=15.0;
            }
            
            
        if (e.getSource()==button_ok){
            
            try{
        String url="jdbc:mysql://localhost:3306/hms?useSSL=true";
        String username="root";
        String password="1234";
 
        connect=DriverManager.getConnection(url, username, password);
        System.out.print("Connected successfully\n");
        
         String sql=String.format("SELECT customer_id from customer where f_name='%s' and national_id=%d",Customer.userName,Customer.Password);
                Statement statement4=connect.createStatement();
                ResultSet rs2=statement4.executeQuery(sql);
                
                if(rs2.next()){
                    check="Perfect\n";
                    System.out.print(rs2.getObject(1));
                    Cid=Integer.parseInt(rs2.getObject(1).toString());
                }
                
                System.out.print(check);
                
        
          String sql_1=String.format("insert into meal(meal_id,meal,Price,Customer_id)"
          + "values('%d','%s','%f','%d')",meal_count++,meal,Price*person,Cid);
         
        Statement statement=connect.createStatement();
        statement.executeUpdate(sql_1);
        
        JOptionPane.showMessageDialog(this, "Included successfully"," ",JOptionPane.INFORMATION_MESSAGE);
        
          this.setVisible(false); 
            Bill_afterBook bill=new Bill_afterBook();
            bill.setVisible(true);
            bill.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            bill.setSize(1600,1000);
            bill.setLocationRelativeTo(null);
        
        
        
        }//try 
        
        catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }//catch
            
        }//ok  
            
         
    }//actionPerformed
    
}//class
