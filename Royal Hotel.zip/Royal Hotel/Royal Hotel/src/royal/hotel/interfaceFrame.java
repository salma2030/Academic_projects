/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package royal.hotel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
//import javax.swing.JColorChooser;
//import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class interfaceFrame extends JFrame implements ActionListener {

    JLabel wel_label =new JLabel("Welcom to Royal Hotel");
    JPanel FristPanel=new JPanel();
    JPanel SecondPanel=new JPanel();
    JButton Admin=new JButton("ADMIN");
   
    JButton Customer=new JButton("CUSTOMER");
    JTextArea hoteldiscription=new JTextArea();
    ImageIcon icon =new  ImageIcon(getClass().getResource("royal1.jpg"));
    JLabel icon_label=new JLabel(icon);
    
    
    Box box=Box.createVerticalBox();
    
    public interfaceFrame(){
     this.setLayout(new FlowLayout());
     add(box);
     FristPanel.setLayout(new FlowLayout());
     wel_label.setFont(new Font("DialogInput",1+2,80));
     wel_label.setForeground(new Color(41,82,197));
     
     Admin.setFont(new Font("DialogInput",Font.BOLD,20));
     Customer.setFont(new Font("DialogInput",Font.BOLD,20));
     
     
     Admin.add(Box.createRigidArea(new Dimension(100,80)));
     Customer.add(Box.createRigidArea(new Dimension(100,80)));
     
     
     FristPanel.add(Box.createHorizontalStrut(350));
     FristPanel.add(wel_label);
     FristPanel.add(Box.createHorizontalStrut(300));
     FristPanel.add(Admin);
     FristPanel.add(Box.createHorizontalStrut(20));
     FristPanel.add(Customer);
     
    hoteldiscription.setEditable(false);
    hoteldiscription.setPreferredSize(new Dimension(100,100));
    hoteldiscription.setText("Hotel Royal is one of the best 3 star hotels in the city\n" +
"We offer best services to the customers.\nWe make the clients feel at home.\n" +
"We also provide meeting and conference hall services.\nHalls for parties and home function are also available.");
    hoteldiscription.setBackground(new Color(184,223,255));
    hoteldiscription.setWrapStyleWord(true);
    hoteldiscription.setLineWrap(true);
    hoteldiscription.setFont(new Font("DialogInput",1+2,55));
    hoteldiscription.setForeground(Color.DARK_GRAY);
    
     
     SecondPanel.setLayout(new GridLayout(1,2,10,10) );
     SecondPanel.add(icon_label);
     SecondPanel.add(hoteldiscription);
     box.add(Box.createVerticalStrut(30));
     box.add(FristPanel);
     box.add(Box.createVerticalStrut(50));
     box.add(SecondPanel);
     
      Admin.addActionListener(this);
      Customer.addActionListener(this);
     
        
    }
           
    
    
    public void actionPerformed(ActionEvent e) {
        
        
           if (e.getSource()==Admin){
              Admin dm=new Admin();
             
            dm.setVisible(true);
            dm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            dm.setSize(1800,1100);
            dm.setLocationRelativeTo(null);
              
            
        }
         if (e.getSource()==Customer){
          Customer cus=new Customer ();  
         
          cus.setVisible(true);
          cus.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
          cus.setSize(1500,1100);
          cus.setLocationRelativeTo(null);  
           
        }
        
        
        
    }
    
}
