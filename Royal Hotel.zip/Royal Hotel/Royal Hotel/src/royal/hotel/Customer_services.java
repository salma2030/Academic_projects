
package royal.hotel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


public class Customer_services extends JFrame implements ActionListener{

    
  JButton button_book =new JButton ("Book a Room");
  JButton button_join =new JButton ("Include Meals");
  JButton button_free=new JButton ("View Free Services");
//  JButton button_print=new JButton ("Print Invoice");
  JButton button_ava=new JButton ("Check Avalibility");
  
  JButton button_exit=new JButton ("EXIT");
  
 
 JPanel BasePanel=new JPanel();
 JPanel fristPanel=new JPanel(); 
 JPanel secondPanel=new JPanel();
 public static int reservation_count=1;
 
    
 public Customer_services (){
     BasePanel.setLayout(new BoxLayout(BasePanel,BoxLayout.Y_AXIS));
     
    fristPanel.setLayout(new GridLayout(2,2,5,5));
    
   fristPanel.setBorder(new EmptyBorder(50,200,50,200));
   BasePanel.setBackground(new Color(255,192,219));//255,192,219)>>pink (184,223,255)>>blue
   secondPanel.setBackground(new Color(255,192,219));
   fristPanel.setBackground(new Color(255,192,219));
   
   button_book.setFont(new Font("DialogInput",Font.BOLD,40));
   button_book.add(Box.createRigidArea(new Dimension(400,80)));
   
   button_join.setFont(new Font("DialogInput",Font.BOLD,40));
   button_join.add(Box.createRigidArea(new Dimension(400,80)));
   
   button_free.setFont(new Font("DialogInput",Font.BOLD,40));
   button_free.add(Box.createRigidArea(new Dimension(400,80)));
   
   //button_print.setFont(new Font("DialogInput",Font.BOLD,40));
   //button_print.add(Box.createRigidArea(new Dimension(400,80)));
   
   button_ava.setFont(new Font("DialogInput",Font.BOLD,40));
   button_ava.add(Box.createRigidArea(new Dimension(400,80)));
   
   button_exit.setFont(new Font("DialogInput",Font.BOLD,40));
   button_exit.add(Box.createRigidArea(new Dimension(400,80)));
   
   
   
   fristPanel.add(button_book);
   fristPanel.add(button_join);
   fristPanel.add(button_free);
   
   //BasePanel.add(button_print);
   fristPanel.add(button_ava);
   secondPanel.add(button_exit);
   
   BasePanel.add(Box.createVerticalStrut(20));
   BasePanel.add(fristPanel);
   BasePanel.add(Box.createVerticalStrut(20));
   BasePanel.add(secondPanel);
   
  
   
    add(BasePanel); 
      
      
  button_book.addActionListener(this);
  button_join.addActionListener(this);
  button_free.addActionListener(this);
  //button_print.addActionListener(this);  
  button_ava.addActionListener(this);
  button_exit.addActionListener(this);   
 }   
 
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==button_book){
            
            
            Book_room ser=new Book_room();
            ser.setVisible(true);
            ser.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            ser.setSize(1800,1200);
            ser.setLocationRelativeTo(null);
               
        }
         if (e.getSource()==button_join){
             food_info  food=new food_info();
                    food.setVisible(true);
                    food.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    food.setSize(1650,1000);
                    food    .setLocationRelativeTo(null);
            
            
        }
          if (e.getSource()==button_free){
            View_Free_Service free=new View_Free_Service();
                    free.setVisible(true);
                    free.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    free.setSize(1650,1000);
                    free.setLocationRelativeTo(null);
            
        }
          /* if (e.getSource()==button_print){
            
            
        }*/
            if (e.getSource()==button_ava){
                    Check_room_Availabilty ava=new Check_room_Availabilty();
                    ava.setVisible(true);
                    ava.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    ava.setSize(1650,1000);
                    ava.setLocationRelativeTo(null);

            
        }
             if (e.getSource()==button_exit){
              this.setVisible(false);
            
        }
      
    }
    
}
