
package royal.hotel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;


public class Customer extends JFrame implements ActionListener{
    
        
  
  JLabel  cus_login = new JLabel("   Customer Login     "); 
  JLabel  cus_username = new JLabel("UserName");
  JTextField txt1 =new JTextField("First name",15);
  
  JLabel  cus_password = new JLabel("PassWord"); 
  JPasswordField txt2 =new JPasswordField("National ID",15);
    
    
 
 
  JButton button_login=new JButton ("Login");
  JButton button_sinup=new JButton ("Sign up");
 JButton button_exit=new JButton ("Exit");
 
   JPanel picPanel=new JPanel();
   
   JPanel upPanel=new JPanel();
   JPanel BasePanel=new JPanel();
   JPanel fristPanel=new JPanel();
   JPanel secondPanel=new JPanel();
   
   public static int customer_count=0;
   public static String userName;
   public static int Password;
   
   Connection connect=null;
   
 public Customer(){
     
   BasePanel.setLayout(new BoxLayout(BasePanel,BoxLayout.Y_AXIS));  
   
   
   upPanel.add(cus_login);
   upPanel.setBackground(new Color(255,192,219));
   
   fristPanel.setLayout(new GridLayout(2,2,5,5));
   
   cus_login.setFont(new Font("DialogInput",1+2,70));
   cus_username.setFont(new Font("DialogInput",1+2,50));
   cus_password.setFont(new Font("DialogInput",1+2,50));
   
   Font font=new Font("DialogInput",1+2,40);
     txt2.setFont(font);
     txt1.setFont(font);
   fristPanel.add(cus_username);
   fristPanel.add(txt1);
   fristPanel.add(cus_password);
   fristPanel.add(txt2);
   fristPanel.setBorder(new EmptyBorder(100,300,100,300));
   
   secondPanel.setLayout(new FlowLayout());
   
   secondPanel.add(button_login);
   secondPanel.add(Box.createHorizontalStrut(20));
   secondPanel.add(button_sinup);
   secondPanel.add(Box.createHorizontalStrut(20));
   secondPanel.add(button_exit);
   
   BasePanel.add(Box.createVerticalStrut(200));      
   BasePanel.add(upPanel);
   BasePanel.add(fristPanel);
   BasePanel.add(secondPanel);
   BasePanel.setBackground(new Color(255,192,219));//255,192,219)>>pink (184,223,255)>>blue
   fristPanel.setBackground(new Color(255,192,219));
   secondPanel.setBackground(new Color(255,192,219));
   
   button_login.add(Box.createRigidArea(new Dimension(400,80)));
   button_login.setFont(new Font("DialogInput",Font.BOLD,40));
   button_sinup.add(Box.createRigidArea(new Dimension(400,80)));
   button_sinup.setFont(new Font("DialogInput",Font.BOLD,40));
  
   button_exit.add(Box.createRigidArea(new Dimension(400,80)));
   button_exit.setFont(new Font("DialogInput",Font.BOLD,40));
   
    
   this.add(BasePanel);
    button_login.addActionListener(this);
    button_sinup.addActionListener(this);
    button_exit.addActionListener(this);
 } //constructor
 

    @Override
    public void actionPerformed(ActionEvent e) {
        
         if (e.getSource()==button_login){
             
            
           
           
           try{
               
            String url="jdbc:mysql://localhost:3306/hms?useSSL=true";
            String username_1="root";
            String password="1234";
           
           
           //second step(to retreive the data from the DB )
 
            connect=DriverManager.getConnection(url, username_1, password);
            System.out.print("Connected successfully\n");
            
            
            String Name=txt1.getText();
            String Pass=txt2.getText();
            
            int flag=0;
            
            
           String sql="select * From customer;";//to compare 
           Statement statement=connect.createStatement();// must create a statement always
           ResultSet rs=statement.executeQuery(sql); //stores the result in resultset object(tabular format).
           
         
           while(rs.next())
           {
                  System.out.println(rs.getObject(2)+"  "+rs.getObject(4));
             if((Name).equals(rs.getObject(2))&& (Integer.valueOf(Pass)==rs.getObject(4))){
              
                flag+=1;
                 JOptionPane.showMessageDialog(rootPane, "Logged In");
                 userName=txt1.getText();
                 Password=Integer.parseInt(txt2.getText());
                 txt1.setText("");
                 txt2.setText("");
                 Customer_services services=new Customer_services();
                 services.setVisible(true);
                 services.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                 services.setSize(1500,800);
                 services.setLocationRelativeTo(null);
                 break;
             }
           
                
            }//loop
           
            if(flag==0){
             JOptionPane.showMessageDialog(rootPane, "Error!!!, Try again");
             txt1.setText("");
             txt2.setText("");
           }
           
          
           }//try
           catch(SQLException ex){
           System.out.println(ex.getMessage());
           }//catch
           
            
        }
         
         if (e.getSource()==button_sinup){
             
            customer_count++;
            Customer_info info=new Customer_info();
            
            info.setVisible(true);
            info.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            info.setSize(1800,1200);
            info.setLocationRelativeTo(null);
             
             
        }
          if (e.getSource()==button_exit){
           this.setVisible(false); 
            
        }
    }
    
}
