
package royal.hotel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GraphicsConfiguration;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


public class Room_update extends JFrame implements ActionListener {

     JPanel BasePanel=new JPanel();
      JPanel upPanel=new JPanel();
     JPanel fristPanel=new JPanel();
     JPanel secondPanel=new JPanel();
     
     JLabel  label= new JLabel("Search Room Number");
   JLabel  room_num = new JLabel("Room Number");
   
   
   JLabel  room_type = new JLabel("Room Type");
   JLabel  Flour_num = new JLabel("Floor Number");
   JLabel  Price= new JLabel("Price");
   JLabel  state = new JLabel("State");
   
    String room_t []={"Choose type","twin","single","king","meeting room","festival hall"};
   JComboBox combobox_type =new JComboBox(room_t); 
  
   String flour []={"Choose Foulr","1","2","3"};
   JComboBox combobox_flour =new JComboBox(flour); 
   
   JTextField txt_numroom =new JTextField(15);
   JTextField txt_flour =new JTextField(15);
   JTextField txt_price =new JTextField(15);
   JTextField txt_search =new JTextField(15); 
   
   String room_state []={"Choose State","Available","Unavailable"};
   JComboBox combobox_state =new JComboBox(room_state); 
   
   JButton button_Add2=new JButton ("Update");
   JButton button_Exit2=new JButton ("Exit");
    
   JButton search_button=new JButton ("Search");
         
    Connection connect;
    
    
      public Room_update(){  
      
        
    BasePanel.setLayout(new BoxLayout(BasePanel,BoxLayout.Y_AXIS));
    
    upPanel.setBackground(new Color(184,223,255)); 
    
    BasePanel.setBackground(new Color(184,223,255)); 
    fristPanel.setBorder(new EmptyBorder(100,200,100,200));
    
    fristPanel.setBackground(new Color(184,223,255));
    fristPanel.setLayout(new GridLayout(5,2,5,5));
    
    Font font=new Font("DialogInput",1+2,40);
    Font font1=new Font("DialogInput",1+2,50);
    
    room_num.setFont(font1);
    room_type.setFont(font1); 
    Flour_num.setFont(font1);
    Price.setFont(font1);
    state .setFont(font1);
   
   txt_numroom.setFont(font); 
    combobox_type .setFont(font); 
    combobox_flour.setFont(font); 
    txt_price .setFont(font); 
    combobox_state.setFont(font);
  
    
    
    fristPanel.add(room_num);
    fristPanel.add(txt_numroom);  
    fristPanel.add(room_type); 
    fristPanel.add(combobox_type);
    
    fristPanel.add(Flour_num);  
    fristPanel.add(combobox_flour); 
    
    fristPanel.add(Flour_num);  
    fristPanel.add(combobox_flour);
    
    fristPanel.add(Price);  
    fristPanel.add(txt_price);
    
    fristPanel.add(state);  
    fristPanel.add(combobox_state);
    
   
    
    secondPanel.setLayout(new FlowLayout());
    button_Add2.add(Box.createRigidArea(new Dimension(400,80)));
    button_Add2.setFont(new Font("DialogInput",Font.BOLD,40));
       
    button_Exit2.add(Box.createRigidArea(new Dimension(400,80)));
    button_Exit2.setFont(new Font("DialogInput",Font.BOLD,40));
    
    
     search_button.add(Box.createRigidArea(new Dimension(400,80)));
     search_button.setFont(new Font("DialogInput",Font.BOLD,40));
    
    
    
    secondPanel.setBackground(new Color(184,223,255));
    secondPanel.add(button_Add2);
    secondPanel.add(button_Exit2);
    
    label.setFont(font);
    txt_search.setFont(font);
    upPanel.add(label);
    upPanel.add(txt_search);
    upPanel.add(Box.createHorizontalStrut(30));
    upPanel.add(search_button);//****
    
    
    BasePanel.add(Box.createVerticalStrut(30));
    BasePanel.add(upPanel);
    BasePanel.add(Box.createVerticalStrut(10));
    BasePanel.add(fristPanel);
    BasePanel.add(Box.createVerticalStrut(30));
    BasePanel.add(secondPanel);
    
    
    add(BasePanel);
     button_Add2.addActionListener(this);
     button_Exit2.addActionListener(this); 
     search_button.addActionListener(this); 
    
    }
  
 
    @Override
    public void actionPerformed(ActionEvent e) {
        //search for information
        int flag=0;
        if (e.getSource()==search_button){
            
             try{
        String url="jdbc:mysql://localhost:3306/hms?useSSL=true";
        String username="root";
        String password="1234";
 
        connect=DriverManager.getConnection(url, username, password);
        System.out.print("Connected successfully");
        
        
        //get room number
        String Search=txt_search.getText();
        int search_int=Integer.parseInt(Search);  
            
            
            
        String sql=String.format("select * from room WHERE room_num =%d",search_int);
            
          
         
        Statement statement=connect.createStatement();
        ResultSet rs=statement.executeQuery(sql);
        
        
        while(rs.next())
           {
            
               if(rs.getObject(1)== (Integer.valueOf(Search))){
                   
                   flag=1;
                   txt_numroom.setText(""+rs.getObject(1)); //room number
                   txt_numroom.enable(false);
                   combobox_type.setSelectedItem(rs.getObject(2));//room type
                   combobox_flour.setSelectedItem(String.valueOf(rs.getObject(3)));
                   combobox_flour.enable(false);
                   txt_price.setText(""+rs.getObject(4));//price
                   combobox_state.setSelectedItem(rs.getObject(5));//state
                   combobox_state.enable(false);
                   
                   
                   
               }//if equal
         
       
        }//while
            if(flag==0)
               {
                JOptionPane.showMessageDialog(this, "there is no Room with"+Integer.valueOf(Search)+ " number"," ",JOptionPane.INFORMATION_MESSAGE);   
               }
             }//try
        catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }//catch
          
        }//search button
        
        //......................................................................
        
         if (e.getSource()==button_Exit2){
           this.setVisible(false); 
            
        }//exit button
         
        //......................................................................
         
         
        //update information
         if (e.getSource()==button_Add2){
             
             try{
        String url="jdbc:mysql://localhost:3306/hms?useSSL=true";
        String username="root";
        String password="1234";
 
        connect=DriverManager.getConnection(url, username, password);
        System.out.print("Connected successfully\n");
        
        
        //get room information 
        
        String type=combobox_type.getSelectedItem().toString();
        Double p=Double.parseDouble(txt_price.getText());
        int roomNumber=Integer.parseInt(txt_numroom.getText());
        
        
        String sql=String.format("update room set room_type='%s',Price=%f WHERE room_num =%d;",type,p,roomNumber);
        Statement statement=connect.createStatement();
        int rs=statement.executeUpdate(sql); 
           if (rs==1){
             JOptionPane.showMessageDialog(rootPane, "update successfully"); 
             txt_search.setText("");
             txt_numroom.setText("");
             combobox_type.setSelectedIndex(0);
             combobox_flour.setSelectedIndex(0);
             txt_price.setText("");//price
             combobox_state.setSelectedIndex(0);//state
                   
             
           }//if
           
           else
               JOptionPane.showMessageDialog(rootPane, "ERROR!!,Try again");
           
           this.setVisible(true);
        
             
             }//try
              catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }//catch
             
        }//addButton
         }//actionPerformed
    }//class

            

        
        
        
        
    
    

