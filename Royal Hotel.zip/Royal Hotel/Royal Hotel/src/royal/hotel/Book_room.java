/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package royal.hotel;


import com.toedter.calendar.JDateChooser;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import static royal.hotel.Customer_services.reservation_count;

/**
 *
 * @author Dr.Salma
 */
public class Book_room extends JFrame implements ActionListener {
    
  JPanel BasePanel=new JPanel();
  JPanel upPanel=new JPanel();
  JPanel fristPanel=new JPanel();
  JPanel secondPanel=new JPanel(); 
  
  JLabel  label = new JLabel("Booking Information");
     
  JLabel  room_num = new JLabel("Room Number:");
  JLabel num_night = new JLabel("Number of Night:");
  JLabel checkin_label = new JLabel("Check In:");
  JLabel checkout_label = new JLabel("Check Out:");
  
  JTextField txt_roomnum =new JTextField(15);
  JTextField txt_numnight =new JTextField(15);
  
  
  JDateChooser date_checkin =new JDateChooser();
  JDateChooser date_checkout =new JDateChooser();
  
   JButton button_ok=new JButton ("Ok");
   JButton button_Exit2=new JButton ("Exit");
  
  Font font=new Font("DialogInput",1+2,50);
  //Font font1=new Font("DialogInput",1+2,50);
  Connection connect;
  int Cid;
  String check="not working";
   
public  Book_room(){
    
  label.setFont(new Font("DialogInput",1+2,60));
  
  upPanel.add(label);
  
  fristPanel.setBorder(new EmptyBorder(100,300,100,300));//top left bottom right //to put empty border around centerpanelt
  BasePanel.setLayout(new BoxLayout(BasePanel,BoxLayout.Y_AXIS));
  BasePanel.setBackground(new Color(255,192,219));//255,192,219)>>pink (184,223,255)>>blue
  fristPanel.setBackground(new Color(255,192,219));
  fristPanel.setLayout(new GridLayout(4,2,5,5));
  
  
  room_num.setFont(new Font("DialogInput",1+2,50));
  num_night.setFont(new Font("DialogInput",1+2,50));
  checkin_label.setFont(new Font("DialogInput",1+2,50));
  checkout_label.setFont(new Font("DialogInput",1+2,50));
  
    fristPanel.add(room_num );
    room_num .setFont(font);
    fristPanel.add(txt_roomnum);
    
    txt_roomnum.setFont(font);
    txt_numnight.setFont(font);
            
    date_checkin.setFont(font);
    date_checkout.setFont(font);
                    
    fristPanel.add(num_night);
    num_night.setFont(font);
    fristPanel.add(txt_numnight);
    
    fristPanel.add(checkin_label);
    checkin_label .setFont(font);
    fristPanel.add(date_checkin);
    fristPanel.add(checkout_label);
    checkout_label.setFont(font);
    fristPanel.add(date_checkout);
     
  
    secondPanel.setLayout(new FlowLayout());
    
    button_ok.add(Box.createRigidArea(new Dimension(400,80)));
    button_ok.setFont(new Font("DialogInput",Font.BOLD,40));
       
    button_Exit2.add(Box.createRigidArea(new Dimension(400,80)));
    button_Exit2.setFont(new Font("DialogInput",Font.BOLD,40));
       
    secondPanel.setBackground(new Color(255,192,219));
    upPanel.setBackground(new Color(255,192,219));
    secondPanel.add(button_ok);
    secondPanel.add(button_Exit2);
    
     BasePanel.add(upPanel);
       BasePanel.add(fristPanel);
       BasePanel.add(Box.createVerticalStrut(10));
       BasePanel.add(secondPanel);
       
     
       this.add(BasePanel);
       button_ok.addActionListener(this);
       button_Exit2.addActionListener(this);
      
   
    
}     

    @Override
    public void actionPerformed(ActionEvent e) {
        
        if (e.getSource()==button_ok){
             if(txt_roomnum.getText().equals("")||txt_numnight.getText().equals("")|| date_checkin.getDate()==null
                     || date_checkout.getDate()==null)
                    {
           
             JOptionPane.showMessageDialog(this, "You should fill the missing blanks!!!","Warning" , JOptionPane.WARNING_MESSAGE);
           
           
           }//if
           
           else{
             try{
        String url="jdbc:mysql://localhost:3306/hms?useSSL=true";
        String username="root";
        String password="1234";
 
        connect=DriverManager.getConnection(url, username, password);
        System.out.print("Connected successfully\n");
        
        
        //get room number
        String room_s=txt_roomnum.getText();
        int room_numInt=Integer.parseInt(room_s);
        
        //get number of night
        String night=txt_numnight.getText();
        int night_num=Integer.parseInt(night);
        
        //get checkIn date
        Date Cin_date=date_checkin.getDate();
        String string_dateIn =Cin_date.toString();
        
        //get checkOut date
        Date Cout_date=date_checkout.getDate();
        String string_dateOut =Cout_date.toString();
        
        //for checking if it is added successfully
        int flag=0;
        
        
//        String sql_1=String.format("insert into reservation(reservation_id,NumOfNight,check_in,check_out,customer_id,room_id)"
//          + "values('%d','%d','%s','%s','%d','%d')",Customer_services.reservation_count,night_num,string_dateIn,string_dateOut,Customer.customer_count,room_numInt);
//         
//        Statement statement1=connect.createStatement();
//        statement1.executeUpdate(sql_1);
        String sql=String.format("SELECT customer_id from customer where f_name='%s' and national_id=%d",Customer.userName,Customer.Password);
                Statement statement4=connect.createStatement();
                ResultSet rs2=statement4.executeQuery(sql);
                
                if(rs2.next()){
                    check="Perfect\n";
                    System.out.print(rs2.getObject(1));
                    Cid=Integer.parseInt(rs2.getObject(1).toString());
                }
                
                System.out.print(check);
                
        //retrieve available rooms
        String sql_2="select room_num from room where state='Available';";
        Statement statement2=connect.createStatement();
        ResultSet rs=statement2.executeQuery(sql_2);
        
        
         while(rs.next())
           {
            
               if(rs.getObject(1)==Integer.valueOf(room_s) ){
                   
                   // String sql_1=String.format("insert into reservation(reservation_id,NumOfNight,check_in,check_out,customer_id,room_id)"
                            //+ "values('%d','%d','%s','%s','%d','%d')",Customer_services.reservation_count,night_num,string_dateIn,
                    //string_dateOut,Customer.customer_count,room_numInt);
                   
                    String sql_1=String.format("insert into reservation(reservation_id,NumOfNight,check_in,check_out,customer_id,room_id)"
                            + "values('%d','%d','%s','%s','%d','%d')",Customer_services.reservation_count++,night_num,string_dateIn,
                    string_dateOut,Cid,room_numInt);
                    //Customer.customer_count;
                    Statement statement1=connect.createStatement();
                    statement1.executeUpdate(sql_1);
                    flag=1;
                    JOptionPane.showMessageDialog(this, "Booked successfully"," ",JOptionPane.INFORMATION_MESSAGE);
                    txt_roomnum.setText("");
                    txt_numnight.setText("");
                    date_checkin.setDate(null);
                    date_checkout.setDate(null);
                    
                    
                    
                    
                    
                    //update the state of this room
                     String sql_3=String.format("update room set state='unavailable' WHERE room_num =%d;",Integer.valueOf(room_s));
                     Statement statement3=connect.createStatement();
                     int rs_state=statement3.executeUpdate(sql_3); 
                      if (rs_state==1){
                           System.out.print("State updated successfully"); 
                          // txt_roomnum.setText("");
                       
                      }//if
                      
                      
                      //reset
                      
           
                     else
                           System.out.print("fail to update"); 
                    
                    
                    Bill_afterBook bill=new Bill_afterBook();
                    bill.setVisible(true);
                    bill.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    bill.setSize(1600,1000);
                    bill.setLocationRelativeTo(null);
                   
               }//if equal
               
               
        
        
        
        
       
        }//while
       
            if(flag==0)
               {
                JOptionPane.showMessageDialog(this,"Enter a proper room number!!!\n\nCheck the available rooms"," ",JOptionPane.INFORMATION_MESSAGE);   
               }
            
                    /*Bill_afterBook bill=new Bill_afterBook();
                    bill.setVisible(true);
                    bill.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    bill.setSize(1800,1200);
                    bill.setLocationRelativeTo(null);*/
        }//try 
        
        catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }//catch
        
         
           }//else
            
        }//ok button
        
        
        if (e.getSource()==button_Exit2){
            this.setVisible(false); 
        } //exist button
       
    }
    
   
    
    
    
}//class
