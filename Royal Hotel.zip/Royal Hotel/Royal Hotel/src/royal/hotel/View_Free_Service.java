/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package royal.hotel;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class View_Free_Service extends JFrame implements ActionListener {
    
      
  JPanel BasePanel=new JPanel();
  JPanel upPanel=new JPanel();
  JPanel fristPanel=new JPanel();
  
  JLabel  label = new JLabel("ROYAL HOTAL Free Services");
  
  
 JPanel secondPanel=new JPanel();   
 JTextArea report=new JTextArea(13,30);//10,30
 //JScrollPane scroll =new JScrollPane( report,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
      //   JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
 
 JButton button_ok=new JButton ("Ok");
 Font font=new Font("DialogInput",1+2,20); 
 
 
 
 public  View_Free_Service(){
   
    report.setText("Internet:\n\tWi-Fi\n"
            + "Bathroom:\n\tPrivate bathroom\n\tBathtub\n\tShower\n\tJacuzzi\n\tSlippers\n\tCoffee/tea maker\n"
            + "Entertainment\n\tTV\n"
            + "Furnishing & layout\n\tBalcony/terrace\n\tDesk\nClothes & Laundry\n\t Iron and Board(on request)\n"
            + "General\n\tAir conditioning\n\tSafe\n\tTelephone\n\t"
            + "Free Public Parking\n\t"
            + "GYM Available 24/7\n"
            );
     
     report.setFont(font);
     report.setEditable(false);
     
     
     label.setFont(new Font("DialogInput",1+2,60));
  
  upPanel.add(label);
  
  
    BasePanel.setLayout(new BoxLayout(BasePanel,BoxLayout.Y_AXIS));
      BasePanel.setBackground(new Color(255,192,219));
      fristPanel.setBackground(new Color(255,192,219));
       
      secondPanel.setBackground(new Color(255,192,219));
      
      
      BasePanel.add(fristPanel);
      BasePanel.add(secondPanel);
      secondPanel.add(button_ok);
 
  
  
  
  secondPanel.setBackground(new Color(255,192,219));
  upPanel.setBackground(new Color(255,192,219));
  
  
  
  
  
  fristPanel.add(report);
  
    button_ok.add(Box.createRigidArea(new Dimension(400,80)));
    button_ok.setFont(new Font("DialogInput",Font.BOLD,40)); 
    
  
  secondPanel.add(button_ok);
    
  BasePanel.add(label);
  BasePanel.add(Box.createVerticalStrut(20));
  BasePanel.add(fristPanel);
  BasePanel.add(Box.createVerticalStrut(20));
  BasePanel.add(secondPanel);
    this.add(BasePanel);
    button_ok.addActionListener(this);
     
     
     
     
     
     
 } 

    @Override
    public void actionPerformed(ActionEvent e) {
          if (e.getSource()==button_ok){
            
            this.setVisible(false); 
            
        } 
    }
    
    
    
    
}
