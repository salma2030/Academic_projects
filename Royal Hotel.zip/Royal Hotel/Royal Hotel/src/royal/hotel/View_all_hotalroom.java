/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package royal.hotel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class View_all_hotalroom extends JFrame implements ActionListener {
    
    JPanel BasePanel=new JPanel();
  JPanel upPanel=new JPanel();
  JPanel fristPanel=new JPanel();
  
  JLabel  label = new JLabel("  View all Hotal Room");
  
  
 JPanel secondPanel=new JPanel();   

 JButton button_ok=new JButton ("Ok");
 Font font=new Font("DialogInput",1+2,40);
 Connection connect;
 int flag=0;
 JTable table= new JTable();
  JTable tables;
  DefaultTableModel model = new DefaultTableModel();
 //JScrollPane scroll =new JScrollPane(table);
 String[] header={"room_num","room_type","floor_num", "Price ","state"};
 
 
  public  View_all_hotalroom(){
      
  label.setFont(new Font("DialogInput",1+2,60));
  
  upPanel.add(label);
  
  
    BasePanel.setLayout(new BoxLayout(BasePanel,BoxLayout.Y_AXIS));
      BasePanel.setBackground(new Color(255,192,219));
      fristPanel.setBackground(new Color(255,192,219));
       
      secondPanel.setBackground(new Color(255,192,219));
      
      
      BasePanel.add(fristPanel);
      BasePanel.add(secondPanel);
      secondPanel.add(button_ok);
 
  
  
  
  secondPanel.setBackground(new Color(255,192,219));
  upPanel.setBackground(new Color(255,192,219));
  
 // report.setFont(font);
  model.setColumnIdentifiers(header);
   JTable tabless = new JTable(model);
        tabless.setModel(model);
       
        tabless.setFillsViewportHeight(true);
        JScrollPane scroll = new JScrollPane(tabless);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

  
    button_ok.add(Box.createRigidArea(new Dimension(400,80)));
    button_ok.setFont(new Font("DialogInput",Font.BOLD,40)); 
    
  
  secondPanel.add(button_ok);
    
  BasePanel.add(label);
  BasePanel.add(Box.createVerticalStrut(20));
  BasePanel.add(fristPanel);
  BasePanel.add(Box.createVerticalStrut(20));
  BasePanel.add(secondPanel);
    this.add(BasePanel);
    
    //connection
  
    try{
        
        
        
        String url="jdbc:mysql://localhost:3306/hms?useSSL=true";
        String username="root";
        String password="1234";
 
        connect=DriverManager.getConnection(url, username, password);
        System.out.print("Connected successfully\n");
       
        
        String sql="select * from room;";
        Statement statement=connect.createStatement();
        ResultSet rs=statement.executeQuery(sql); 
        
        
        int nOfC=5;
        int nOfR=0;
        
        if(rs.next()){
          rs.last();
          nOfR=rs.getRow();
          
        }
        String record [][]= new String[nOfR][nOfC];
        rs.beforeFirst();
        
        for (int i=0; i<nOfR;i++ ){
             rs.next();
             record[i][0]=rs.getString("room_num");
             record[i][1]=rs.getString("room_type");
             record[i][2]=rs.getString("floor_num");
             record[i][3]=rs.getString("Price");
             record[i][4]=rs.getString("state");
        }
        table=new JTable(record,header);
         String columnsHeader[] = {"room_num", "room_type", "floor_num", "Price","state"};

           

            JScrollPane scrollPane = new JScrollPane(table);
            //table.setFont(font);
            fristPanel.add(scrollPane);
          
          if(flag==0){
             /*report.setText("No reservation to record");
             report.setFont(font);
             fristPanel.add(report);*/
              
               JOptionPane.showMessageDialog(rootPane, "No rooms to view");
                     
             
           }
             
             }//try
              catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }//catch
             
    
    
    
    button_ok.addActionListener(this);
      
  }  

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==button_ok){
            
            this.setVisible(false); 
            
        } 
    
} 
    
}
