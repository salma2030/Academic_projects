<!--add and edit a college --> 
<?PHP

$college_id = req('college_id');

if($college_id){
    $college = getColleges($college_id)[0];
    
}

$college_id = isset($college['college_id'])? $college['college_id'] : req('college_id');
$college_name = isset($college['college_name'])? $college['college_name'] : req('college_name');
$college_location = isset($college['college_location'])? $college['college_location'] : req('college_location');


if(isset($_GET['remove_id'])){
    $remove_id = req('remove_id');
    if(delete("DELETE FROM `colleges` WHERE college_id = '$remove_id'")){
        redirect_to("index.php?do=colleges&msg=remove");
    }
}

?>
<div class="wrapper">
    <div class="container-fluid mt-3">
        <div class="text-left">
            <div id="alert_msg"></div>
        </div>
        
        <div class="row mt-2">
            <div class="col-12">
                <div class="card-box">
                    <h4 class="m-t-0 header-title"><?= gText(($college_id)?"edit_college": "add_new_college")?></h4>
                    
                    <form class="form-horizontal" role="form" method="post">
                        <div class="row">
                            <div class="col-5">
                                <div class="p-20">
                                    
                                    <div class="form-group row">
                                        <label class="col-3 col-form-label"><?= gText("college_name")?><small class="float-right text-danger fa fa-star"></small></label>
                                        <div class="col-9">
                                            <input type="text" name="college_name" id="college_name"  class="form-control" value="<?=$college_name?>">
                                        </div>
                                    </div>
                                       
                                    <div class="form-group row">
                                        <label class="col-3 col-form-label"><?= gText("college_location")?></label>
                                        <div class="col-9">
                                            <input type="text" name="college_location" id="college_location"  class="form-control" value="<?=$college_location?>">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group row">
                                        <label class="col-3 col-form-label">&nbsp;</label>
                                        <button type="submit" name="process" id="process" class="btn btn-success"><?=($college_id)? gText("update") : gText("add")?></button>
                                    </div>

                                    </div>      
                                </div>
                            </div>
                          </form>
                            <!-- end row -->

                        </div> <!-- end card-box -->
                    </div><!-- end col -->
                </div>
                <!-- end row -->
                
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->
<?PHP
     //submitting the form   
    if(isset($_POST['process'])){

    $college_name =  req('college_name');
    $college_location =  req('college_location');
    
    $msg_error = NULL;
         //set error messages for college name.   
        if(!$college_name)
            $msg_error[] = gText("field_college_name_empty");

        if($msg_error == null):

            if($college_id){

                    $sql = "UPDATE `colleges` SET "
                            . "`college_name`= '$college_name',"
                            . "`college_location`= '$college_location' "

                            . "WHERE college_id = $college_id";

                    if(update($sql)){
                        redirect_to("index.php?do=colleges&msg=update");
                    }else{
                    echo Alert(gText("msg_record_nothing_update"),2);        
                    }

            }else{
                
                $sql = "INSERT INTO `colleges` (`college_id`, `college_name`, `college_location`) VALUES (NULL, '$college_name', '$college_location')";

                if(insert($sql)){
                    redirect_to("index.php?do=colleges&msg=add");
                }else{
                    echo Alert(gText("Error"),4);        
                }

            }

        else:
            echo Alert($msg_error[0],4);    
        endif;
            
        
        }
        ?>