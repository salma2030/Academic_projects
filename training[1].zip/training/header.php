<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title><?= gText("site_name")?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/style.css" rel="stylesheet" type="text/css" />
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/modernizr.min.js"></script>

        
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Almarai:wght@300&family=Cairo:wght@700&display=swap" rel="stylesheet">
<style>
    body{
        font-family: 'Almarai', sans-serif;
font-family: 'Cairo', sans-serif;
    }
</style>
        <link href="assets/css/bootstrap-datetimepicker.min.css" rel="stylesheet" />
    
    </head>

    <body>

        <!-- Navigation Bar-->
        <header id="topnav">
            <div class="topbar-main">
                <div class="container-fluid">

                    <!-- Logo container-->
                    <div class="logo">
                        <!-- Text Logo -->
                        <a href="index.php" class="logo">
                            <span class="logo-small"><i class="mdi mdi-radar"></i></span>
                            <span class="logo-large"><i class="mdi mdi-radar"></i> <?= gText("site_name")?></span>
                        </a>
                    </div>
                    <!-- End Logo container-->


                    <div class="menu-extras topbar-custom">

                        <ul class="list-inline float-right mb-0">

                            <li class="menu-item list-inline-item">
                                <!-- Mobile menu toggle-->
                                <a class="navbar-toggle nav-link">
                                    <div class="lines">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </div>
                                </a>
                                <!-- End mobile menu toggle-->
                            </li>
                         

                   

                        </ul>
                    </div>
                    <!-- end menu-extras -->

                    <div class="clearfix"></div>

                </div> <!-- end container -->
            </div>
            <!-- end topbar-main -->

            <div class="navbar-custom">
                <div class="container-fluid">
                    <div id="navigation">
                        <!-- Navigation Menu-->
                        <ul class="navigation-menu">

                            <li class="has-submenu">
                                <a href="index.php"><i class="ti-home"></i> <?= gText("home")?> </a>
                            </li>

                             <li class="has-submenu">
                                <a href="index.php?do=colleges"><i class="ti-layout-column2  "></i> <?= gText("colleges")?> </a>
                            </li>
                            
                             <li class="has-submenu">
                                <a href="index.php?do=supervisors"><i class="ti-eye"></i> <?= gText("supervisors")?> </a>
                            </li>
                            
                              <li class="has-submenu">
                                <a href="index.php?do=coops"><i class="ti-eye"></i> <?= gText("coops")?> </a>
                            </li>
                            
                             <li class="has-submenu">
                                <a href="index.php?do=departments"><i class="ti-layers-alt "></i> <?= gText("departments")?> </a>
                            </li>
                            
                             <li class="has-submenu">
                                <a href="index.php?do=files"><i class="ti-files"></i> <?= gText("files")?> </a>
                            </li>
                              <li class="has-submenu">
                                <a href="index.php?do=myfiles"><i class="ti-files"></i> <?= gText("myfiles")?> </a>
                            </li>
                    

                        </ul>
                        <!-- End navigation menu -->
                    </div> <!-- end #navigation -->
                </div> <!-- end container -->
            </div> <!-- end navbar-custom -->
  
        </header>
        <!-- End Navigation Bar-->

 