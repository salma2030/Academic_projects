<?PHP

$where = "";
$text = req('text');

if($text)
    $where .= " AND `file_name` LIKE '%$text%' ";

  
$sql = "SELECT * FROM `files`  Where student_id IS NULL $where ORDER BY file_id DESC";

$files = getRows($sql);


if(isset($_POST['doSubmit'])){
    
    $target_dir = "uploads/";
    $temp = explode(".", $_FILES["fileToUpload"]["name"]);
    $newfilename = round(microtime(true)) . '.' . end($temp);

  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_dir . $newfilename)) {
      
      $student_id  = req('student_id');
      $file_name  = req('file_name');
      $file = $newfilename;
      $created_at = date('Y-m-d H:i:s');
      

      
      $sql = "INSERT INTO `files` (`file_id`, `student_id`, `types`, `file_name`, `file`, `created_at`) VALUES (NULL, NULL, NULL, '$file_name', '$file', '$created_at')";
    
      if(insert($sql)){
      redirect_to("index.php?do=myfiles&msg=add");    
      }
     
  } else {
    echo "Sorry, there was an error uploading your file.";
  }

}

?>      
<div class="wrapper">
    <div class="container-fluid mt-3">
        <div class="text-left">
            <div id="alert_msg"></div>
        </div>
        <?PHP print_MSG();?>
        <div class="row">
       

                    <div class="col-lg-12 col-xl-12">
                        <div class="">
                            <div class="card-box">
                                   <h4 class="text-dark p-3 header-title m-t-0"><i class="ti-files"></i> <?= gText("list_of_my_files")?> 
                                   
                                   <button type="button" class="float-right btn btn-primary btn-rounded  waves-effect waves-light" data-toggle="modal" data-target="#con-close-modal-my-file-modal"><i class="ti-plus" ></i></button>
                                   </h4>
                                    <form  method="get">
                                        
                                        <input type="hidden" name="do" value="<?=$do?>"/>
                                <div class="row">
                                        
                       <input name="text" id="text" type="text" placeholder="<?= gText("search")?>" value="<?=$text?>" class="form-control mr-2 col-lg-2" autocomplete="on">
                       <button type="submit" class="btn btn-primary mr-2"><?= gText("search")?></button>
                            </div>
                                    </form>
                            
                        <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th width="25">#</th>
                         
                      
                                    <th><?= gText("file_name")?></th>
                                       <th width="200"><?= gText("created_at")?></th>
                                </tr>
                                </thead>
                                <tbody>
                                      <?PHP 
                                            if($files){ 
                                                $i = 0 ;
                                                foreach ($files as $file){$i++;?>
                                <tr>
                             
                               
                                    <td>
                                                <div class="dropdown">
                                                <button class="btn btn-primary btn-block  dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fa fa-fw fa-cog"></i> <?=$file['file_id']?>
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                               
                                               
                                                    <a class="dropdown-item" href="index.php?do=file-process&file_id=<?=$file['file_id']?>"><i class="fa fa-fw fa-edit text-primary"></i> <?= gText("edit")?></a>
                                                    <a class="dropdown-item" href="index.php?do=file-process&remove_id=<?=$file['file_id']?>"><i class="fa fa-fw fa-trash-o text-danger"></i> <?= gText("remove")?></a>
                                                
                                                </div>
                                                </div>
                                                </td>
                       
                                                <td><a class="text-primary" href="uploads/<?=$file['file']?>" download><?=$file['file_name']?></a></td>
                                         <td dir="ltr"><?=$file['created_at']?></td>
                                </tr>
                              <?PHP }}?>
                             
                                </tbody>
                            </table>
                            
                            </div>
                        </div>

                    </div> <!-- end col -->
                </div>
                <!-- end row -->

            </div> <!-- end container -->
        </div>
        
    
    <div id="con-close-modal-my-file-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
        <form  method="post" enctype="multipart/form-data">

            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h4 class="modal-title"><?= gText("upload_file")?></h4>
                    </div>
                    <div class="modal-body">

                        <input type="hidden" name="types" id="types" value="<?=$type?>"/>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group text-left">
                                    <label for="field-1" ><?= gText("file_name")?><small class="float-right text-danger fa fa-star"></small></label>
                                    <input type="text" name="file_name" id="file_name" class="form-control" required="">
                                </div>
                            </div>
                            <div class="col-md-12">
                                  <div class="form-group text-left">
                                    <label for="field-2" class="control-label"><?= gText("file")?><small class="float-right text-danger fa fa-star"></small></label>
                                    <input type="file" name="fileToUpload" id="fileToUpload" class="form-control" required="">
                                </div>
                            </div>
                        </div>



                    </div>
                    <div class="modal-footer" dir="ltr">
                
                        <button type="submit" name="doSubmit" id="doSubmit" class="btn btn-primary waves-effect waves-light float-left"><?= gText("upload")?></button>
                    </div>
                </div>
                </div>
        </form>
    </div><!-- /.modal -->