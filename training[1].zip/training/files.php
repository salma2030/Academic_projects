<?PHP
$type = req('types');
$where = "";

if($type)
    $where .= " AND types = '".gText('types_'.$type)."'";

$sql = "SELECT * FROM `files` LEFT JOIN students ON students.student_id = files.student_id Where  files.student_id IS NOT NULL $where ORDER BY file_id DESC";

$files = getRows($sql);

$types = getTypes();

?>      
<div class="wrapper">
    <div class="container-fluid mt-3">
        <div class="text-left">
            <div id="alert_msg"></div>
        </div>
        <?PHP print_MSG();?>
        <div class="row">
       

                    <div class="col-lg-12 col-xl-12">
                        <div class="">
                            <div class="card-box">
                                   <h4 class="text-dark p-3 header-title m-t-0"><i class="ti-files"></i> <?= gText("list_of_files")?> </h4>
                               
                            <p class="text-muted m-b-30 font-14 ">
                                
                                <a href="index.php?do=files" class="badge badge-<?=(!$type)? 'primary' : 'light'?> border p-2">عرض الكل</a>
                                
                                <?PHP foreach ($types as $item){
                                    $badge = ($item == $type)? 'primary' : 'light';
                                    echo "<a href=\"index.php?do=files&types=$item\" class=\"badge badge-$badge border p-2\">".gText('types_' . $item)."</a>";
                                    }?>
                            </p>
                            
                        <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th><?= gText("type")?></th>
                                    <th><?= gText("student_name")?></th>
                                    <th><?= gText("file_name")?></th>
                                    <th width="200"><?= gText("created_at")?></th>
                                  
                                </tr>
                                </thead>
                                <tbody>
                                      <?PHP 
                                            if($files){ 
                                                $i = 0 ;
                                                foreach ($files as $file){$i++;?>
                                <tr>
                                    <th scope="row"><?=$i?></th>
                                    <td><?=$file['types']?></td>
                                  
                                    <td><a class="text-primary" href="index.php?do=student-profile&student_id=<?=$file['student_id']?>"><?=$file['arabic_name']?></a></td>
                                    <td><a class="text-primary" href="uploads/<?=$file['file']?>" download><?=$file['file_name']?></a></td>
                                    <td dir="ltr"><?=$file['created_at']?></td>
                                  
                                </tr>
                              <?PHP }}?>
                             
                                </tbody>
                            </table>
                            
                            </div>
                        </div>

                    </div> <!-- end col -->
                </div>
                <!-- end row -->

            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->