<?php

date_default_timezone_set('asia/riyadh');

$DB_NAME = "training_db";
$MYSQL_USER = "root";
$MYSQL_PASS = "";
$SERVER_NAME = "localhost";





$con = mysqli_connect($SERVER_NAME,$MYSQL_USER,$MYSQL_PASS,$DB_NAME);

define("SITENAME", "التدريب");

require_once 'functions.php'; //The require_once expression is identical to require except PHP will check if the file has already been included, and if so, not include (require) it again.
require_once ("lib/hijri.class.php");