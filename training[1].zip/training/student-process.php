<?PHP
//This page is created to add and edit a trainee
//For adding a trainee > student_id = null
//For editing a trainee > student_id = id

$student_id = req('student_id');

if($student_id){
//get date from the database
$student = getStudentsByWhere(" AND students.student_id = '$student_id'")[0]; //request one specific student
}

$student_id = isset($student['student_id'])? $student['student_id'] : req('student_id'); //is it empty? no>bring it, yes?require it
$coop_department = isset($student['coop_department'])? $student['coop_department'] : req('coop_department');
$arabic_name = isset($student['arabic_name'])? $student['arabic_name'] : req('arabic_name');
$english_name = isset($student['english_name'])? $student['english_name'] : req('english_name');
$university_id = isset($student['university_id'])? $student['university_id'] : req('university_id');
$identity = isset($student['identity'])? $student['identity'] : req('identity');
$semester = isset($student['semester'])? $student['semester'] : req('semester');
$email = isset($student['email'])? $student['email'] : req('email');
$year = isset($student['year'])? $student['year'] : req('year');
$major = isset($student['major'])? $student['major'] : req('major');

$start_date = isset($student['start_date'])? $student['start_date'] : date('Y-m-d');//Bring the date from the database or set the current day//date() format a local current time/date

$end_date = isset($student['end_date'])? $student['end_date'] :  date('Y-m-d');
$training_period = isset($student['training_period'])? $student['training_period'] : req('training_period');
$phone = isset($student['phone'])? $student['phone'] : req('phone');
$skills = isset($student['skills'])? $student['skills'] : req('skills');
$supervisor_id = isset($student['supervisor_id'])? $student['supervisor_id'] : req('supervisor_id');
$coop_id = isset($student['coop_id'])? $student['coop_id'] : req('coop_id');
$college_id = isset($student['college_id'])? $student['college_id'] : req('college_id');




?>
<div class="wrapper">
    <div class="container-fluid mt-3">
        <div class="text-left">
            <div id="alert_msg"></div>
       
        </div>


                
                    <div class="row mt-2">
                    <div class="col-12">
                        <div class="card-box">
                      <h4 class="m-t-0 header-title"><?= gText(($student_id)?"edit_student" : "add_new_student")?></h4>
                            <form class="form-horizontal" role="form" method="post">
                            <div class="row">
                     
                                <div class="col-5">
                                
                                    <div class="p-20">
                           
                                     
                                            
                                 
                                           
                                            
                                            <div class="form-group row">
                                                <label class="col-4 col-form-label"><?= gText("arabic_name")?><small class="float-right text-danger fa fa-star"></small></label>
                                                <div class="col-8">
                                                    <input type="text" name="arabic_name" id="arabic_name"  class="form-control" value="<?=$arabic_name?>">
                                                </div>
                                            </div>
                                       
                                              <div class="form-group row">
                                                <label class="col-4 col-form-label"><?= gText("english_name")?></label>
                                                <div class="col-8">
                                                    <input type="text" name="english_name" id="english_name"  class="form-control" value="<?=$english_name?>">
                                                </div>
                                            </div>
                                        
                                           
                                            <div class="form-group row">
                                                <label class="col-4 col-form-label"><?= gText("email")?></label>
                                                <div class="col-8">
                                                    <input type="email" name="email" id="email"  class="form-control" value="<?=$email?>">
                                                </div>
                                            </div>
                                     
                                        
                                        
                                          <div class="form-group row">
                                                <label class="col-4 col-form-label"><?= gText("university_id")?></label>
                                                <div class="col-8">
                                                    <input type="text" name="university_id" id="university_id"  class="form-control" value="<?=$university_id?>">
                                                </div>
                                            </div>
                                       
                                          <div class="form-group row">
                                                <label class="col-4 col-form-label"><?= gText("identity")?></label>
                                                <div class="col-8">
                                                    <input type="text" name="identity" id="identity"  class="form-control" value="<?=$identity?>" maxlength="10">
                                                </div>
                                            </div>
                                       
                                            <div class="form-group row">
                                                <label class="col-4 col-form-label"><?= gText("semester")?></label>
                                                <div class="col-8">
                                                    <input type="text" name="semester" id="semester"  class="form-control" value="<?=$semester?>">
                                                </div>
                                            </div> 
                                       
                                                <div class="form-group row">
                                                <label class="col-4 col-form-label"><?= gText("year")?></label>
                                                <div class="col-8">
                                                    <input type="text" name="year" id="year"  class="form-control" value="<?=$year?>">
                                                </div>
                                            </div>
                                        
                                   
                                            
                                        

                                                <!-- button -->
                                                 <div class="form-group row">
                                                <label class="col-3 col-form-label">&nbsp;</label> <!-- if there is an ID> print update, else> add -->
                                                <button type="submit" name="process" id="process" class="btn btn-success"><?=($student_id)? gText("update") : gText("add")?></button>
                                                 </div>

                                    </div>
                                            
                                </div>
                          
                                 <div class="col-4">
                       
                                    <div class="p-20">
                                   
                                     
                                              <div class="form-group row">
                                                <label class="col-4 col-form-label"><?= gText("college")?></label>
                                                <div class="col-8"> <!-- college drop down list -->
                                                    <select class="form-control" name="college_id" id="college_id">
                                                         <option value="NULL"></option>
                                                        <?PHP foreach (getColleges() as $college){?>
                                                        <!--for editing set the entered value as selected, but for adding nothing is selected -->
                                                        <option <?=($college_id == $college['college_id'])? 'selected=""' :''?>  value="<?=$college['college_id']?>"><?=$college['college_name']?></option>
                                                        <?PHP }?>
                                                    </select>
                                                </div>
                                            </div>
                                        
                                            <div class="form-group row">
                                                <label class="col-4 col-form-label"><?= gText("supervisor")?></label>
                                                 <div class="col-8"> <!-- supervisor drop down list -->
                                                    <select class="form-control" name="supervisor_id" id="supervisor_id">
                                                         <option value="NULL"></option>
                                                        <?PHP foreach (getSupervisors() as $supervisor){?>
                                                        <option <?=($supervisor_id == $supervisor['supervisor_id'])? 'selected=""' :''?> value="<?=$supervisor['supervisor_id']?>"><?=$supervisor['supervisor_name']?></option>
                                                        <?PHP }?>
                                                    </select>
                                                </div>
                                            </div>
                                            
                                        
                                                <div class="form-group row">
                                                <label class="col-4 col-form-label"><?= gText("coop_name")?></label>
                                                 <div class="col-8"> <!-- supervisor drop down list -->
                                                    <select class="form-control" name="coop_id" id="coop_id">
                                                        <option value="NULL"></option>
                                                        <?PHP foreach (getCoops() as $coop){?>
                                                        <option <?=($coop_id == $coop['coop_id'])? 'selected=""' :''?> value="<?=$coop['coop_id']?>"><?=$coop['coop_name']?></option>
                                                        <?PHP }?>
                                                    </select>
                                                </div>
                                            </div>
                                    
                                      
                                     
                                            <div class="form-group row">
                                                <label class="col-4 col-form-label"><?= gText("major")?></label>
                                                <div class="col-8">
                                                    <input type="text" name="major" id="major"  class="form-control" value="<?=$major?>">
                                                </div>
                                            </div>
                                       
                                    
                                      
                                            
                                             <div class="form-group row">
                                                <label class="col-4 col-form-label"><?= gText("training_period")?></label>
                                                <div class="col-8">
                                                    <input type="text" name="training_period" id="training_period"  class="form-control" value="<?=$training_period?>">
                                                </div>
                                            </div>
                                          <!--convert  -->
                                          <!-- for view, convert the date from English to Hijri -->
                                            <?PHP $start_date = getH2G($start_date);?>
                                              <div class="form-group row">
                                                <label class="col-4 col-form-label"><?= gText("start_date")?></label>
                                                <div class="col-8">
                             
                                                    <input class="form-control" type="text" name="start_date" id="start_date" value="<?=$start_date?>">
                                                    
                                                </div>
                                            </div>
                                            <!-- for view, convert the date from English to Hijri -->
                                            <?PHP $end_date = getH2G($end_date);?>
                                            <div class="form-group row">
                                                <label class="col-4 col-form-label"><?= gText("end_date")?></label>
                                                <div class="col-8">
                                                    <input class="form-control" type="text" name="end_date" id="end_date" value="<?=$end_date?>">
                                                </div>
                                            </div>
                                            
                                 
                                            
                                            <div class="form-group row">
                                                <label class="col-4 col-form-label"><?= gText("phone")?><small class="float-right text-danger fa fa-star"></small></label>
                                                <div class="col-8">
                                                    <input type="tel" name="phone" id="phone"  class="form-control text-right" value="<?=$phone?>" maxlength="10" placeholder="05xxxxxxxx" dir="ltr">
                                                </div>
                                            </div>
                            
                               

                                       
                                    </div>
                                            
                                </div>
                                
                                       <div class="col-3">
                                
                                    <div class="p-20">
                                        
                                           <div class="form-group ">
                                                <label class="col-form-label"><?= gText("skills")?></label>
                                               
                                                    <textarea class="form-control" name="skills" id="skills" rows="2"><?=$skills?></textarea>
                                               
                                            </div>
                                        
                                        
                                        
                                                        
                                             <div class="form-group">
                                                <label class="col-form-label"><?= gText("department")?></label>
                                                 <div class=""><!-- department list -->
                                                     <select multiple=""  class="form-control" name="department_id" id="department_id" style="height: 180px;">
                                                        <?PHP foreach (getDepartments() as $department){
                                                            //once editing trainee data
                                                            $arr = explode(",", $coop_department);//Break a string into an array
                                                        
                                                            if (in_array($department['department_id'], $arr)) {
                                                                $selected = 'selected=""';
                                                                
                                                            }else{
                                                                $selected = '';
                                                            }

                                                            ?>
                                                         <option <?=$selected?>  value="<?=$department['department_id']?>"><?=$department['department_name']?></option>
                                                        <?PHP }?>
                                                    </select>
                                                     <input type="hidden" name="coop_department" id="coop_department"  class="form-control" value="<?=$coop_department?>">
                                                       <script>
  //when adding a trainee departments                                                     
  document.getElementById('department_id').onchange = function() {
    var selected = [];
    for (var option of document.getElementById('department_id').options)
    {//push any selected option to the array 
        if (option.selected) {
            selected.push(option.value);
 
        }
    }               //id
               $('#coop_department').val(selected);
    //alert(selected);
}
                                                           </script>
                                                </div>
                                            </div>
                                        
                                        
                                    </div>
                                       </div>
                           
                            </div>
                          </form>
                            <!-- end row -->

                        </div> <!-- end card-box -->
                    </div><!-- end col -->
                </div>
                <!-- end row -->
                
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->
        <?PHP
    //once the button is pressed    
    if(isset($_POST['process'])){

        $coop_department =  req('coop_department');
        $arabic_name =  req('arabic_name');
        $english_name =  req('english_name');
        $university_id =  req('university_id');
        $identity =  req('identity');
        $semester =  req('semester');
        $email = req('email');
        $year =  req('year');
        $major =  req('major');
        $start_date =  req('start_date');
        $start_date = getG2H($start_date);// convert it to English to enter the database

        $end_date =  req('end_date');
        $end_date = getG2H($end_date);// convert it to English to enter the database

        $training_period =  req('training_period');
        $phone =  req('phone');
        $skills =  req('skills');
        $supervisor_id =  req('supervisor_id');
        $coop_id =  req('coop_id');
        
        $college_id =  req('college_id');

        $msg_error = NULL;
            
    //set error messages for arabic name.     
    if(!$arabic_name)
            $msg_error[] = gText("field_arabic_name_empty");
    //set error messages for identity.
    if($identity):
       $row = getRow("SELECT * FROM `students` WHERE `identity` = '$identity'");

        if($row['identity'] && ($student_id != $row['student_id'])){ // when adding a student, and enter the ID the added previously. 
            $msg_error[] = gText("field_identity_exists");
        }else if(!preg_match('/^[0-9]{10}+$/', $identity)){//preg_match() function returns whether a match was found in a string.
             //preg_match(pattern, input, matches, flags, offset)
            $msg_error[] = gText('field_identity_10');
        }
    endif;
    
        //set error messages for phone number. 
        if(!$phone){
            $msg_error[] = gText('field_phone_empty');
        }else if(!startsWith( $phone, "05" )){
            $msg_error[] = gText('field_phone_starts_with_05');
        }else if(!preg_match('/^[0-9]{10}+$/', $phone)){
            $msg_error[] = gText('field_phone_10_number');
        }

        if($msg_error == null):
            //update the trainee information.
            if($student_id){

                    $sql = "UPDATE `students` SET "
                            . "`coop_department`= '$coop_department',"
                            . "`arabic_name`= '$arabic_name',"
                            . "`english_name`= '$english_name',"
                            . "`university_id`= '$university_id',"
                            . "`identity`= '$identity',"
                            . "`semester`= '$semester',"
                            . "`email`= '$email',"
                            . "`year`= '$year',"
                            . "`major`='$major' ,"
                            . "`start_date`='$start_date',"
                            . "`end_date`='$end_date',"
                            . "`training_period`='$training_period',"
                            . "`phone`='$phone',"
                            . "`skills`='$skills',"
                            . "`supervisor_id`= $supervisor_id ,"
                            . "`coop_id`= $coop_id ,"
                            . "`college_id`= $college_id "
                            . "WHERE student_id = $student_id";

                    if(update($sql)){
                        redirect_to("index.php?msg=update");
                    }else{
                    echo Alert(gText("msg_record_nothing_update"),2);        
                    }

            }else{

                //Add the trainee information.
                 $sql = "INSERT INTO `students` (`student_id`, `coop_department`, `arabic_name`, `english_name`, `university_id`, `identity`, `semester`, `email`, `year`, `major`, `start_date`, `end_date`, `training_period`, `phone`, `skills`, `supervisor_id`, `coop_id`, `college_id`) "
                . "VALUES "
                . "(NULL, '$coop_department', '$arabic_name', '$english_name', '$university_id', '$identity', '$semester', '$email', '$year', '$major', '$start_date', '$end_date', '$training_period', '$phone', '$skills', $supervisor_id, $coop_id, $college_id)";
        if(insert($sql)){
            redirect_to("index.php?msg=add");
        }else{
           echo Alert(gText("Error"),4);      
        }

            }

        else:

            echo Alert($msg_error[0],4);    
        endif;
            
        
        }
        ?>

    <script type="text/javascript">

    //set date picker
        $(function () {

             $("#start_date").hijriDatePicker({
                hijri:true,
                showSwitcher:false
            });
            
             $("#end_date").hijriDatePicker({
                hijri:true,
                showSwitcher:false
            });

        });

   
    </script>