<!--add and edit a department --> 
<?PHP
$department_id = req('department_id');

if($department_id){
    $department = getDepartments($department_id)[0];
    
}

$department_id = isset($department['department_id'])? $department['department_id'] : req('department_id');
$department_name = isset($department['department_name'])? $department['department_name'] : req('department_name');



if(isset($_GET['remove_id'])){
    $remove_id = req('remove_id');
    if(delete("DELETE FROM `departments` WHERE department_id = '$remove_id'")){
        redirect_to("index.php?do=departments&msg=remove");
    }
}

?>
<div class="wrapper">
    <div class="container-fluid mt-3">
        <div class="text-left">
            <div id="alert_msg"></div>
        </div>
        
        <div class="row mt-2">
            <div class="col-12">
                <div class="card-box">
                    <h4 class="m-t-0 header-title"><?= gText(($department_id)?"edit_department": "add_new_department")?></h4>
                    
                    <form class="form-horizontal" role="form" method="post">
                        <div class="row">
                            <div class="col-5">
                                <div class="p-20">
                                    
                                    <div class="form-group row">
                                        <label class="col-3 col-form-label"><?= gText("department_name")?><small class="float-right text-danger fa fa-star"></small></label>
                                        <div class="col-9">
                                            <input type="text" name="department_name" id="department_name"  class="form-control" value="<?=$department_name?>">
                                        </div>
                                    </div>
                                
                                    
                                    <div class="form-group row">
                                        <label class="col-3 col-form-label">&nbsp;</label>
                                        <button type="submit" name="process" id="process" class="btn btn-success"><?=($department_id)? gText("update") : gText("add")?></button>
                                    </div>

                                    </div>      
                                </div>
                            </div>
                          </form>
                            <!-- end row -->

                        </div> <!-- end card-box -->
                    </div><!-- end col -->
                </div>
                <!-- end row -->
                
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->
<?PHP
        
    if(isset($_POST['process'])){

    $department_name =  req('department_name');

    $msg_error = NULL;
        //Strip whitespace from the beginning and end of a string    
        if(!trim($department_name))
            $msg_error[] = gText("field_department_name_empty");

        if($msg_error == null):

            if($department_id){

                    $sql = "UPDATE `departments` SET "
                            . "`department_name`= '$department_name'"
                            . "WHERE department_id = $department_id";

                    if(update($sql)){
                        redirect_to("index.php?do=departments&msg=update&msg=update");
                    }else{
                    echo Alert(gText("msg_record_nothing_update"),2);        
                    }

            }else{
                
                $sql = "INSERT INTO `departments` (`department_id`, `department_name`) VALUES (NULL, '$department_name')";

                if(insert($sql)){
                    redirect_to("index.php?do=departments&msg=add");
                }else{
                    echo Alert(gText("Error"),4);        
                }

            }

        else:
            echo Alert($msg_error[0],4);    
        endif;
            
        
        }
        ?>