<?PHP

if(isset($_GET['remove_id'])){
    
    $file_id = req('remove_id');
    $file_type = req('file_type');
    $student_id = req('student_id');
 
    $file = getRow("SELECT * FROM `files` WHERE `file_id` = '$file_id' ");
    unlink("uploads/" . $file['file']);
    
    delete("DELETE FROM `files` WHERE `files`.`file_id` = '".$file['file_id']."' ");
    
    if($file_type){
      redirect_to("index.php?do=student-profile&student_id=".$file['student_id']."&types=$file_type&msg=remove");  
    }else{
      redirect_to("index.php?do=myfiles&msg=remove");  
    }

    
}


    $file_id = req('file_id');
    
    if($file_id){
        $file = getRow("SELECT * FROM files Where file_id = '$file_id' ");
    ?>


<div class="wrapper">
    <div class="container-fluid mt-3">
        <div class="text-left">
            <div id="alert_msg"></div>
        </div>
  
        <?PHP
        
        if(isset($_POST['doUpdate'])){
            
            $file_id = req('doUpdate');
            $file_name = req('file_name');
            $file_type = req('file_type');
            $file = getRow("SELECT * FROM files Where file_id = '$file_id' ");

        if(update("UPDATE `files` SET `file_name` = '$file_name' WHERE `files`.`file_id` = '$file_id';")){
            
            if($file_type){
                redirect_to("index.php?do=student-profile&student_id=".$file['student_id']."&types=$file_type&msg=update");     
            }else{
                redirect_to("index.php?do=myfiles&msg=update"); 
            }

        }else{
            echo Alert(gText("msg_record_nothing_update"),2);    
        }
        }
        ?>
        <div class="row mt-2">
            <div class="col-12 ">
                <div class="card-box ">
                    <h4 class="m-t-0 header-title"><?= gText("edit_file_name")?></h4>
                    
                    <form class="form-horizontal" role="form" method="post">
                        <div class="row">
                            <div class="col-12 col-lg-12 ">
                                <div class="p-20">
                         
                                    <div class="form-group row">
                                        <label class="col-lg-1  col-form-label"><?= gText("file_name")?></label>
                                        <div class="col-lg-2 col-12">
                                            <input type="text" name="file_name" id="file_name"  class="form-control" value="<?=$file['file_name']?>" required="">
                                                
                                        </div>
                                     
                                  
                                      
                                    </div>
                             <div class="form-group row">
                                 <label class="col-lg-1  col-form-label">&nbsp;</label>
                                        <div class="col-lg-2 col-12">
                                                   <button type="submit" name="doUpdate" id="doUpdate" value="<?=$file['file_id']?>" class="btn btn-success col-lg-4 col-12 "><?=gText("update")?></button>
                                        </div>
                             </div>

                                    </div>      
                                </div>
                            </div>
                          </form>
                            <!-- end row -->

                        </div> <!-- end card-box -->
                    </div><!-- end col -->
                </div>
                <!-- end row -->
                
            </div> <!-- end container -->
        </div>


    <?PHP }?>