<?PHP

$student_id = req('student_id');
if(!$student_id)
    redirect_to(".");

$student = getStudentsByWhere(" AND `student_id` = '$student_id'")[0];

$types = req('types');




if(isset($_POST['doSubmit'])){
    
    $target_dir = "uploads/";
    $temp = explode(".", $_FILES["fileToUpload"]["name"]);
    $newfilename = round(microtime(true)) . '.' . end($temp);

  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_dir . $newfilename)) {
      
      $student_id  = req('student_id');
      $file_name  = req('file_name');
      $file = $newfilename;
      $types  = req('types');
      $created_at = date('Y-m-d H:i:s');
      

      
      $sql = "INSERT INTO `files` (`file_id`, `student_id`, `types`, `file_name`, `file`, `created_at`) VALUES (NULL, '$student_id', '". gText('types_'.$types)."', '$file_name', '$file', '$created_at')";
    
      if(insert($sql)){
      redirect_to("index.php?do=student-profile&student_id=$student_id&types=$types&msg=add");    
      }
     
  } else {
    echo "Sorry, there was an error uploading your file.";
  }

}

?>        
<div class="wrapper">
            <div class="container-fluid">

    
                
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        &nbsp;
                    </div>
                </div>
                <!-- end page title end breadcrumb -->
                   <div class="text-left">
            <div id="alert_msg"></div>
        </div>
        <?PHP print_MSG();?>
                
                <div class="row">
       
               
                    <div class="col-lg-12 col-xl-12 ">
                        <div class="">
                            <div class="card-box">
                                <h4 class="m-t-0 header-title"><?=$student['arabic_name']?></h4>
                            <p class="text-muted m-b-30 font-14">
                                <span id="sub-title"><?=($types)? gText($types) : gText("informations");?></span>
                            </p>
                            
                                <ul class="nav nav-tabs tabs-bordered">
                                    <li class="nav-item">
                                        <a href="#informations" onclick="$('#sub-title').html('<?=gText("informations");?>')" data-toggle="tab" aria-expanded="true" class="nav-link <?=(!$types)? 'active show' : ''?>"><?=gText("informations");?>
                                        </a>
                                    </li>
                                    
                                    <?PHP foreach (getTypes() as $item){?>
                                    <li class="nav-item">
                                        <a href="#<?=$item?>" onclick="$('#sub-title').html('<?=gText("$item");?>')"  data-toggle="tab" aria-expanded="false" class="nav-link <?=($types == $item)? 'active show' : ''?>"><?=gText($item);?>
                                        </a>
                                    </li>
                                    <?PHP }?>

                                </ul>
                        
                            
                                <div class="tab-content">
                                   
                                    <div class="tab-pane <?=(!$types)? 'active show' : ''?>" id="informations">
                                        <?PHP include 'student-informations.php';?>
                                    </div>
                                    
                                     <?PHP foreach (getTypes() as $type){?>
                                    <div class="tab-pane <?=($types == $type)? 'active show' : ''?>" id="<?=$type?>">
                                       <?PHP

                                        include 'files-table.php';
                                        ?>
                                    </div>
                                    <?PHP }?>
                                    
                       
                                    
                                </div>
                            </div>
                        </div>

                    </div> <!-- end col -->
                </div>
                <!-- end row -->

            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->