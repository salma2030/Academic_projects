<?PHP

include 'init.php';

include 'header.php';

$do = req('do');

if(isset($do) && $do){
    
        $file =   $do .'.php';
        if (file_exists($file)) {
            include $file;
        }else{
            redirect_to("index.php");
        }
}else{
    include 'home.php';
}
include 'footer.php';
?>

