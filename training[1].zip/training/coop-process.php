<!--add and edit a coop --> 
<?PHP
$coop_id = req('coop_id');

if($coop_id){
    $coop = getCoops($coop_id)[0];   
}

$coop_id = isset($coop['coop_id'])? $coop['coop_id'] : req('coop_id');
$coop_name = isset($coop['coop_name'])? $coop['coop_name'] : req('coop_name');
$coop_email = isset($coop['coop_email'])? $coop['coop_email'] : req('coop_email');
$coop_phone = isset($coop['coop_phone'])? $coop['coop_phone'] : req('coop_phone');


if(isset($_GET['remove_id'])){
    $remove_id = req('remove_id');
    if(delete("DELETE FROM `coops` WHERE coop_id = '$remove_id'")){
        redirect_to("index.php?do=coops&msg=remove");
    }
}

?>
,,,,,
<div class="wrapper">
    
    <div class="container-fluid mt-3">

        <div class="text-left">
            <div id="alert_msg"></div>
        </div>
       
        <div class="row mt-2">
            <div class="col-12">
                <div class="card-box">
                    <h4 class="m-t-0 header-title"><?= gText(($coop_id)?"edit_coop" : "add_new_coop")?></h4>
                    
                    <form class="form-horizontal" role="form" method="post">
                        <div class="row">
                            <div class="col-5">
                                <div class="p-20">
                            
                                    <div class="form-group row">
                                        <label class="col-4 col-form-label"><?= gText("coop_name")?><small class="float-right text-danger fa fa-star"></small></label>
                                        <div class="col-8">
                                            <input type="text" name="coop_name" id="coop_name"  class="form-control" value="<?=$coop_name?>" required="">
                                        </div>
                                    </div>
                                       
                                    <div class="form-group row">
                                        <label class="col-4 col-form-label"><?= gText("email")?>&nbsp;<small class="float-right text-danger fa fa-star"></small></label>
                                        <div class="col-8">
                                            <input type="email" name="coop_email" id="coop_email"  class="form-control" value="<?=$coop_email?>">
                                        </div>
                                    </div>
                                    
                                     <div class="form-group row">
                                        <label class="col-4 col-form-label"><?= gText("phone")?></label>
                                        <div class="col-8">
                                            <input type="text" name="coop_phone" id="coop_phone"  class="form-control" value="<?=$coop_phone?>">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group row">
                                        <label class="col-3 col-form-label">&nbsp;</label>
                                        <button type="submit" name="process" id="process" class="btn btn-success"><?=($coop_id)? gText("update") : gText("add")?></button>
                                    </div>

                                    </div>      
                                </div>
                            </div>
                          </form>
                            <!-- end row -->

                        </div> <!-- end card-box -->
                    </div><!-- end col -->
                </div>
                <!-- end row -->
                
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->
<?PHP
        
    if(isset($_POST['process'])){

$coop_name =  req('coop_name');
$coop_email =  req('coop_email');
$coop_phone =  req('coop_phone');
    
    $msg_error = NULL;
          //set error messages for Coop name.   
        if(!$coop_name)
            $msg_error[] = gText("field_coop_name_empty");
        //set error messages for Coop email. 
        if(!$coop_email)
            $msg_error[] = gText("field_email_empty");
        
        if($msg_error == null):

            if($coop_id){
                    //update the Coop information.
                    $sql = "UPDATE `coops` SET "
                            . "`coop_name`= '$coop_name',"
                            . "`coop_email`= '$coop_email', "
                            . "`coop_phone`= '$coop_phone' "
                            . "WHERE coop_id = $coop_id ";

                    if(update($sql)){
                    redirect_to("index.php?do=coops&msg=update");
                    }else{
                    echo Alert(gText("msg_record_nothing_update"),2);        
                    }

            }else{
                
                $sql = "INSERT INTO `coops` (`coop_id`, `coop_name`, `coop_email`, `coop_phone`) VALUES (NULL, '$coop_name', '$coop_email', '$coop_phone')";

                if(insert($sql)){
                    redirect_to("index.php?do=coops&msg=add");
                }else{
                    echo Alert(gText("Error"),4);        
                }

            }

        else:
            echo Alert($msg_error[0],4);    
        endif;
            
        
        }
        ?>