<!--add and edit a supervisor --> 
<?PHP
$supervisor_id = req('supervisor_id');

if($supervisor_id){
    $supervisor = getSupervisors($supervisor_id)[0];
    
}

$supervisor_id = isset($supervisor['supervisor_id'])? $supervisor['supervisor_id'] : req('supervisor_id');
$supervisor_name = isset($supervisor['supervisor_name'])? $supervisor['supervisor_name'] : req('supervisor_name');
$supervisor_email = isset($supervisor['supervisor_email'])? $supervisor['supervisor_email'] : req('supervisor_email');
$supervisor_phone = isset($supervisor['supervisor_phone'])? $supervisor['supervisor_phone'] : req('supervisor_phone');


if(isset($_GET['remove_id'])){
    $remove_id = req('remove_id');
    if(delete("DELETE FROM `supervisors` WHERE supervisor_id = '$remove_id'")){
        redirect_to("index.php?do=supervisors&msg=remove");
    }
}

?>
<div class="wrapper">
    <div class="container-fluid mt-3">
        <div class="text-left">
            <div id="alert_msg"></div>
        </div>
        
        <div class="row mt-2">
            <div class="col-12">
                <div class="card-box">
                    <h4 class="m-t-0 header-title"><?= gText(($supervisor_id)?"edit_supervisor" : "add_new_supervisor")?></h4>
                    
                    <form class="form-horizontal" role="form" method="post">
                        <div class="row">
                            <div class="col-5">
                                <div class="p-20">
                                    
                                    <div class="form-group row">
                                        <label class="col-4 col-form-label"><?= gText("supervisor_name")?><small class="float-right text-danger fa fa-star"></small></label>
                                        <div class="col-8">
                                            <input type="text" name="supervisor_name" id="supervisor_name"  class="form-control" value="<?=$supervisor_name?>" required="">
                                        </div>
                                    </div>
                                       
                                    <div class="form-group row">
                                        <label class="col-4 col-form-label"><?= gText("email")?>&nbsp;<small class="float-right text-danger fa fa-star"></small></label>
                                        <div class="col-8">
                                            <input type="email" name="supervisor_email" id="supervisor_email"  class="form-control" value="<?=$supervisor_email?>">
                                        </div>
                                    </div>
                                    
                                     <div class="form-group row">
                                        <label class="col-4 col-form-label"><?= gText("phone")?></label>
                                        <div class="col-8">
                                            <input type="text" name="supervisor_phone" id="supervisor_phone"  class="form-control" value="<?=$supervisor_phone?>">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group row">
                                        <label class="col-3 col-form-label">&nbsp;</label>
                                        <button type="submit" name="process" id="process" class="btn btn-success"><?=($supervisor_id)? gText("update") : gText("add")?></button>
                                    </div>

                                    </div>      
                                </div>
                            </div>
                          </form>
                            <!-- end row -->

                        </div> <!-- end card-box -->
                    </div><!-- end col -->
                </div>
                <!-- end row -->
                
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->
<?PHP
        
    if(isset($_POST['process'])){

$supervisor_name =  req('supervisor_name');
$supervisor_email =  req('supervisor_email');
$supervisor_phone =  req('supervisor_phone');
    
    $msg_error = NULL;
          //set error messages for supervisor name.   
        if(!$supervisor_name)
            $msg_error[] = gText("field_supervisor_name_empty");
        //set error messages for supervisor email. 
        if(!$supervisor_email)
            $msg_error[] = gText("field_email_empty");
        
        if($msg_error == null):

            if($supervisor_id){
                    //update the supervisor information.
                    $sql = "UPDATE `supervisors` SET "
                            . "`supervisor_name`= '$supervisor_name',"
                            . "`supervisor_email`= '$supervisor_email', "
                            . "`supervisor_phone`= '$supervisor_phone' "
                            . "WHERE supervisor_id = $supervisor_id ";

                    if(update($sql)){
                    redirect_to("index.php?do=supervisors&msg=update");
                    }else{
                    echo Alert(gText("msg_record_nothing_update"),2);        
                    }

            }else{
                
                $sql = "INSERT INTO `supervisors` (`supervisor_id`, `supervisor_name`, `supervisor_email`, `supervisor_phone`) VALUES (NULL, '$supervisor_name', '$supervisor_email', '$supervisor_phone')";

                if(insert($sql)){
                    redirect_to("index.php?do=supervisors&msg=add");
                }else{
                    echo Alert(gText("Error"),4);        
                }

            }

        else:
            echo Alert($msg_error[0],4);    
        endif;
            
        
        }
        ?>