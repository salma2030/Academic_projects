<?php

/*This function navigates to the desired location*/
 function redirect_to($location)
    {
    if (!headers_sent()) {
        header('Location: ' . $location);
                exit;
        } else
        echo '<script type="text/javascript">';
        echo 'window.location.href="' . $location . '";';
        echo '</script>';
        echo '<noscript>';
        echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
        echo '</noscript>';
    }
    
/*This function get value from url : $_GET or $_POST*/
    function req($key = "" ){
      return (isset($_REQUEST[$key]) && $_REQUEST[$key])? $_REQUEST[$key] : null; //if (not null is sent)>get that value, else>return null
    }
    
 /*This function get arabic value from lang_ar.ini file */
    function gText($text = "" ){
        $lang = parse_ini_file("lang_ar.ini");
        return (isset($lang[$text]))? $lang[$text] : ucfirst($text); ////if there a value for $lang[$text] print it, otherwise Convert the first character of "text" to uppercase using ucfirst()
    }

/*This function retrieve  one row from database */
    function getRows($sql_query = ""){
        global $con; //global>imports variables from the global scope into the local scope of a function.
        $result = mysqli_query($con,$sql_query);
        return ($result)? mysqli_fetch_all($result, MYSQLI_ASSOC) : null;
    }
    
/*This function retrieve all rows from database */
    function getRow($sql_query = ""){
           
    $result = getRows($sql_query);
   
    return ($result)?$result[0] : NULL;
    }

/*This function retrieve all rows from database */
   function getValue($what = "",$table = "", $where = "" ){
       $row = null;
    if($what && $table && $where){
        $sql = "SELECT $what From $table Where $where ";
        $row = getRow($sql);
    }
     return ($row)? $row[$what] : NULL;
   }
   
/*This function add new record to database by $sql */
   function insert($sql = ""){

    if($sql){
        global $con;
        if (mysqli_query($con, $sql)) {
               return $con->insert_id;
        }else{
            return 0;
        }
    }
   }
   
/*This function remove any records from database by $sql */
    function delete($sql = ""){

    if($sql){
        global $con;
          mysqli_query($con, $sql);
        if (mysqli_affected_rows($con)) {
               return TRUE;
        }else{
            return FALSE;
        }
    }
    
   }
   
/*This function update any records from database by $sql */
    function update($sql = ""){

    if($sql){
        global $con;
        mysqli_query($con, $sql);
              
        if (mysqli_affected_rows($con)) {
           
            return TRUE;
        }else{

            return FALSE;
        }
    }
    
   }

/*This function get all types of files as array() */
    function getTypes(){
        $ar = array('reporting', 'forms', 'activities', 'projects');
        return $ar;
    }

/*This function get color class from css by $color number */
    function getColor($color = 0){
              switch ($color){
            case 1:
                return "primary";
                break;
            case 2:
                 return "secondary";
                break;
            case 3:
                  return "warning";
                break;
            case 4:
                  return"danger";
                break;
            case 5:
                  return "success";
                break;
            case 6:
                 return "info";
                break;
            case 7:
                 return "light";
                break;
            case 8:
                 return "dark";
                break;
            
          }
         }

/*This function print alert */
    function Alert($title = "", $color = 0){
         
       $out = "
           <script>
                $('#alert_msg').html('$title');
                $('#alert_msg').attr('class', 'alert alert-".getColor($color)."');
                setTimeout(function() { $('#alert_msg').slideUp(); }, 5000);
            </script>";
       
       return $out;
      }

/*This function print msg */
       function print_MSG(){
         
           switch (req("msg")){
        case 'add':
            echo Alert(gText("msg_record_has_been_add"), 5);
            break;
         case 'update':
            echo Alert(gText("msg_record_has_been_update"), 3);
            break;
        case 'remove':
            echo Alert(gText("msg_record_has_been_remove"), 4);
            break;
            }
      }
      
/*This function get starts With letter from string */
    function startsWith ($string, $startString){
        $len = strlen($startString);
    return (substr($string, 0, $len) === $startString);
    }
//the ID will be passed when editing information, and a specific information (one row) for that college will be retrieved
//the ID will not be passed when adding information, and all rows of the colleges will be retrieved
/*This function retrieve Colleges */
    function getColleges($college_id = ""){
        if($college_id)
            $college_id = " AND college_id = '$college_id' ";
        return getRows("SELECT * FROM `colleges` Where 1 $college_id");
    }
    
/*This function retrieve Supervisors */
    function getSupervisors($supervisor_id = ""){
    if($supervisor_id)
        $supervisor_id = " AND supervisor_id = '$supervisor_id' ";
    return getRows("SELECT * FROM `supervisors` Where 1 $supervisor_id");
    }
    
/*This function retrieve Supervisors-Coops */
    function getCoops($coop_id = ""){
         if($coop_id)
        $coop_id = " AND coop_id = '$coop_id' ";
    return getRows("SELECT * FROM `coops` Where 1 $coop_id");
    }
    
/*This function retrieve Departments */
    function getDepartments($department_id = ""){
    if($department_id)
        $department_id = " AND department_id IN($department_id) ";
    return getRows("SELECT * FROM `departments` Where 1 $department_id");
    }


/*This function retrieve Students */
    function getStudentsByWhere($where = ""){

    return getRows("SELECT * FROM `students` 
        LEFT JOIN colleges ON colleges.college_id = students.college_id
        LEFT JOIN supervisors ON supervisors.supervisor_id = students.supervisor_id 
        LEFT JOIN coops ON coops.coop_id = students.coop_id 
        Where 1 $where ORDER BY student_id ASC");
    }
    
/*This function retrieve Files */
    function getFiles($file_id = ""){
        if($file_id)
            $file_id = " AND file_id = '$file_id' ";
        return getRows("SELECT * FROM `files` Where 1 $file_id");
    }
    
    
/*This function convert date from Gregorian To Hijri */
    function getH2G($date = ""){
        
           $time=strtotime($date); //used to convert an English textual date-time description to a UNIX timestamp

        $year = date("Y",$time);
        $month = date("m",$time);
        $day = date("d",$time);
        
        $date = new hijri\Calendar();
   
        $full_date =  $date->GregorianToHijri($year, $month, $day);
 
        return  $full_date['y'].'/'.$full_date['m'].'/'.$full_date['d'];
    }

/*This function convert date from Hijri To Gregorian */
      function getG2H($string = ""){
        
        $time=strtotime($string);

        $year = date("Y",$time);
        $month = date("m",$time);
        $day = date("d",$time);
        
        $date = new hijri\Calendar();

        $full_date =  $date->HijriToGregorian($year, $month, $day);
        return  $full_date['y'].'-'.$full_date['m'].'-'.$full_date['d'];
    }
    
    