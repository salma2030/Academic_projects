<?PHP //main page> search, delete

$columns = array('arabic_name', 'english_name', 'university_id', 'identity', 'semester', 'email', 'year', 'major', 'training_period', 'phone', 'skills');
$supervisors = getSupervisors();
$coops = getCoops();
$colleges = getColleges();

$supervisor_id = req('supervisor_id');
$coop_id = req('coop_id');
$college_id = req('college_id');
$column = req('column');
$text = req('text');
$where = "";

if($column){
    
    if($text){
        
    switch ($column):
        case 'arabic_name';
        case 'english_name';
        case 'skills';
        case 'major';
        case 'training_period';
               $where .= " AND `$column` LIKE '%$text%' ";
            break;
        default :
               $where .= " AND `$column` = '$text' ";
            break;
    endswitch;
    }

}

    if($supervisor_id){
        $where .= " AND students.`supervisor_id` = '$supervisor_id' ";
     }
     
     if($coop_id){
        $where .= " AND students.`coop_id` = '$coop_id' ";
     }
     
    
    if($college_id){
        $where .= " AND colleges.`college_id` = '$college_id' ";
    }

    $students = getStudentsByWhere($where);  
    //remove students
    if(isset($_GET['remove_id'])){
        $remove_id = req('remove_id');
        
        $files = getRows("SELECT * FROM `files` WHERE `student_id` = '$remove_id'");

        if(delete("DELETE FROM `students` WHERE `students`.`student_id` = '$remove_id'")){
         
            foreach ($files as $file):
                unlink("uploads/" . $file['file']); //delete files as well
            endforeach;
            
            redirect_to("index.php?msg=remove");
        }
   
    }


?>
<div class="wrapper">
       <form method="get">
    <div class="container-fluid mt-3">
        <div class="text-left">
            <div id="alert_msg"></div>
        </div>
     
        <?PHP print_MSG(); ?>
        <div class="row">
                    <div class="col-12">
                        <div class="card-box">
                            <h4 class="text-dark p-3 header-title m-t-0"><i class="ti-list"></i> <?= gText("list_of_students")?> <a href="index.php?do=student-process" class="float-right btn btn-primary btn-rounded  waves-effect waves-light "><i class="ti-plus" title="<?= gText("add_new_student")?>"></i></a></h4>
                            <hr>
                            
                                <div class="form-inline m-b-20">
                                   
                                        <div class="col-md-12">
                                            <div class="form-group">
                                             
                                                    <select name="column" id="column" class="form-control">
                                                    <option value=""><?= gText("show_all")?></option>
                                                    <?PHP
                                                       foreach ($columns as $item){
                                                    ?>
                                                    <option value="<?=$item?>" <?=($column == $item)? 'selected=""' : ''?> ><?= gText($item)?></option>
                                                       <?PHP }?>
                                              
                                                </select>
                                                    <input name="text" id="text" type="text" placeholder="<?= gText("search")?>" value="<?=$text?>" class="form-control mr-2" autocomplete="on">
                                                    <button type="submit" class="btn btn-primary mr-2"><?= gText("search")?></button>
                                                        
                                            </div>
                                            
                                        </div>
                                 
                                
                                </div>
                            
                            <table id="demo-foo-filtering" class="table table-striped table-bordered toggle-circle m-b-0" data-page-size="7">
                               
                                <thead>
                                   <tr>
                                        <th width="25">#</th>
                                        <th><?= gText("student_name")?></th>
                                        <th> 
                                            <select class="form-control" onchange="submit()" name="supervisor_id">
                                                <option value=""><?= gText("supervisor_name")?></option>
                                                <?PHP 
                                                if($supervisors){

                                                foreach ($supervisors as $supervisor):
                                                $selected = ($supervisor['supervisor_id'] == $supervisor_id)? 'selected=""' : '';
                                                echo "<option value='".$supervisor['supervisor_id']."' $selected >".$supervisor['supervisor_name']."</option>";
                                                endforeach;
                                                
                                                }
                                                ?>
                                                
                                            </select>
                                               
                                        </th>
                                        
                                             <th> 
                                            <select class="form-control" onchange="submit()" name="coop_id">
                                                <option value=""><?= gText("coop_name")?></option>
                                                <?PHP 
                                                if($coops){

                                                foreach ($coops as $coop):
                                                $selected = ($coop['coop_id'] == $coop_id)? 'selected=""' : '';
                                                echo "<option value='".$coop['coop_id']."' $selected >".$coop['coop_name']."</option>";
                                                endforeach;
                                                
                                                }
                                                ?>
                                                
                                            </select>
                                               
                                        </th>
                                        
                                        
                                        <th>
                                                  <select class="form-control" onchange="submit()" name="college_id">
                                                <option value=""><?= gText("college")?></option>
                                                <?PHP 
                                                if($colleges){

                                                foreach ($colleges as $college):
                                                $selected = ($college['college_id'] == $college_id)? 'selected=""' : '';
                                                echo "<option value='".$college['college_id']."' $selected >".$college['college_name']."</option>";
                                                endforeach;
                                                
                                                }
                                                ?>
                                    
                                            </select>
                                        </th>
                                        <th><?= gText("major")?></th>
                                        <th><?= gText("year")?></th>
                                       
                                    </tr>
                                </thead>
                                <tbody>
                                            <?PHP 
                                            if($students){
                                            foreach ($students as $student){?>
                                    <tr>
                                        <td>
                                        <div class="dropdown">
                                            <button class="btn btn-primary btn-block  dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fa fa-fw fa-cog"></i> <?=$student['student_id']?>
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            
                                            <a class="dropdown-item" href="index.php?do=student-profile&student_id=<?=$student['student_id']?>"><i class="fa fa-fw fa-list"></i> <?= gText("details")?></a>
                                            <a class="dropdown-item" href="index.php?do=student-process&student_id=<?=$student['student_id']?>"><i class="fa fa-fw fa-edit text-primary"></i> <?= gText("edit")?></a>
                                            <a class="dropdown-item" href="index.php?remove_id=<?=$student['student_id']?>"><i class="fa fa-fw fa-trash-o text-danger"></i> <?= gText("remove")?></a>

                                        </div>
                                        </div>
                                        </td>
                                        <td><a class="text-primary" href="index.php?do=student-profile&student_id=<?=$student['student_id']?>"><?=$student['arabic_name']?></a></td>
                                        <td><?=$student['supervisor_name']?></td>
                                        <td><?=$student['coop_name']?></td>
                                        <td><?=$student['college_name']?></td>
                                        <td><?=$student['major']?></td>
                                        <td><?=$student['year']?></td>
                                      
                                    </tr>
                                            <?PHP }}?>
                               
                                </tbody>
                            
                            </table>
                        </div>
                    </div>
                </div>

    </div> <!-- end container -->
       </form>
</div>
<!-- end wrapper -->