<?PHP 

    $columns = array('college_name', 'college_location');

    $column = req('column');

    $text = req('text');
    $where = "";
    
    if($column){
        if($text){
                  $where .= " AND `$column` LIKE '%$text%' ";
        }
    }
   $colleges = getRows("SELECT * FROM `colleges` Where 1 $where"); 
?>

<div class="wrapper">
    <form method="get" >
        <input type="hidden" name="do" id="do" value="<?= req('do')?>"/>
    <div class="container-fluid mt-3">
        <div class="text-left">
            <div id="alert_msg"></div>
        </div>
       <?PHP print_MSG();?>
        <div class="row">
            <div class="col-12">
                <div class="card-box">
                    <h4 class="text-dark p-3 header-title m-t-0"><i class="ti-layout-column2-alt"></i> <?= gText("list_of_colleges")?> <a href="index.php?do=college-process" class="float-right btn btn-primary btn-rounded  waves-effect waves-light "><i class="ti-plus" title="<?= gText("add_new_college")?>"></i></a></h4>
                    <hr>
                    <table id="demo-foo-filtering" class="table table-striped table-bordered toggle-circle m-b-0" data-page-size="7">
                        <thead>
                           <tr>
                                <th width="25">#</th>
                              <th><?= gText("college_name")?></th>
                                <th><?= gText("college_location")?></th>
                            </tr>
                        </thead>
                            <div class="form-inline m-b-20">

                                <div class="col-md-12">
                                    <div class="form-group">

                                        <select name="column" id="column" class="form-control">
                                            <option value=""><?= gText("show_all")?></option>

                                            <?PHP foreach ($columns as $item){?>
                                                <option value="<?=$item?>" <?=($column == $item)? 'selected=""' : ''?> ><?= gText($item)?></option>
                                            <?PHP }?>

                                        </select>
                                        
                                            <input name="text" id="text" type="text" placeholder="<?= gText("search")?>" value="<?=$text?>" class="form-control mr-2" autocomplete="on">
                                              <button type="submit" class="btn btn-primary mr-2"><?= gText("search")?></button>
                                    </div>

                                </div>


                        </div>
                        <tbody>
                                     <?PHP 
                                    if($colleges){ 
                                        foreach ($colleges as $college){?>
                            <tr>
                                    <td>
                                        <div class="dropdown">
                                        <button class="btn btn-primary btn-block  dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fa fa-fw fa-cog"></i> <?=$college['college_id']?>
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">

                                            <a class="dropdown-item" href="index.php?do=college-process&college_id=<?=$college['college_id']?>"><i class="fa fa-fw fa-edit text-primary"></i> <?= gText("edit")?></a>
                                            <a class="dropdown-item" href="index.php?do=college-process&remove_id=<?=$college['college_id']?>"><i class="fa fa-fw fa-trash-o text-danger"></i> <?= gText("remove")?></a>

                                        </div>
                                        </div>
                                        </td>
                                        <td><a class="text-primary" href="index.php?do=college-process&college_id=<?=$college['college_id']?>"><?=$college['college_name']?></a></td>
                                <td><?=$college['college_location']?></td>

                            </tr>
                                    <?PHP }}?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>

    </div> <!-- end container -->
    </form>
</div>
<!-- end wrapper -->