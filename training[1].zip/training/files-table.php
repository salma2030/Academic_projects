<?PHP 


  
$text = req('text');
$where = "";

if($text)
$where .= " AND file_name LIKE '%$text%'";

$files = getRows("SELECT * FROM `files` Where student_id = '$student_id' AND types = '". gText('types_'.$type)."' $where");

?>



    <form method="get" >
        <input type="hidden" name="do" id="do" value="<?= req('do')?>"/>
        <input type="hidden" name="student_id" id="student_id" value="<?= req('student_id')?>"/>
        <input type="hidden" name="types" id="types" value="<?= $type?>"/>
<div class="row">
                                        
                                             
                                       
                                                
                                                <div class="col-md-2">
                                            <div class="form-group">
                                                <input name="text" id="text" type="text" placeholder="<?= gText("search")?>" value="<?=$text?>" class="form-control mr-2" autocomplete="on">
                                            
                                                        
                                            </div>
                                            
                                        </div>
    <div class="col-md-4">
        <div class="form-group">
            <button type="submit" class="btn btn-primary mr-2"><?= gText("search")?></button>
            </div>
    </div>
    
      <div class="col-lg-6 ">
                                            <div class="form-group">
                                                <button type="button" class="float-right btn btn-primary btn-rounded  waves-effect waves-light" data-toggle="modal" data-target="#con-close-modal-<?=$type?>"><i class="ti-plus" title="<?= gText("add_new_file")?>"></i></button>
                                            </div>
                                        </div>
    
                                   
                                    </div>
    </form>
                            <table id="demo-foo-filtering" class="table table-striped table-bordered toggle-circle m-b-0 " data-page-size="7">
                                <thead>
                                   <tr>
                                        <th width="25">#</th>
                                      <th><?= gText("file_name")?></th>
                                        <th width="200"><?= gText("created_at")?></th>
                                    </tr>
                                </thead>
                         
                                <tbody>
                                             <?PHP 
                                            if($files){ 
                                                foreach ($files as $file){?>
                                    <tr>
                                            <td>
                                                <div class="dropdown">
                                                <button class="btn btn-primary btn-block  dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fa fa-fw fa-cog"></i> <?=$file['file_id']?>
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                               
                                               
                                                    <a class="dropdown-item" href="index.php?do=file-process&file_id=<?=$file['file_id']?>&file_type=<?=$type?>"><i class="fa fa-fw fa-edit text-primary"></i> <?= gText("edit")?></a>
                                                    
                                                    <a class="dropdown-item" href="index.php?do=file-process&remove_id=<?=$file['file_id']?>&file_type=<?=$type?>"><i class="fa fa-fw fa-trash-o text-danger"></i> <?= gText("remove")?></a>
                                                
                                                </div>
                                                </div>
                                                </td>
                                                
                              
                                                <td><a class="text-primary" href="uploads/<?=$file['file']?>" download><?=$file['file_name']?></a></td>
                                         <td dir="ltr"><?=$file['created_at']?></td>
                          
                                    </tr>
       
                                            <?PHP }}?>
                               
                                </tbody>
                            
                            </table>
              


<?PHP include 'file-modal.php';?>