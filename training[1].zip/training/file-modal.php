
    <div id="con-close-modal-<?=$type?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
        <form  method="post" enctype="multipart/form-data">

            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h4 class="modal-title"><?= gText("upload_file")?></h4>
                    </div>
                    <div class="modal-body">

                        <input type="hidden" name="types" id="types" value="<?=$type?>"/>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="field-1" class="control-label"><?= gText("file_name")?><small class="float-right text-danger fa fa-star"></small></label>
                                    <input type="text" name="file_name" id="file_name" class="form-control" required="">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="field-2" class="control-label"><?= gText("file")?><small class="float-right text-danger fa fa-star"></small></label>
                                    <input type="file" name="fileToUpload" id="fileToUpload" class="form-control" required="">
                                </div>
                            </div>
                        </div>



                    </div>
                    <div class="modal-footer" dir="ltr">
                
                        <button type="submit" name="doSubmit" id="doSubmit" class="btn btn-primary waves-effect waves-light float-left"><?= gText("upload")?></button>
                    </div>
                </div>
                </div>
        </form>
    </div><!-- /.modal -->