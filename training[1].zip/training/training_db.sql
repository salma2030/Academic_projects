-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 13, 2021 at 07:06 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `training_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `colleges`
--

CREATE TABLE `colleges` (
  `college_id` int(11) NOT NULL,
  `college_name` varchar(50) NOT NULL,
  `college_location` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `colleges`
--

INSERT INTO `colleges` (`college_id`, `college_name`, `college_location`) VALUES
(1, 'جامعة الملك فيصل', 'الأحساء'),
(2, 'جامعة الاميرة نورة بنت عبدالرحمن', 'الرياض');

-- --------------------------------------------------------

--
-- Table structure for table `coops`
--

CREATE TABLE `coops` (
  `coop_id` int(11) NOT NULL,
  `coop_name` varchar(50) NOT NULL,
  `coop_email` varchar(50) NOT NULL,
  `coop_phone` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `coops`
--

INSERT INTO `coops` (`coop_id`, `coop_name`, `coop_email`, `coop_phone`) VALUES
(1, 'a', 'a@kfu.edu.sa', '11');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `department_id` int(11) NOT NULL,
  `department_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`department_id`, `department_name`) VALUES
(1, 'الدعم الفني'),
(2, 'تقنيات التعلم'),
(3, 'أنظمة'),
(4, 'شبكات'),
(5, 'خدمات المستفيدين'),
(6, 'نظم'),
(7, 'أعمال إدراية');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `file_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `types` enum('تقرير','نموذج','نشاط','مشروع') DEFAULT NULL,
  `file_name` varchar(50) NOT NULL,
  `file` varchar(30) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `coop_department` varchar(30) NOT NULL,
  `arabic_name` varchar(50) NOT NULL,
  `english_name` varchar(50) NOT NULL,
  `university_id` varchar(9) NOT NULL,
  `identity` varchar(10) NOT NULL,
  `semester` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `year` int(11) NOT NULL,
  `major` varchar(30) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `training_period` varchar(35) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `skills` text NOT NULL,
  `supervisor_id` int(11) DEFAULT NULL,
  `coop_id` int(11) DEFAULT NULL,
  `college_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `coop_department`, `arabic_name`, `english_name`, `university_id`, `identity`, `semester`, `email`, `year`, `major`, `start_date`, `end_date`, `training_period`, `phone`, `skills`, `supervisor_id`, `coop_id`, `college_id`) VALUES
(1, '1,2,4', 'سلمى عبدالله عباس العمر', 'Salma Abdullah Abbas Alomar', '217019858', '1098371881', 'الصيفي', '217019858@student.kfu.edu.sa', 1442, 'علوم حاسب', '2021-05-23', '2021-08-12', '12 أسبوع', '0552007619', 'تصوير، تصميم، برمجة\r\n', 1, 1, 1),
(2, '1,2,4', 'أصالة أحمد شريده البريه', ' Asalah Ahmad Shreeda Albreih', '217027174', '1098144478', 'الصيفي', '217027174@student.kfu.edu.sa', 1442, 'علوم حاسب', '2021-05-23', '2021-08-12', '12 أسبوع', '0535044074', 'التصميم، الرسم، التصوير، برمجة', 1, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `supervisors`
--

CREATE TABLE `supervisors` (
  `supervisor_id` int(11) NOT NULL,
  `supervisor_name` varchar(50) NOT NULL,
  `supervisor_email` varchar(50) NOT NULL,
  `supervisor_phone` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `supervisors`
--

INSERT INTO `supervisors` (`supervisor_id`, `supervisor_name`, `supervisor_email`, `supervisor_phone`) VALUES
(1, 'عيد محمد البلوي', 'ealbalawi@kfu.edu.sa', '0135898884'),
(2, 'عبدالإله القصيبي', 'aaalgosaibi@kfu.edu.sa', '0135898146');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `colleges`
--
ALTER TABLE `colleges`
  ADD PRIMARY KEY (`college_id`);

--
-- Indexes for table `coops`
--
ALTER TABLE `coops`
  ADD PRIMARY KEY (`coop_id`),
  ADD UNIQUE KEY `supervisor_email` (`coop_email`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`),
  ADD UNIQUE KEY `identity` (`identity`),
  ADD KEY `college_id` (`college_id`),
  ADD KEY `supervisor_id` (`supervisor_id`) USING BTREE,
  ADD KEY `coop_id` (`coop_id`);

--
-- Indexes for table `supervisors`
--
ALTER TABLE `supervisors`
  ADD PRIMARY KEY (`supervisor_id`),
  ADD UNIQUE KEY `supervisor_email` (`supervisor_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `colleges`
--
ALTER TABLE `colleges`
  MODIFY `college_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `coops`
--
ALTER TABLE `coops`
  MODIFY `coop_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `supervisors`
--
ALTER TABLE `supervisors`
  MODIFY `supervisor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `files`
--
ALTER TABLE `files`
  ADD CONSTRAINT `files_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_3` FOREIGN KEY (`coop_id`) REFERENCES `coops` (`coop_id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `students_ibfk_4` FOREIGN KEY (`supervisor_id`) REFERENCES `supervisors` (`supervisor_id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `students_ibfk_5` FOREIGN KEY (`college_id`) REFERENCES `colleges` (`college_id`) ON DELETE SET NULL ON UPDATE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
