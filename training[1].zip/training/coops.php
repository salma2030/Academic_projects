<?PHP 

$columns = array('coop_name', 'coop_email', 'coop_phone');

$column = req('column');

$text = req('text');
$where = "";
if($column){
    if($text){
              $where .= " AND `$column` LIKE '%$text%' ";
    }
}
   $coops = getRows("SELECT * FROM `coops` Where 1 $where"); 
?>

<div class="wrapper">
    <form method="get" >
        <input type="hidden" name="do" id="do" value="<?= req('do')?>"/>
    <div class="container-fluid mt-3">
        <div class="text-left">
            <div id="alert_msg"></div>
        </div>
        
        <?PHP print_MSG();?>
        
        <div class="row">
                    <div class="col-12">
                        <div class="card-box">
                            <h4 class="text-dark p-3 header-title m-t-0"><i class="ti-eye"></i> <?= gText("list_of_coops")?> <a href="index.php?do=coop-process" class="float-right btn btn-primary btn-rounded  waves-effect waves-light "><i class="ti-plus" title="<?= gText("add_new_coop")?>"></i></a></h4>
                            <hr>
                            <table id="demo-foo-filtering" class="table table-striped table-bordered toggle-circle m-b-0" data-page-size="7">
                                <thead>
                                   <tr>
                                        <th width="25">#</th>
                                        <th><?= gText("coop_name")?></th>
                                        <th><?= gText("email")?></th>
                                        <th><?= gText("phone")?></th>
                                  
                                    </tr>
                                </thead>
                                   
                                <div class="form-inline m-b-20">
                                   
                                        <div class="col-md-12">
                                            <div class="form-group">
                                             
                                                    <select name="column" id="column" class="form-control">
                                                    <option value=""><?= gText("show_all")?></option>
                                                    <?PHP
                                                       foreach ($columns as $item){
                                                    ?>
                                                    <option value="<?=$item?>" <?=($column == $item)? 'selected=""' : ''?> ><?= gText($item)?></option>
                                                       <?PHP }?>
                                              
                                                </select>
                                                    <input name="text" id="text" type="text" placeholder="<?= gText("search")?>" value="<?=$text?>" class="form-control mr-2" autocomplete="on">
                                                    <button type="submit" class="btn btn-primary mr-2"><?= gText("search")?></button>
                                                        
                                            </div>
                                            
                                        </div>
                                 
                                
                                </div>
                                <tbody>
                                  <?PHP 
                                            if($coops){
                                                
                                             foreach ($coops as $coop){?>
                                    <tr>
                                          <td>
                                                <div class="dropdown">
                                                <button class="btn btn-primary btn-block  dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fa fa-fw fa-cog"></i> <?=$coop['coop_id']?>
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                               
                                                <a class="dropdown-item" href="index.php?do=coop-process&coop_id=<?=$coop['coop_id']?>"><i class="fa fa-fw fa-edit text-primary"></i> <?= gText("edit")?></a>
                                                <a class="dropdown-item" href="index.php?do=coop-process&remove_id=<?=$coop['coop_id']?>"><i class="fa fa-fw fa-trash-o text-danger"></i> <?= gText("remove")?></a>
                                                
                                                </div>
                                                </div>
                                                </td>
                                                
                                      
                                        <td><a class="text-primary" href="index.php?do=coop-process&coop_id=<?=$coop['coop_id']?>"><?=$coop['coop_name']?></a></td>
                                        <td><?=$coop['coop_email']?></td>
                                        <td><?=$coop['coop_phone']?></td>
                          
                                    </tr>
       
                                        <?PHP }} ?>
                               
                                </tbody>
                                <tfoot>
                                <tr class="active">
                                    <td colspan="5">
                                        <div class="text-right">
                                            <ul class="pagination pagination-split justify-content-end footable-pagination m-t-10 m-b-0"></ul>
                                        </div>
                                    </td>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>

    </div> <!-- end container -->
    </form>
</div>
<!-- end wrapper -->