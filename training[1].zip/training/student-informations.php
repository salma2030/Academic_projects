<div class="row">
    <div class="col-12 col-lg-3">
        <div class="p-20">
               <div class="form-group">
                   <label class=" col-form-label"><?= gText("arabic_name")?></label>
                    <p class="form-control-static"><?=$student['arabic_name']?></p>
               </div>
            
                 <div class="form-group">
                   <label class=" col-form-label"><?= gText("university_id")?></label>
                    <p class="form-control-static"><?=$student['university_id']?></p>
               </div>
            
                <div class="form-group">
                   <label class=" col-form-label"><?= gText("semester")?></label>
                    <p class="form-control-static"><?=$student['semester']?></p>
               </div>

              <div class="form-group">
                   <label class=" col-form-label"><?= gText("start_date")?></label>
                    <p class="form-control-static"><?=getH2G($student['start_date'])?></p>
               </div>
            
             <div class="form-group">
                   <label class=" col-form-label"><?= gText("phone")?></label>
                    <p class="form-control-static"><?=$student['phone']?></p>
               </div>
            
        </div>
    </div>

    <div class="col-12 col-lg-3">
        <div class="p-20">

               <div class="form-group">
                    <label class=" col-form-label"><?= gText("english_name")?></label>
                    <p class="form-control-static"><?=$student['english_name']?></p>
               </div>
            
             <div class="form-group">
                    <label class=" col-form-label"><?= gText("identity")?></label>
                    <p class="form-control-static"><?=$student['identity']?></p>
               </div>
            
            <div class="form-group">
                    <label class=" col-form-label"><?= gText("year")?></label>
                    <p class="form-control-static"><?=$student['year']?></p>
               </div>

              <div class="form-group">
                   <label class=" col-form-label"><?= gText("end_date")?></label>
                    <p class="form-control-static"><?=getH2G($student['end_date'])?></p>
               </div>
            
            <div class="form-group">
                   <label class=" col-form-label"><?= gText("skills")?></label>
                    <p class="form-control-static"><?=$student['skills']?></p>
               </div>
            
        </div>
    </div>
    
    <div class="col-12 col-lg-3">
        <div class="p-20">

               <div class="form-group">
                    <label class=" col-form-label"><?= gText("email")?></label>
                    <p class="form-control-static"><?=$student['email']?></p>
               </div>
            
            <div class="form-group">
                    <label class=" col-form-label"><?= gText("major")?></label>
                    <p class="form-control-static"><?=$student['major']?></p>
               </div>

             <div class="form-group">
                    <label class=" col-form-label"><?= gText("training_period")?></label>
                    <p class="form-control-static"><?=$student['training_period']?></p>
               </div>
             
              <div class="form-group">
                    <label class=" col-form-label"><?= gText("departments")?></label>
                    <p class="form-control-static">
                        
                        <?PHP
                        if($student['coop_department']){
                        $departments = getDepartments($student['coop_department']);
                        foreach ($departments as $department):
                            echo "<span class=\"badge badge-light border m-1 p-1\">".$department['department_name']."</span>";
                        endforeach;
                        }else{
                            echo "-";
                        }
                    ?></p>
               </div>
            
        </div>
    </div>
    
        <div class="col-12 col-lg-3">
            <div class="p-20">
                <div class="form-group">
                    <label class=" col-form-label"><?= gText("college_name")?></label>
                    <p class="form-control-static"><?=$student['college_name']?></p>
               </div>
                
                <div class="form-group">
                    <label class=" col-form-label"><?= gText("supervisor_name")?></label>
                    <p class="form-control-static"><?=$student['supervisor_name']?></p>
               </div>
                
                <div class="form-group">
                    <label class=" col-form-label"><?= gText("coop_name")?></label>
                    <p class="form-control-static"><?=$student['coop_name']?></p>
               </div>
                
            </div>
        </div>
</div>
