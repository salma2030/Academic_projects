/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encryption_decryption_system;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

/**
 *
 * @author MeMe
 */
public class Main_Frame extends JFrame implements ActionListener{
    
   
    
    
    
    JLabel wellabel =new JLabel("Scytale Cipher");
    //JLabel services =new JLabel("Choose a Service:");
     JPanel welPanel=new JPanel();
   JPanel FristPanel=new JPanel();
   JPanel SecondPanel=new JPanel();
   JPanel BasePanel=new JPanel();
   
   JButton enc=new JButton("Encryption");
   
   JButton dec=new JButton("Decryption");
   Box box=Box.createVerticalBox();
   public Main_Frame(){
       
    // this.setLayout(new FlowLayout());
     wellabel.setFont(new Font("DialogInput",1,70));
     wellabel.setForeground(new Color(41,82,197));
     //wellabel.setBorder(new EmptyBorder(50,200,50,200));
     enc.setFont(new Font("DialogInput",Font.BOLD,60));
     enc.add(Box.createRigidArea(new Dimension(400,100)));
     enc.setBackground(new Color(37,115,31));
     enc.setForeground(new Color(255,255,240));
     
      dec.setFont(new Font("DialogInput",Font.BOLD,60));
     dec.add(Box.createRigidArea(new Dimension(400,100)));
     dec.setBackground(new Color(37,115,31));
     dec.setForeground(new Color(255,255,240));
     
     
     //services.setFont(new Font("DialogInput",1+2,50));
     //services.setForeground(new Color(41,82,197));
     BasePanel.setLayout(new BoxLayout(BasePanel,BoxLayout.Y_AXIS));
     BasePanel.setBackground(new Color(180,229,204));
      welPanel.setBackground(new Color(180,229,204));//255,192,219
     BasePanel.add(Box.createVerticalStrut(50));
     welPanel.add(wellabel);
     
     BasePanel.add(Box.createVerticalStrut(30));
     FristPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
     FristPanel.add(Box.createHorizontalStrut(100));
     //FristPanel.add(services);
     FristPanel.setBackground(new Color(180,229,204));
     SecondPanel.setBorder(new EmptyBorder(50,200,50,200));
     SecondPanel.setBackground(new Color(180,229,204));
     SecondPanel.setLayout(new GridLayout(1,2,20,20) );
     SecondPanel.add(enc);
     SecondPanel.add(dec);
     BasePanel.add(welPanel);
     BasePanel.add(FristPanel);
    
     BasePanel.add(SecondPanel);
     BasePanel.add(Box.createVerticalStrut(30));
     this.add(BasePanel);
     
     
    enc.addActionListener(this);
    dec.addActionListener(this);
     
   } 

    @Override
    public void actionPerformed(ActionEvent e) {
        
        
      if(e.getSource()==enc) {
            
            Encrption_Cipher b=new Encrption_Cipher();
            b.setVisible(true);
            b.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            b.setSize(1800,1200);
            b.setLocationRelativeTo(null);
      } 
      
       if(e.getSource()==dec) {
          Decryption_Cipher  c=new Decryption_Cipher ();
            c.setVisible(true);
            c.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            c.setSize(1800,1200);
            c.setLocationRelativeTo(null);
      } 
      
      
    }
    
}
