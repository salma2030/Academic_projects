/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encryption_decryption_system;

import javax.swing.JFrame;

/**
 *
 * @author MeMe
 */
public class Encryption_Decryption_System  {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Main_Frame frm=new Main_Frame();
        frm.setVisible(true);
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frm.setSize(1900,1100);
        frm.setLocationRelativeTo(null);
    }
    
}
