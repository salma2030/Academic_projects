package encryption_decryption_system;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MeMe
 */
public class Encrption_Cipher extends JFrame implements ActionListener{
    
  JLabel label =new JLabel("Encryption");
    JPanel topPanel=new JPanel();
   JPanel FristPanel=new JPanel();
   JPanel SecondPanel=new JPanel();
    JPanel thirdPanel=new JPanel();
   JPanel BasePanel=new JPanel(); 
   
   JLabel PlainText_lable =new JLabel("Enter The Plain Text:");
   static JTextArea PlainText_area=new JTextArea(15,80);
   JLabel key_lable =new JLabel("Enter The Key:");
   static JTextArea key_Text_area =new JTextArea(3,80);
   
   
    JButton enc=new JButton("Encryption");
    JButton Clear_b=new JButton("Clear");
    
    
   
   
   public Encrption_Cipher(){
     BasePanel.setLayout(new BoxLayout(BasePanel,BoxLayout.Y_AXIS));  
    label.setFont(new Font("DialogInput",1,70));
     label.setForeground(new Color(41,82,197));
     //255,192,219
     BasePanel.add(Box.createVerticalStrut(50));
     topPanel.add(label);
     
     topPanel.setBackground(new Color(180,229,204));
     FristPanel.setBackground(new Color(180,229,204));
     BasePanel.setBackground(new Color(180,229,204));
     SecondPanel.setBackground(new Color(180,229,204));
     thirdPanel.setBackground(new Color(180,229,204));
     
     PlainText_lable.setFont(new Font("DialogInput",1,40));
     PlainText_lable.setForeground(new Color(41,82,197));
     
     PlainText_area.setWrapStyleWord(true);
     PlainText_area.setLineWrap(true);
     
     PlainText_area.setFont(new Font("DialogInput",1+2,20));
     
     key_Text_area.setFont(new Font("DialogInput",1+2,20));
     
     
     key_Text_area.setWrapStyleWord(true);
     key_Text_area.setLineWrap(true);
     
     FristPanel.setLayout(new FlowLayout(FlowLayout.LEFT)); 
     FristPanel.add(Box.createHorizontalStrut(100));
     FristPanel.add(PlainText_lable);
    
     FristPanel.add(PlainText_area);
     
     key_lable.setFont(new Font("DialogInput",1,40));
     key_lable.setForeground(new Color(41,82,197));
     
     
     SecondPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
     SecondPanel.add(Box.createHorizontalStrut(100));
     SecondPanel.add(key_lable);
     SecondPanel.add(Box.createHorizontalStrut(160));
     SecondPanel.add(key_Text_area);
     
     
     enc.setFont(new Font("DialogInput",Font.BOLD,40));
     enc.add(Box.createRigidArea(new Dimension(400,150)));
     enc.setBackground(new Color(37,115,31));
     enc.setForeground(new Color(255,255,240));
     
     Clear_b.setFont(new Font("DialogInput",Font.BOLD,40));
     Clear_b.add(Box.createRigidArea(new Dimension(400,150)));
     Clear_b.setBackground(new Color(37,115,31));
     Clear_b.setForeground(new Color(255,255,240));
     
     thirdPanel.add(enc);
     thirdPanel.add(Box.createHorizontalStrut(50));
     thirdPanel.add(Clear_b);
     
     BasePanel.add(topPanel);
     BasePanel.add(FristPanel);
     BasePanel.add(SecondPanel);
     BasePanel.add(thirdPanel);
     this.add(BasePanel);
     
     PlainText_area.setText("");
     key_Text_area.setText("");
     
     
    enc.addActionListener(this);
    Clear_b.addActionListener(this);
     
   }
   
   
   

    @Override
    public void actionPerformed(ActionEvent e) {
        //if clicks encryption
         //get plaintext and key
          String get_plaintext=PlainText_area.getText();
          String  plaintext_key=key_Text_area.getText();
        
        
        if(e.getSource()==enc) 
        {
            
          
            
            if(get_plaintext.isEmpty() || plaintext_key.isEmpty() ){
                JOptionPane.showMessageDialog(this,"Please, Fill both feilds");
               //System.out.print("empty");
             
            }
            
            else{
            Result_Encryption b=new Result_Encryption();
            b.setVisible(true);
            b.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            b.setSize(1800,1200);
            b.setLocationRelativeTo(null);
            }
            
        
            
        }//if
        
        
         if(e.getSource()==Clear_b){
             
          key_Text_area.setText("");
          PlainText_area.setText("");
          
             
         } 
     
    }//actionPerformed
    
   

    
}//class
