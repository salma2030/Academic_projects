/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encryption_decryption_system;

import static encryption_decryption_system.Result_Encryption.scytale_Encode;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 *
 * @author MeMe
 */
public class Result_Decryption extends JFrame implements ActionListener{
  JLabel label =new JLabel("The Original Text is");
    
    JTextArea decryptedText_area=new JTextArea(15,80);
    
    JPanel FristPanel=new JPanel();
    JPanel SecondPanel=new JPanel();
    JPanel thirdPanel=new JPanel(); 
    JPanel BasePanel=new JPanel();
    JButton Exit=new JButton("Exit"); 
    
    String get_plaintext=Decryption_Cipher.PlainText_area.getText();
    int get_key=Integer.parseInt(Decryption_Cipher.key_Text_area.getText());
    String decryption_result;
    
    
    public Result_Decryption(){
     BasePanel.setLayout(new BoxLayout(BasePanel,BoxLayout.Y_AXIS)); 
    label.setFont(new Font("DialogInput",1,70));
    label.setForeground(new Color(41,82,197));   
    
    BasePanel.add(Box.createVerticalStrut(50));
    FristPanel.add(label);  
     
    FristPanel.setBackground(new Color(180,229,204));
    BasePanel.setBackground(new Color(180,229,204));
    SecondPanel.setBackground(new Color(180,229,204));
    thirdPanel.setBackground(new Color(180,229,204));
     
     
     decryptedText_area.setFont(new Font("DialogInput",1+2,20));
     decryptedText_area.setWrapStyleWord(true);
     decryptedText_area.setLineWrap(true);
     
    SecondPanel.add(decryptedText_area);
     
     Exit.setFont(new Font("DialogInput",Font.BOLD,40));
     Exit.add(Box.createRigidArea(new Dimension(400,150)));
     Exit.setBackground(new Color(37,115,31));
     Exit.setForeground(new Color(255,255,240)); 
     
     
     thirdPanel.add(Exit);
     BasePanel.add(FristPanel);
     BasePanel.add(SecondPanel);
     BasePanel.add(thirdPanel);
     
     this.add(BasePanel);
     Exit.addActionListener(this);   
        
      decryption_result=scytale_Decode(get_plaintext,get_key);
     decryptedText_area.setText(decryption_result);  
        
        
        
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
       if(e.getSource()==Exit) {
            
           this.setVisible(false); 
            
      } 
    }//actionPerformed
    
     //to decode the encoded text
    public static String scytale_Decode(String encodeText,int numOfRows ){
        
        String decodeText=" ";
        
        //Calculate number of coulmns ()
        int numOfCols= encodeText.length()/numOfRows;
        
        //decode the encodeText
        decodeText=Result_Encryption.scytale_Encode(encodeText,numOfCols).trim();
        return decodeText;
    }//scytale_Decode()
    
      
}//class
