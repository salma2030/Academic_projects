/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encryption_decryption_system;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
/**
 *
 * @author MeMe
 */
public class Result_Encryption extends JFrame implements ActionListener   {

    JLabel label =new JLabel("The Encrypted Text is");
    
    JTextArea ecryptedText_area=new JTextArea(15,80);
    
    JPanel FristPanel=new JPanel();
    JPanel SecondPanel=new JPanel();
    JPanel thirdPanel=new JPanel(); 
    JPanel BasePanel=new JPanel();
    JButton Exit=new JButton("Exit"); 
    
    String get_plaintext=Encrption_Cipher.PlainText_area.getText();
    int get_key=Integer.parseInt(Encrption_Cipher.key_Text_area.getText());
    String ecryption_result;
    
   public  Result_Encryption(){
    BasePanel.setLayout(new BoxLayout(BasePanel,BoxLayout.Y_AXIS)); 
    label.setFont(new Font("DialogInput",1,70));
    label.setForeground(new Color(41,82,197));   
    
    BasePanel.add(Box.createVerticalStrut(50));
    FristPanel.add(label);  
     
    FristPanel.setBackground(new Color(180,229,204));
    BasePanel.setBackground(new Color(180,229,204));
    SecondPanel.setBackground(new Color(180,229,204));
     thirdPanel.setBackground(new Color(180,229,204));
     
     
     ecryptedText_area.setFont(new Font("DialogInput",1+2,20));
     ecryptedText_area.setWrapStyleWord(true);
     ecryptedText_area.setLineWrap(true);
     
    SecondPanel.add(ecryptedText_area);
     
     Exit.setFont(new Font("DialogInput",Font.BOLD,40));
     Exit.add(Box.createRigidArea(new Dimension(400,150)));
     Exit.setBackground(new Color(37,115,31));
     Exit.setForeground(new Color(255,255,240)); 
     
     
     thirdPanel.add(Exit);
     BasePanel.add(FristPanel);
     BasePanel.add(SecondPanel);
     BasePanel.add(thirdPanel);
     
     this.add(BasePanel);
     Exit.addActionListener(this);
     
     ecryption_result=scytale_Encode(get_plaintext,get_key);
     ecryptedText_area.setText(ecryption_result);
     
     
   } 
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==Exit) {
            
           this.setVisible(false); 
            
      } //if exist 
        
       
        
      
    }//actionPerformed
    
     
    //Encryption method
    //to encode a plain text
    public static String scytale_Encode(String plainText,int numOfRows ){
    
    String plainText_without_space="";
    String encodedText="";
    char[] chars=plainText.toCharArray();
    for (int i=0 ; i<chars.length;i++){
        
        if(chars[i]!=' '){
          plainText_without_space+=chars[i];  
        }
    }
    System.out.println(plainText_without_space);
    // check wether number of rows is greater than or= to plain text length 
    
    if(numOfRows>=plainText_without_space.length() || numOfRows<=0){
    return plainText;}//if
    
    
   // divide the plaintext length by number of rows
    else{
        //if we have remainder, add space to the plain text
        while(plainText_without_space.length()%numOfRows!=0){
           plainText_without_space+="z";
        }//while
        
        //Calculate number of coulmns ()
        int numOfCols= plainText_without_space.length()/numOfRows;
        //int j=numOfCols;
        for(int i=0; i<numOfCols;i++){
            for(int j=i;j<plainText_without_space.length();j+=numOfCols){
                encodedText+=plainText_without_space.charAt(j);
                
            
            }//inner for
        
        }//outer for
      } 
    
    return encodedText;
    
    }//scytale_Encode()
    
    
  
    
    
    
    
    
    
    
    
}//class
