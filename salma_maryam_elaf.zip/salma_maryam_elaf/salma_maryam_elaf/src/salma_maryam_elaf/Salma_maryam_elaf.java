/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salma_maryam_elaf;

import javax.swing.JFrame;

/**
 *
 * @author Dr.Salma
 */
public class Salma_maryam_elaf {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Welcome frame=new Welcome();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(850,700);
        frame.setLocationRelativeTo(null);
        
    }
    
}
