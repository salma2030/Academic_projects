/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salma_maryam_elaf;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import javax.swing.*;
import salma_maryam_elaf.TicTacToe;
/**
 *
 * @author 
 */
public class TicTacToeTest {
    
    public TicTacToeTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of determainWhoseTurn method, of class TicTacToe.
     */
    @Test
    public void testDetermainWhoseTurn() {
        System.out.println("testDetermainWhoseTurn");
        TicTacToe tt= new TicTacToe();
        TicTacToe.whoseTurn="O";
        tt.determainWhoseTurn();
        assertEquals("X",tt.getWhoseTurn());

    }
    @Test
    public void testDetermainWhoseTurn2() {
        System.out.println("testDetermainWhoseTurn2");
        TicTacToe tt= new TicTacToe();
        TicTacToe.whoseTurn="O";
        tt.determainWhoseTurn();
        assertEquals("X",tt.getWhoseTurn());
    }
    public void testDetermainWhoseTurn3() {
        System.out.println("testDetermainWhoseTurn3");
        TicTacToe tt= new TicTacToe();
        TicTacToe.whoseTurn="O";
        tt.determainWhoseTurn();
        assertNotEquals("O",false);
    }
    @Test
    public void testDetermainWhoseTurn4() {
        System.out.println("testDetermainWhoseTurn4");
        TicTacToe tt= new TicTacToe();
        TicTacToe.whoseTurn="X";
        tt.determainWhoseTurn();
        assertFalse("O",false);
    }
    /**
     * Test of setScores method, of class TicTacToe.
     */
    @Test
    public void testSetScores() {
        System.out.println("setScores");
        TicTacToe tt= new TicTacToe();
        tt.firstPlayer="Mohammed";
        tt.secondPlayer="Salma";
        tt.firstPlayerScore=5;
        tt.secondPlayerScore=2;
        tt.setScores();
        assertEquals("Mohammed's score is: 5\t\t  Salma's score is: 2\t\t",tt.getFirstPlayer()+"'s score is: "+tt.getFirstPlayerScore()+"\t\t  " + tt.getSecondPlayer()+"'s score is: "+tt.getSecondPlayerScore()+"\t\t");
    }
    public void testSetScores2() {
        System.out.println("setScores2");
        TicTacToe tt= new TicTacToe();
        tt.firstPlayer="Abdullah";
        tt.secondPlayer="Maryam";
        tt.firstPlayerScore=0;
        tt.secondPlayerScore=2;
        tt.setScores();
        assertEquals("Abdullah's score is: 0\t\t  Maryam's score is: 2\t\t",tt.getFirstPlayer()+"'s score is: "+tt.getFirstPlayerScore()+"\t\t  " + tt.getSecondPlayer()+"'s score is: "+tt.getSecondPlayerScore()+"\t\t");
    }
    @Test
    public void testSetScores3() {
        System.out.println("setScores3");
        TicTacToe tt= new TicTacToe();
        tt.firstPlayer="Jonson";
        tt.secondPlayer="Riya";
        tt.firstPlayerScore=0;
        tt.secondPlayerScore=2;
        tt.setScores();
        assertNotEquals("Abdu score is: 0       Khawaja's score is: 2",tt.getFirstPlayer()+"'s score is: "+tt.getFirstPlayerScore()+"\t\t  " + tt.getSecondPlayer()+"'s score is: "+tt.getSecondPlayerScore()+"\t\t");
    }

    /**
     * Test of x_winner method, of class TicTacToe.
     */
    @Test(expected = Exception.class)
    public void testX_winner() {
        System.out.println("x_winner");
        TicTacToe tt= new TicTacToe();
        tt.firstPlayer="Ali";
        tt.firstPlayerScore=3;
        tt.firstPlayerScore++;
        tt.round++;
        tt.x_winner();
        assertNotEquals("Player one(  ALi  ) wins Winner","Player one( " +tt.getFirstPlayer()+ " ) wins Winner");
    }
    
    @Test(expected = Exception.class)
    public void testX_winner2() {
        System.out.println("x_winner2");
        TicTacToe tt= new TicTacToe();
        tt.firstPlayer="abc";
        tt.firstPlayerScore=2;
        tt.firstPlayerScore++;
        tt.round++;
        tt.x_winner();

        assertEquals("Player one(  Abc  ) wins Winner","Player one( " +tt.getFirstPlayer()+ " ) wins Winner");
    }
    
    @Test(expected = Exception.class)
    public void testX_winner3() {
        System.out.println("x_winner3");
        TicTacToe tt= new TicTacToe();
        tt.secondPlayer="Alpha";
        tt.firstPlayerScore=4;
        tt.firstPlayerScore++;
        tt.round++;
        tt.x_winner();

        assertFalse("Player one(  Elaf  ) wins Winner",false);
    }
    @Test(expected = Exception.class)
    public void testX_winner4() {
        System.out.println("x_winner4");
        TicTacToe tt= new TicTacToe();
        tt.firstPlayer="Elaf";
        tt.firstPlayerScore=4;
        tt.firstPlayerScore++;
        tt.round++;
        tt.x_winner();

        assertTrue("Player one(  Elaf  ) wins Winner",true);
    }

    /**
     * Test of o_winner method, of class TicTacToe.
     */

@Test(expected = Exception.class)
        public void testO_winner() {
        System.out.println("o_winner");
        TicTacToe tt= new TicTacToe();
        tt.secondPlayer="beta";
        tt.secondPlayerScore=1;
        tt.secondPlayerScore++;
        tt.round++;
        tt.o_winner();

        assertTrue("Player one(  beta  ) wins Winner",true);
    }
   @Test(expected = Exception.class)
        public void testO_winner2() {
        System.out.println("o_winner2");
         TicTacToe tt= new TicTacToe();
        tt.secondPlayer="gema";
        tt.secondPlayerScore=1;
        tt.secondPlayerScore++;
        tt.round++;
        tt.o_winner();

        assertEquals("Player one(  Gema  ) wins Winner","Player one( " +tt.getSecondPlayer()+ " ) wins Winner");
    }     
        
    /**
     * Test of reset method, of class TicTacToe.
     */
    @Test
    public void testReset() {
        System.out.println("reset");
        TicTacToe tt= new TicTacToe();
        tt.Button1.setText("abc");
        tt.Button2.setText("abcsf");
        tt.reset();
        String xx=tt.Button1.getText();
        assertEquals("", xx);
    }
    @Test
    public void testReset2() {
        System.out.println("reset2");
        TicTacToe tt= new TicTacToe();
        tt.Button4.setText("abc");

        tt.reset();
        String xx=tt.Button4.getText();
        assertEquals("", xx);
    }
    @Test
    public void testReset3() {
        System.out.println("reset3");
        TicTacToe tt= new TicTacToe();
        tt.Button5.setText("abc");

        tt.reset();
        String xx=tt.Button5.getText().trim();
        assertEquals("", xx);
    }
    /**
     * Test of whenWin method, of class TicTacToe.
     */
    @Test(expected = Exception.class)
    public void testWhenWin() {
        System.out.println("whenWin");
        TicTacToe tt= new TicTacToe();
        tt.Button1.setText("X");
        tt.Button2.setText("X");
        tt.Button3.setText("X");
        tt.whenWin();
        String one=tt.Button1.getText();
        String two=tt.Button2.getText();
        String three=tt.Button3.getText();
        assertEquals("X's wins the game" , one+"'s wins the game" );

    }
     @Test(expected = Exception.class)
    public void testWhenWin2() {
        System.out.println("whenWin2");
        TicTacToe tt= new TicTacToe();
        tt.Button1.setText("O");
        tt.Button2.setText("O");
        tt.Button3.setText("O");
        tt.whenWin();
        String one=tt.Button1.getText();
        String two=tt.Button2.getText();
        String three=tt.Button3.getText();
        assertEquals("O's wins the game" , one+"'s wins the game" );


    }
@Test(expected = Exception.class)
    public void testWhenWin3() {
        System.out.println("whenWin3");
        TicTacToe tt= new TicTacToe();
        tt.Button4.setText("X");
        tt.Button5.setText("X");
        tt.Button6.setText("X");
        tt.whenWin();
        String four=tt.Button4.getText();
        String five=tt.Button5.getText();
        String six=tt.Button6.getText();
        assertEquals("X's wins the game" , five+"'s wins the game" );


    }
@Test(expected = Exception.class)
    public void testWhenWin4()throws Exception{
        System.out.println("whenWin4");
        TicTacToe tt= new TicTacToe();
        tt.Button4.setText("X");
        tt.Button5.setText("X");
        tt.Button6.setText("X");
        tt.whenWin();
        String four=tt.Button4.getText();
        String five=tt.Button5.getText();
        String six=tt.Button6.getText();
        assertEquals("X's wins the game" , five+"'s wins the game" );

    }
    /**
     * Test of tie_Game method, of class TicTacToe.
     */
    @Test
    public void testTie_Game() {
        System.out.println("tie_Game");
        TicTacToe tt= new TicTacToe();
        tt.Button1.setText("ab");
        tt.Button2.setText("v");
        tt.Button3.setText("dv");
        tt.tie_Game();

        String one=tt.Button1.getText();
        String two=tt.Button2.getText();
        String three=tt.Button3.getText();
        assertEquals("match tie", "match tie");
    }
    @Test
    public void testTie_Game2() {
        System.out.println("tie_Game2");
        TicTacToe tt= new TicTacToe();
        tt.Button4.setText("dvd");
        tt.Button5.setText("ds");
        tt.Button6.setText("we");
        tt.tie_Game();

        String four=tt.Button4.getText();
        String five=tt.Button5.getText();
        String six=tt.Button6.getText();
        assertNotEquals("match tie", "match won");
    }
    @Test
    public void testTie_Game3()throws Exception {
        System.out.println("tie_Game3");
        TicTacToe tt= new TicTacToe();
        tt.Button7.setText("");
        tt.Button8.setText("ad");
        tt.Button9.setText("");
        tt.tie_Game();

        String seven=tt.Button7.getText();
        String eight=tt.Button8.getText();
        String nine=tt.Button9.getText();
        assertEquals("match tie", "match tie");
    }
    @Test
    public void tie_Game_2() throws Exception{
        TicTacToe tt= new TicTacToe();
        tt.Button3.setText("");
        tt.Button1.setText("");
        tt.Button8.setText("");
        tt.tie_Game();

        String three=tt.Button1.getText();
        String one=tt.Button2.getText();
        String eight=tt.Button3.getText();
        assertEquals("match tie", "match tie");
    }
    
}
