<?php
session_start();
ob_start();
include("db_config.php");

if(!isset($_SESSION['User'])){
     
     echo 'Something goes wrong'; 
 }
 
 else{
     
     
      if (isset($_POST['update_info'])){ 
             
            $get_name=$_POST['new_name'];
            $get_mail=$_POST['new_email'];
            $get_pass=$_POST['new_password'];
            
            $query_update="Update user SET name='$get_name', email='$get_mail', password='$get_pass' where email='". $_SESSION['User']."' ";
            $result_update=mysqli_query($con, $query_update);
            
                if(isset($result_update) and $result_update){
                    $_SESSION['User']=$_POST['new_email'];
                    header('location: Profile.php?update=Your information updated successfully');
                    exit();
                }
                
                else {
                    header('location: Profile.php?wrong=Try again later');
                    exit();
                }
         
     }
     
     else {
         echo 'Try again!!';  
 }

 }




         
 









?>