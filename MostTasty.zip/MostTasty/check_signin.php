<?php
session_start();
include("db_config.php");






          if (isset($_POST['signIn_btn'])){ 
             
            if(empty($_POST['email']) || empty($_POST['password'])){
                    
                header("location: Home.php?Empty=Please fill in all blanks");
                 
             } else{ 
                
                    $query="select * from user where email='".$_POST['email']."' and password='".$_POST['password']."'";
                    $result = mysqli_query($con, $query);
                    
                    if(mysqli_fetch_assoc($result)){
                        $_SESSION['User'] =$_POST['email'];
                        header('location: Home_After_signin.php');
                        exit();
                    }
                    
                    else {
                        header("location: Home.php?invalid=please enter correct values");
                        exit();
                        
                    }
                 }
         
     } 

 else {
         echo 'Try again!!';  
 }









?>