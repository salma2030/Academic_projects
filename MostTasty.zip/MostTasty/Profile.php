<!DOCTYPE html>
<?php 

ob_start();
include("db_config.php");
session_start();



 if(!isset($_SESSION['User'])){
      
    // echo "<script type='text/javascript'>alert('Try again');</script>";
    echo 'NO session established';
 }
 
 else{
     
     $get_email=$_SESSION['User'];
     
     
  $query= "SELECT * FROM user where email='$get_email'" ;
    
   $result_1 = mysqli_query($con, $query);
    
   $row= mysqli_fetch_assoc($result_1);
 }
  

    
    
?>


<html>
    <head>
        <title>My profile</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <style>
            #wrapper{
                margin: 0;
                width: 1000;
                
            }            
            
         #menuBar{
         background-color: #FFE4C4; 
         height: 130px;
          
      }
      #Pic_Name{
        width: 550px; 
        height: 60px;
        margin-left: 50px;
        margin-top: 11px;
         
      }  
      #services{
     
      width: 500px;  
      float:right;
      margin-top: -110px;
      margin-right: -138px;
     
        
      }
      
      #services img{
          //margin-right: -180px;
          cursor: pointer;
      }
      .profile_pic{
          
       width: 107px;
       height: 107px;   
       margin-top: 14px;   
      } 
      .user_name{
        color: grey; 
        font-size: 26px; 
        font-weight: bold;
         padding-top: 15px;
         float: right;
         margin-right: 365px;
         
      }
      /*header design*/
      #add{
          position: absolute;
          top:135px;
          right:1250px;
          font-size:26px; 
          font-weight: bold;
          padding-left: -100px;
      }
       
      .columncenter{
              background-color: #fff;  
              color:black; 
              width: 250px;
              height: 250px;
              float:left;
              margin: 15px;
              padding-top: 50px;
              text-align: center;
              margin-right: 100px;
              margin-left: 90px;
              font-size: 40px;
              font-weight: bold;
               
            }
            .columncenter img:hover{
               transform:scale(1.1,1.1); 
               
            }
            
            .columncenter img{
               width:350px;
               height:350px;
               
            }
            .columncenter > h2{
                font-size: 20px;
                margin-left: 120px;
                margin-top: 5px;
            }
            
            
            #add_pic{
              transition: 0.4s;
              cursor: pointer;   
            }
            
            #add_pic:hover{
                
              transform:scale(1.3,1.3);
                
            }
            .close{
                position:absolute;
                background-color:#fff; 
                top:-15px;
                right:-15px;
                border-radius: 10px;
                box-shadow: 6px 6px 29px -4px rgba(0,0,0,0.75);
                cursor: pointer;
            }
            #button1_add{
                
               background-color: #778899;
               color:#fff;
               width:250px;
               height: 50px;
               padding:10px 15px;
               text-decoration: none;
               border-radius: 5px;
               cursor: pointer;
               text-align: center;
               padding-top: -30px;
               margin-top: 20px;
               margin-right: -70px;
             }
            
            .popup_add_recipe{
             background: rgba (0,0,0,0.50);
             width:150px;
             height: 100px;
             /*margin-top: 100px;*/
             display:none;
             justify-content:left;
             align-items:left;
            }
            
            .pop-content_add_recipe{
             height: 890px;
             width:750px;
             background:#F0F8FF ;
             padding:15px;
             border-radius: 30px;
             box-shadow: 6px 6px 29px -4px rgba(0,0,0,0.75);
             text-align: center;
             border: 1px solid grey;
             font-size: 25px;
             position: absolute;
             left: 400px;
             top: 200px;
              
            }
            
           .pop-content_add_recipe input{
                
                height: 40px;
                width: 250px;
                border: 1px solid black;
                font-size: 20px;
            }
            
            .pop-content_add_recipe select{
                
                height: 40px;
                width: 250px;
                border: 1px solid black;
                font-size: 20px;
            }
            
            .popup_Edit_profile{
             background: rgba (0,0,0,0.50);
             width:400px;
             height: 300px;
             display:none;
             justify-content:left;
             align-items:left;
             
             
            }
            .pop-content_Edit_profile{
             height: 600px;
             width:670px;
             background:#F0F8FF ;
             padding: 15px;
             border-radius: 30px;
             box-shadow: 6px 6px 29px -4px rgba(0,0,0,0.75);
             text-align: center;
             border: 1px solid grey;
             font-size: 25px;
             position: absolute;
             left: 400px;
             top: 100px;
            }
            .pop-content_Edit_profile input{
            
             height: 40px;
             width: 250px;
             border: 1px solid black;
             font-size: 20px;
            }
            
            
            #edit{
             cursor: pointer;   
            }
            
            
             .error1
            {
                color: red;
                font-style: italic;
                font-size: 10px;
                visibility: hidden;
                
            } 
             .error
            {
                color: red;
                font-style: italic;
                font-size: 10px;
                visibility: hidden;
                
            } 
            textarea{
                font-size: 20px;
                font-weight: bold;
            }
            
            
          
              #button1_add:hover{
            background-color: #D2691E;
           
           
            }
            
            .pop-content{
                height: 450px;
             width:450px;
             background: #fff;
             padding:20px;
             border-radius: 10px;
             margin-top: -100x;
             text-align: center;
             border: 1px solid grey;
             position: absolute;
             left: 530px;
             top: 200px;
             
            }
            
            .popup{
                background: rgba (0,0,0,0.50);
             width:500px;
             height: 300px;
             margin-top: 100px;
            
             display:none;
             justify-content:center;
             align-items:center;
            }
            
            .close_optimal{
                position:absolute;
                background-color:#fff; 
                top:-15px;
                right:-15px;
                border-radius: 10px;
                box-shadow: 6px 6px 29px -4px rgba(0,0,0,0.75);
                cursor: pointer;}
            
            
            
            
            
           
            
        </style>
    </head>
    <body style=" overflow-x: hidden">
        
        <div id="wrapper">
       <?php 
            $name=$row['name'];
            include("profile_header.php");
       ?>
        <img src="add.png" alt="add"  id="add_pic" style="width: 36px; height:36px; padding-left: 75px; padding-top: 10px"> 
        <h2 id="add">My Recipes</h2>
        <hr>
        
         <div class="columncenter" id="column1"> <!--if  i want to use the class name it should be no space-->
                    
             <a href="pizzaRecipe.php"><img src="pizza.jpg"></a>
             
                               <h2 class="first">Pizza</h2>  
                    
                </div>
                <div class="columncenter" id="column2">
                    
                    <a href="pastaRecipe.php"><img src="pasta.jpg" ></a>
                              <h2 class="first">Pasta</h2>  
                    
                    
                </div>
                <div class="columncenter" id="column3">
                    
                    <a href="beefRecipe.php"><img src="beef.jpg" ></a>
                      <h2 class="first">Beef</h2> 
                </div>
                
                    
            <!-----------------------------------------Add recipe form---------->  
            
         <div  class="popup_add_recipe">
            <div class="pop-content_add_recipe" >
               
                 <img src="chef.png" alt="new-recipe_pic" style="width:130px; height:130px">
                   <img src="close-480.png" alt="new-recipe_pic"  class="close" style="width:40px; height:40px">  
                 <h4>Add New Recipe</h4>
                    
                    
                 <hr>
                 <form  id="add_form" name="recipe_form"  method="post" action="check111.php" enctype="multipart/form-data" >
                      
                     <label  for="recipe_name">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Recipe Name*:&nbsp;&nbsp; </label>
                    <input type="text" name="recipe_name"  >
                    <!-- <span class="error1">This is required</span>-->
                    
                    <br><br>
                    
                    
                    
                     <label for="recipe_pic">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Recipe Picture*: </label>
                     <input type="file" name="recipe_pic"  required>
                     <!-- <span class="error1">This is required</span>-->
                    
                       <br><br>
                        <label  for="recipe_time">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cook Time*:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </label>
                        <input type="time"  name="recipe_time">
                        <!-- <span class="error1">This is required</span>-->
                
                
                      <br><br>
                
                    <label   for="recipe_cal">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Calories*:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </label>
                    <input type="text" name="recipe_cal">
                    <!-- <span class="error1">This is required</span>-->
                    <br><br>
                    
                     <label  for="recipe_type">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Recipe type*:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   </label>
                    <select name="select_type">
                        <option value="default">Choose a type</option>
                        <option value="main_dish">Main dishes</option>
                        <option value="salad">Salad</option>
                        <option value="dessert">Dessert</option>
                        <option value="drinks">Drinks</option>
                        <option value="seafood">Seafood</option>
                        
                    </select>
                    <!-- <span class="error1">This is required</span>-->
                    
                    <br><br>
                    
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <textarea rows="6" cols="32" name="recipe_details" placeholder="Write the Ingredients Here "></textarea>
                    <!-- <span class="error1">This is required</span>-->
                    <br><br>
                    <input type="submit" name="add" value="ADD" id="button1_add" ">
                      <!-- <input  id="button1_add" type="reset" value="Clear" onclick="reset()">-->
                     </form>
                 
                 <?php if(@$_GET['Emptyfield']==TRUE) {?>
                <div class="alert-light text-danger py-3" style="color: red; margin-top:20px; margin-right:-30px "><?php echo @$_GET['Emptyfield'];?></div>
                <?php }?>
                
                 <?php if(@$_GET['notsuccess']==TRUE) {?>
                <div class="alert-light text-danger py-3" style="color: red; margin-top:20px; margin-right:-30px"><?php echo @$_GET['notsuccess'];?></div>
                <?php }?>
                  <?php if(@$_GET['added']==TRUE) {?>
                <div class="alert-light text-danger py-3" style="color: green; margin-top:20px; margin-right:-30px"><?php echo @$_GET['added'];?></div>
                <?php }?>
                 
                 
                 
                 
                 <br>
                
            </div> 
            
            
        </div> 
      
         
         <!--finsh the add recipe form-->
         
         <!--------------------------Edit form--------------------------------->  
         
         <div  class="popup_Edit_profile">
            <div class="pop-content_Edit_profile" >
               
                 <img src="pic.png" alt="pic" style="width:120px; height:120px">
                   <img src="close-480.png" alt="new-recipe_pic" id="close1" class="close" style="width:40px; height:40px">  
                 
                   <form   name="Edit_form" method="POST" action="check_edit.php">
                       <br><br>
                           <label for="new_name">New Name*:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  </label> 
                           <input type="text" id="userName" name="new_name" value="<?php echo $row['name'];?>" >
                           <span class="error">This is required</span>
                           <br><br>
                           <label for="new_email"> New Email*:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </label><!--&nbsp; to add one space-->
                        <input type="email" name="new_email" value="<?php echo $row['email'];?>"> 
                        <span class="error">This is required</span>
                                      
                        <br><br>
                     
                        <label for="new_password">New Password*: </label> 
                        <input type="password"  name="new_password" value="<?php echo $row['password'];?>">
                    <span class="error">This is required</span>
                
                    <input type="submit" value="Update"  id="button1_add" name="update_info"  style="background-color:palevioletred; color:black; border: 2px solid black ; ">
                    <!--<input  id="button1_add" type="reset" value="Clear" onclick="reset()">-->
                     </form>
                   <br> <br>
                   
                    <?php if(@$_GET['update']== TRUE){ ?>
                
                <div class="alert-light text-danger text-center py-3" style=" color: green; margin-left:55px"> <?php echo @$_GET['update'];?></div>
                <?php }?>
                
                <?php if(@$_GET['wrong']== TRUE){ ?>
                
                <div class="alert-light text-danger text-center py-3" style=" color: red; margin-left:55px"> <?php echo @$_GET['wrong'];?></div>
                <?php }?>
                   
            </div> 
            
            
        </div> 
          <!--finish the edit recipe form-->
          
            <!---------------------optimal weight form--------------------------------->
    <div class="popup" 
         style="">
        
        
        <div class="pop-content" 
             style="">
            
            <img src="weight.png" alt="Optimal weight icon" style="width:60px; height:60px">
                   <img src="close-480.png" alt="new-recipe_pic"  class="close_optimal" style="width:30px; height:30px">  
                 <h4 >Calculate Optimal weight</h4>
                 <hr>
                 <div id="form_div">
                     <form name="optimal-weight-form" id="optimal-weight-form">
                         <label for="weight"> Weight*</label>
                         <input type="text" name="weight" id="weighid" placeholder="Kg">
                         
                         <br><br><br>
                         
                         
                         <label for="gender"> Gender*</label>
                         <input type="radio" name="gender" id="gender" >Female
                         <input type="radio" name="gender" id="gender">Male
                        
                         
                         <br><br><br>
                         <label for="Height">Height*</label>
                         <input type="text" name="Height" placeholder="Cm" id="heightid">
                         
                         <br><br><br>
                         <a href="javascript:void()" id="button1_add" class="cal_class" onclick="calculate_fun()" > Calculate</a>
                         <input type="reset" id="button1_add" class="clear_class" value="clear" onclick="reset()" 
                                style="width: 150px; height: 43px;
                                border-radius: 5px;
                                font-size: 18px;
                                padding:5px 5px;" >
                         
                         
                         <br><br>
                        
                         <span id="error" style="
                                color: red;
                                font-size: 14px;
                                visibility: hidden;">
                             * Fill all required fields</span>
                     </form>
                     
                 </div>
            
        </div>
    </div>
           </div>
           <script>
          //  
         document.getElementById("add_pic").addEventListener("click",function(){
             document.querySelector(".popup_add_recipe").style.display="flex";
         });
         
          document.querySelector(".close").addEventListener("click",function(){
            document.querySelector(".popup_add_recipe").style.display="none";
            document.getElementByClassName(".error1").style.visibility="hidden";
             
         });
         
           
             document.getElementById("edit").addEventListener("click",function(){
             document.querySelector(".popup_Edit_profile").style.display="flex";
         });
         
          document.getElementById("close1").addEventListener("click",function(){
             document.querySelector(".popup_Edit_profile").style.display="none";
         }) ;
         //validate add form
        function validate_add()
            {       
               
               
                if (document.forms["recipe_form"]["recipe_name"].value != "" && document.forms["recipe_form"]["recipe_pic"].value != ""&&
                document.forms["recipe_form"]["recipe_time"].value != ""&&document.forms["recipe_form"]["recipe_cal"].value != ""
                &&document.forms["recipe_form"]["recipe_details"].value != "" && document.forms["recipe_form"]["select_type"].value != "default" )
               {
                   alert("The Recipe Added");
               }
               else{ 
                
                if (document.forms["recipe_form"]["recipe_name"].value == "") 
                    document.getElementsByClassName("error1")[0].style.visibility = "visible"; 
                
                else 
                    document.getElementsByClassName("error1")[0].style.visibility = "hidden";
                
                if (document.forms["recipe_form"]["recipe_pic"].value == "") 
                    document.getElementsByClassName("error1")[1].style.visibility = "visible"; 
                
                else 
                    document.document.getElementsByClassName("error1")[1].style.visibility = "hidden";
                
                if (document.forms["recipe_form"]["recipe_time"].value == "") 
                    document.getElementsByClassName("error1")[2].style.visibility = "visible"; 
                
                else 
                    document.getElementsByClassName("error1")[2].style.visibility = "hidden";
                
                
                if (document.forms["recipe_form"]["recipe_cal"].value == "" ) 
                    document.getElementsByClassName("error1")[3].style.visibility = "visible"; 
                
                else 
                    document.getElementsByClassName("error1")[3].style.visibility = "hidden";
                
                 if (document.forms["recipe_form"]["select_type"].value == "default") 
                    document.getElementsByClassName("error1")[4].style.visibility = "visible"; 
                
                else 
                    document.getElementsByClassName("error1")[4].style.visibility = "hidden";
                
                
                 if (document.forms["recipe_form"]["recipe_details"].value == "" ) 
                    document.getElementsByClassName("error1")[5].style.visibility = "visible"; 
                
                else 
                    document.getElementsByClassName("error1")[5].style.visibility = "hidden";
                   
               }

            }
         //validate edit form
         
         
            function validate_edit()
            {       
               
               
                if (document.forms["Edit_form"]["new_name"].value != "" && document.forms["Edit_form"]["new_email"].value != ""&&
                document.forms["Edit_form"]["new_password"].value != "")
               {
                   var new_name = document.getElementById("userName").innerHTML;
                     alert(new_name);//just tomake sure you can delete it
                   document.querySelector(".user_name").innerHTML=new_name.innerHTML;
                   document.querySelector(".popup_Edit_profile").style.display="none";
                   
                   alert("The Profile is Edited");
               }
               else{ 
                
                if (document.forms["Edit_form"]["new_name"].value == "") 
                    document.getElementsByClassName("error")[0].style.visibility = "visible"; 
                
                else 
                    document.getElementsByClassName("error")[0].style.visibility = "hidden";
                
                    
                if (document.forms["Edit_form"]["new_email"].value == "") 
                    document.getElementsByClassName("error")[1].style.visibility = "visible"; 
                
                else 
                    document.document.getElementsByClassName("error")[1].style.visibility = "hidden";
                
                if (document.forms["Edit_form"]["new_password"].value == "") 
                    document.getElementsByClassName("error")[2].style.visibility = "visible"; 
                
                else 
                    document.getElementsByClassName("error")[2].style.visibility = "hidden";
                
                   
               }

            }
            
            
            //-------------------Optimal weight form actions--------------------------------

    
    document.getElementById("weight_logo").addEventListener("click",function(){
               
              document.querySelector(".popup").style.display="flex"; 
             
    })
  
 //to make it clear and empty

 document.querySelector(".close_optimal").addEventListener("click",function(){
             var error_optimal= document.getElementById("error");
             document.querySelector(".popup").style.display="none";
            error_optimal.style.visibility='hidden';
              
         })
  
 
         
       
    
//-------------------Optimal weight form actions for contents-------------------
    //when press on calculate button
  
          function calculate_fun(){
               
              var weight_kg=document.getElementById("weighid");
              var height_kg=document.getElementById("heightid");
              var gend=document.getElementById("gender");
              var message=document.getElementById("error");
              
             if(weight_kg.value=="" || height_kg.value=="" || gend.value=="" ){
                 message.style.visibility="visible";
                 
             }
             
              if(weight_kg.value!="" && height_kg.value!="" && gend.value!="" ){
                 document.querySelector(".popup").style.display="none"; 
                 message.style.visibility="hidden";
                 
             }
             
             
    }//calculate_fun()
         
         
         </script>
        
    </body>
</html>
