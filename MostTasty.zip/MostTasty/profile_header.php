<header>
            <div id="menuBar">
                <div id="Pic_Name" >
                 <img src="pic.png" class="profile_pic" alt="profile_pic" >
                 <img src="pencil.png"  id="edit" alt="profile_pic" style="width: 35px; height:35px">
                 <h4  class="user_name" style=" margin-left:-30px"><?php echo $name; ?></h4>
                </div>
    
                <div id="services" >
                    <a href="favorite.php"><img src="f.png" alt="profile_pic" style="width: 80px; height: 80px;"></a>
                    <a href="javascript:void()" id="weight_logo"><img src="weight.png" alt="profile_pic" style="width: 70px; height: 70px;"></a>
                  
                    <a href="planner.php"><img src="planner.png" alt="profile_pic" style="width:70px; height: 70px"></a>
                    <a href="Home_After_signin.php"><img src="Home-icon.png" alt="profile_pic" style="width:70px; height:70px"></a>
                </div>
      
           </div>
      </header>
