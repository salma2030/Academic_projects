<?php

$host='127.0.0.1';
$username='root';
$pwd=''; 
$db="most_tasty";
$port='3307';



$con = mysqli_connect($host,$username,$pwd,$db, $port);

if(mysqli_connect_errno($con)){
    
    echo mysqli_connect_error();
    exit();
    
    
}















?>