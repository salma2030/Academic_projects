<!Document html>
<html>
 <?php
    include("db_config.php");
    
    $query = " SELECT * FROM recipe";
    
    $result = mysqli_query($con, $query);
    
    $recipe_list = array();
    
    while($row =  mysqli_fetch_assoc($result)){
      $recipe_list[$row['r_id']]  = array(
          "name"=>$row['recipe_name'],
          "img"=>$row['recipe_pic']
          
      );
              
        
        
        
    }
 
 
 
 ?>
    <head>
        <title>main dish</title>
         <link rel="stylesheet" href="mainDish_css.css" type="text/css">
    </head>
    
    <header>
       <input type ="text" name="search" placeholder="Search ...">
       <img src="tasty.png" alt="About us" >
       <button type="button" id="button"> Sign in/ Sign up</button>   
    </header>
    
   
    
    
    
    
    <nav> <!--Nav section-->
      <ul>
        <li> <a href="Home.php"> Home </a></li>
           <li >
          <div id="dropdown">
              <button onclick="dropFunction()" class="dropbtn">Recipes ^</button>
              <div id="myDropdown" class="drop-content">
                  <a href="mainDish.php">Main dishes</a>
                <a href="#">Salad</a>
                <a href="#">Dessert</a>
                <a href="#">Drinks</a>
                <a href="#">SeaFood</a>
              </div>
            </div>
            </li>
            <li><a href="About_us.php">About us</a></li> 
      </ul>
    </nav><!--End of Nav section-->
    
    
    
    <main><!--Main Dishes photo-->
        <img src="1.jpg" alt="photo" style="width: 1503px; height: 300px">
       <div class="top-left">
           <h2>Main Dishes</h2>
           <p>Hundreds of main dish recipes. Choose from</p>
           <p>comfort food, healthy, and vegetarian options.</p>
           <p>Find your dinner star now!</p>
        </div>
    </main><!--End of Main Dishes photo-->
    
    
    
    <body><!--Body-->
        
         <!--_____Sign in Code_____ -->
        
        <div  class="popup">
            <div class="pop-content" >
             <img src="tasty.png" alt="Photo" style="width:100px; height:90px">
             <img src="close-480.png" alt="new-recipe_pic"  class="close" style="width:30px; height:30px"> 
                
                <form><!--Sign in Form-->
                     <br><br>
                    <table>
                    <tr> <!--First row-->
                        <td>
                          <label for="email"><b>Email</b> </label>
                        </td>
                        <td> 
                           <input type="email" name="email>">
                        </td>
                    </tr>
                    <tr> <!--Second row-->
                        <td>
                            <label for="password"><b>Password</b></label>
                        </td>
                        <td>
                            <input type="password" name="password">
                        </td>
                    </tr>
                  </table>
              </form> <!--End of Sign in Form-->
                <br><br> 
                <a href="#" id="btn_sign">Sign in</a>
                <!-- ______Sign Up code_______-->
                <p>Are you a new member?<a href="#" id="btn_signUp" >Sign up</a></p>
            </div>             
        </div> <!-- End of Sign in code ----->
        
        
        
        
        <!-- ______Sign Up code_______-->
        
         <div  class="popup2">
            <div class="pop-content2" >
             <img src="tasty.png" alt="Photo" style="width:100px; height:90px">
             <img src="close-480.png" alt="new-recipe_pic"  class="close2" style="width:30px; height:30px"> 
                
                <form><!--Sign in Form-->
                     <br><br>
                    <table>
                     <tr> <!--First row-->
                        <td>
                          <label for="email"><b>Name</b> </label>
                        </td>
                        <td> 
                           <input type="text" name="name>">
                        </td>
                    </tr>
                    <tr> <!--Second row-->
                        <td>
                          <label for="email"><b>Email</b> </label>
                        </td>
                        <td> 
                           <input type="email" name="email>">
                        </td>
                    </tr>
                    <tr> <!--Third row-->
                        <td>
                            <label for="password"><b>Password</b></label>
                        </td>
                        <td>
                            <input type="password" name="password">
                        </td>
                    </tr>
                  </table>
              </form> <!--End of Sign up Form-->
                <br><br> 
                <a href="#" id="btn_sign2">Sign in</a>
                <!-- ______Sign Up code_______-->
            </div>             
        </div> <!-- End of Sign Up code ----->
        
    
        
        <div id="bodyContent"><!--Content of Body-->
        <div id="recipe">
            <h2> Recipes</h2>
        </div>
        <hr><!--Line-->
        
            
        <br><br><!--Recepies Photos-->
        <?php foreach ($recipe_list as $photo){ ?>
        <div id="column">
            <a href="pizzaRecipe.php"><img src="<?php echo $photo['img'];?>" alt="<?php echo $photo['name'];?>"></a>
             <h2><?php echo $photo['name'];?></h2>
        </div>
        <?php } ?>
        </div><!--End of Content Body-->
        
        
        
        
        
       <script>//--Java Script-->> 
      
     //<<__Dropdown list for Recipes Function__>>
      function dropFunction() {
      document.getElementById("myDropdown").classList.toggle("show");
      }
        
      window.onclick = function(event) {
      if (!event.target.matches('.dropbtn')) {
      var dropdowns = document.getElementsByClassName("drop-content");
        
      var i;
      for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
    //<<_______________Sign in Function_______________>>
      
          document.getElementById("button").addEventListener("click",function(){
              document.querySelector(".popup").style.display="flex";
         })
         
          document.querySelector(".close").addEventListener("click",function(){
             document.querySelector(".popup").style.display="none";
         })
           
           document.getElementById("btn_sign").addEventListener("click",function(){
              document.querySelector(".popup").style.display="none";
         })
            
      
   //<<_______________Sign Up Function_______________>>
          //if the user click on sign up at the Top..
          document.getElementById("btn_signUp").addEventListener("click",function(){
              document.querySelector(".popup2").style.display="flex";
              document.querySelector(".popup").style.display="none";
         })
         
         //if the user click on sign in..
           document.getElementById("btn_sign2").addEventListener("click",function(){
              document.querySelector(".popup2").style.display="none";
         })
         //if the user click on sign in on sign up window..
          document.querySelector(".close2").addEventListener("click",function(){
             document.querySelector(".popup2").style.display="none";
         })
      
      
   </script><!--End of Java Script--> 
        
</body><!--End of Body-->
    
</html>