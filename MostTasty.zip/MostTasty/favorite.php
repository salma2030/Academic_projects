<!DOCTYPE html>

<html>
    <head>
        <title>My favorite recipes</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
  #wrapper{
                margin: 0;
                width: 1000;
                
            }            
            
         #menuBar{
         background-color: #FFE4C4; 
         height: 130px;
          
      }
      #Pic_Name{
        width: 550px; 
        height: 60px;
        margin-left: 50px;
        margin-top: 11px;
         
      }  
      #services{
     
      width: 500px;  
      float:right;
      margin-top: -110px;
      margin-right: -138px;
     
        
      }
      
      #services img{
          //margin-right: -180px;
          cursor: pointer;
      }
      .profile_pic{
          
       width: 107px;
       height: 107px;   
       margin-top: 14px;   
      } 
      
            
      .user_name{
        color: grey; 
        font-size: 26px; 
        font-weight: bold;
         padding-top: 27px;
         float: right;
         margin-right: 230px;
         
      }
            #fav{
                position: absolute;
                top:280px;
                right:2600px;
                font-size: 60px; 
                font-weight: bold;
                padding-left: 15px;


            }

            .columncenter{
                background-color: #fff;  
                color:black; 
                width: 400px;
                height: 400px;
                float:left;
                margin: 15px;
                padding-top: 50px;
                text-align: center;
                margin-right: 30px;
                margin-left: 90px;
                font-size: 40px;
                font-weight: bold;

            }
            .columncenter img{
               width:350px;
               height:350px;
               
               
            }
            .columncenter > .first{
                font-size: 20px;
                margin-left: -20px;
                margin-top: 9px;
            }
            
            .columncenter img:hover{
                transform:scale(1.1,1.1); 

            }

            #return_pic{
                transition: 0.4s;
                cursor: pointer;   
            }

            .columncenter img{
                width:400px;
                height:400px;
            }
            
            .pop-content{
                height: 450px;
             width:450px;
             background: #fff;
             padding:20px;
             border-radius: 10px;
             margin-top: -100x;
             text-align: center;
             border: 1px solid grey;
             position: absolute;
             left: 530px;
             top: 200px;
             z-index:9999;
             
            }
            
            .popup{
                background: rgba (0,0,0,0.50);
             width:500px;
             height: 300px;
             margin-top: 100px;
            
             display:none;
             justify-content:center;
             align-items:center;
             
            }
            
            .close_optimal{
                position:absolute;
                background-color:#fff; 
                top:-15px;
                right:-15px;
                border-radius: 10px;
                box-shadow: 6px 6px 29px -4px rgba(0,0,0,0.75);
                cursor: pointer;}
            
            #button1_add{
            background-color: #FF8C00;
            color:#fff;
            width:400px;
            height: 50px;
           padding:10px 15px;
           text-decoration: none;
           border-radius: 5px;
           cursor: pointer;
           
            }
              #button1_add:hover{
            background-color: #D2691E;
           
           
            }
            


        </style>
    </head>
    <body>
       <?php 
            include("profile_header.php");
       ?>  
        <!--back icon-->
        
        <a href="Profile.php"><img src="return-icon.png" alt="add"  id="return_pic" style="width: 45px; height: 45px; padding-left: 70px; padding-top: 10px"> </a>
        <h2 id="fav">My Favorite list</h2>
        <hr>
        <div class="columncenter" id="column1"> <!--if  i want to use the class name it should be no space-->

            <a href="pizzaRecipe.php"><img src="pizza.jpg" ></a>
            <h2 class="first">Pizza</h2>  

        </div>
        <div class="columncenter" id="column2">

            <a href="pastaRecipe.php"><img src="pasta.jpg" ></a>
            <h2 class="first">Pasta</h2>  


        </div>
        
        <!---------------------optimal weight form--------------------------------->
    <div class="popup" 
         style="">
        
        
        <div class="pop-content" 
             style="">
            
            <img src="weight.png" alt="Optimal weight icon" style="width:60px; height:60px">
                   <img src="close-480.png" alt="new-recipe_pic"  class="close_optimal" style="width:30px; height:30px">  
                 <h4 >Calculate Optimal weight</h4>
                 <hr>
                 <div id="form_div">
                     <form name="optimal-weight-form" id="optimal-weight-form">
                         <label for="weight"> Weight*</label>
                         <input type="text" name="weight" id="weighid" placeholder="Kg">
                         
                         <br><br><br>
                         
                         
                         <label for="gender"> Gender*</label>
                         <input type="radio" name="gender" id="gender" >Female
                         <input type="radio" name="gender" id="gender">Male
                        
                         
                         <br><br><br>
                         <label for="Height">Height*</label>
                         <input type="text" name="Height" placeholder="Cm" id="heightid">
                         
                         <br><br><br>
                         <a href="javascript:void()" id="button1_add" class="cal_class" onclick="calculate_fun()" > Calculate</a>
                         <input type="reset" id="button1_add" class="clear_class" value="clear" onclick="reset()" 
                                style="width: 150px; height: 43px;
                                border-radius: 5px;
                                font-size: 18px;
                                padding:5px 5px;" >
                         
                         
                         <br><br>
                        
                         <span id="error" style="
                                color: red;
                                font-size: 14px;
                                visibility: hidden;">
                             * Fill all required fields</span>
                     </form>
                     
                 </div>
            
        </div>
    </div>
          
        <script>
             //-------------------Optimal weight form actions--------------------------------

    
    document.getElementById("weight_logo").addEventListener("click",function(){
               
              document.querySelector(".popup").style.display="flex"; 
             
    })
  
 //to make it clear and empty

 document.querySelector(".close_optimal").addEventListener("click",function(){
             var error_optimal= document.getElementById("error");
             document.querySelector(".popup").style.display="none";
            error_optimal.style.visibility='hidden';
              
         })
  
 
         
       
    
//-------------------Optimal weight form actions for contents-------------------
    //when press on calculate button
  
          function calculate_fun(){
               
              var weight_kg=document.getElementById("weighid");
              var height_kg=document.getElementById("heightid");
              var gend=document.getElementById("gender");
              var message=document.getElementById("error");
              
             if(weight_kg.value=="" || height_kg.value=="" || gend.value=="" ){
                 message.style.visibility="visible";
                 
             }
             
              if(weight_kg.value!="" && height_kg.value!="" && gend.value!="" ){
                 document.querySelector(".popup").style.display="none"; 
                 message.style.visibility="hidden";
                 
             }
             
             
    }//calculate_fun()
            
            
            
            
            
        </script>

    </body>
</html>
