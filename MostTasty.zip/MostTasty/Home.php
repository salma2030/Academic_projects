
<!Doctype html>
<?php 
    ob_start();
    session_start();
    include("db_config.php");
    
?>
<html>
 
    <head>
        <title>Most Tasty</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
         <link rel="stylesheet" href="Home_CSS.css" type="text/css">
         <style>
             #wrapper{
                 margin: auto;
                 
             }
             //
                 img{
                 float:right;
                 display: inline-block;
                 width: 100px;
                 align-content: center;
                 padding: 50px;
    
            }

            td img{
               width: 430px;
               height: 342px;
               padding:-20px;
               margin-right: 100px;
               margin-top: -30px;
               cursor: pointer;
            }
             td img:hover{
               
               cursor: pointer;
            }
            
            
            
            td>p{
                margin-left: -100px;
                text-align: center;
                margin-bottom: 40px;
            }
            
            #text b{
                font-size:40px;
                padding: 8px;
                margin-left: 200px;
            }
            
            #text:nth-child(2){
                font-size:20px;
                padding: 13px;
                margin-left: 29px;
                
            }
            
            #seperator>img{
                margin-top: -80px;
                margin-left: 50px;
                position: absolute;
            }
            .close{
                position:absolute;
                background-color:#fff; 
                top:-15px;
                right:-15px;
                border-radius: 10px;
                box-shadow: 6px 6px 29px -4px rgba(0,0,0,0.75);
                cursor: pointer;}
            
             input{
                text-align: center;
                font-size: 15px;
                margin-top: 3px; 
            }
            
           #button1_add{
            background-color: #FF8C00;
            color:#fff;
            width:400px;
            height: 50px;
           padding:10px 15px;
           text-decoration: none;
           border-radius: 5px;
           cursor: pointer;
           
            }
              #button1_add:hover{
            background-color: #D2691E;
           
           
            }
            
            
                 
            #logo{
               cursor: pointer; 
            }
            
          
            //sign up button in header
            #btn_sign2{
                           background-color: #800000;
                           color:#fff;
                           width:40px;
                           height: 50px;
                           padding:10px 15px;
                           text-decoration: none;
                           border-radius: 5px;
                           cursor: pointer;
                           box-shadow: 6px 6px 10px -4px rgba(0,0,0,0.75);
            }
            
            #btn_sign2:hover{
                box-shadow: 0px 0px 20px -4px rgba(0,0,0,0.75);

            }
            
            //-----------------------------------------------
            //sign up button in footer
            /*#btn_sign3{
                           background-color: #800000;
                           color:#fff;
                           width:40px;
                           height: 50px;
                           padding:10px 15px;
                           text-decoration: none;
                           border-radius: 5px;
                           cursor: pointer;
                           box-shadow: 6px 6px 10px -4px rgba(0,0,0,0.75);
            }*/
            
            #btn_sign3:hover{
                box-shadow: 0px 0px 20px -4px rgba(0,0,0,0.75);

            }

             
           

           
             
     
         </style>
    </head>
    
    <header>
       
       <input type ="text" name="search" placeholder="Search ...">
       <a href="Home.html">
       <img src="tasty.png" alt="www.MostTasty.com" id="logo"  style="width:130px ;height:110px;top:15px;right:668px;position: absolute ">
       </a>
       <button type="button" id="button"> Sign in/ Sign up</button>
    </header>
    
    <nav>
      <ul>
        <li> <a href="Home.html"> Home </a></li>
          <li >
          <div id="dropdown">
              <button onclick="dropFunction()" class="dropbtn">Recipes ^</button>
              <div id="myDropdown" class="drop-content">
                <a href="mainDish.php">Main dishes</a>
                <a href="#">Salad</a>
                <a href="#">Dessert</a>
                <a href="#">Drinks</a>
                <a href="#">SeaFood</a>
              </div>
            </div>
            </li>
            
            <li><a href="About_us.php">About us</a></li> 
      </ul>
    </nav>
    
    
    
    <body style=" overflow-x: hidden">
        <div id="wrapper" >
            
            
     <!----------Sign in for header-------------------------------------------->
        
        <div  class="popup1">
            <div class="pop-content1" >
             <img src="tasty.png" alt="Photo" style="width:100px; height:90px">
             <img src="close-480.png" alt="new-recipe_pic"  class="close1" style="width:30px; height:30px"> 
                
             <form name="signin-form" method="POST" action="check_signin.php"><!--Sign in Form-->
                     <br><br>
                    <table>
                    <tr> <!--First row-->
                        <td>
                          <label for="email"><b>Email</b> </label>
                        </td>
                        <td> 
                            <input type="email" name="email" id="email_text">
                        </td>
                    </tr>
                    <tr> <!--Second row-->
                        <td>
                            <label for="password"><b>Password</b></label>
                        </td>
                        <td>
                            <input type="password" name="password" id="pass_text">
                        </td>
                    </tr>
                  </table>
                     <br><br> 
                     <input type="submit" id="btn_sign" name="signIn_btn" style=" width: 100px;"  value="Sign In">
              </form> <!--End of Sign in Form-->
                <br><br> 
                <!--<button id="btn_sign" name="signIn_btn" style=" width: 100px;">Sign in</button>-->
                <!-- ______Sign Up code_______-->
                <p>Are you a new member?<a href="#" id="btn_signUp" >Sign up</a></p>
                
                <!--<span id="error1" style="
                      color: red;
                      font-size: 14px;
                       visibility:hidden;">* wrong </span>-->
                
                <?php if(@$_GET['Empty']== TRUE){ ?>
                
                <div class="alert-light text-danger text-center py-3" style=" color: red"> <?php echo @$_GET['Empty'];?></div>
                <?php }?>
                
                <?php if(@$_GET['invalid']== TRUE){ ?>
                
                <div class="alert-light text-danger text-center py-3" style=" color: red"> <?php echo @$_GET['invalid'];?></div>
                <?php }?>

            </div>             
        </div> <!-- End of Sign in code ----->
        
          
        
      <!---------------------Sign Up code for header------------------------------------->
      
        
         <div  class="popup2">
            <div class="pop-content2" >
             <img src="tasty.png" alt="Photo" style="width:100px; height:90px">
             <img src="close-480.png" alt="new-recipe_pic"  class="close2" style="width:30px; height:30px"> 
                
             <form method="POST" action="check_singup.php"><!--Sign in Form-->
                     <br><br>
                    <table>
                     <tr> <!--First row-->
                        <td>
                          <label for="name"><b>Name</b> </label>
                        </td>
                        <td> 
                            <input type="text" name="name" id="name_text_signup">
                        </td>
                    </tr>
                    <tr> <!--Second row-->
                        <td>
                          <label for="email"><b>Email</b> </label>
                        </td>
                        <td> 
                           <input type="email" name="email" id="email_text_signup">
                        </td>
                    </tr>
                    <tr> <!--Third row-->
                        <td>
                            <label for="password"><b>Password</b></label>
                        </td>
                        <td>
                            <input type="password" name="password" id="pass_text_signup">
                        </td>
                    </tr>
                  </table>
                     <br><br>
                     <input type="submit" id="btn_sign2" name="signup" style="width: 100px" value="Sign up" >
              </form> <!--End of Sign in Form-->
                 
                
                <br>
               
                <?php if(@$_GET['Emptyfield']==TRUE) {?>
                <div class="alert-light text-danger py-3" style="color: red"><?php echo @$_GET['Emptyfield'];?></div>
                <?php }?>
                
                 <?php if(@$_GET['notsuccess']==TRUE) {?>
                <div class="alert-light text-danger py-3" style="color: red"><?php echo @$_GET['notsuccess'];?></div>
                <?php }?>
            </div>             
        </div> <!-- End of Sign Up code ----->
        
        <!-----------------Sign Up code for footer----------------------------->
        
        <div  class="popup3" style=" 
        background: rgba (0,0,0,0.50);
        display:none;
        justify-content:center;
        align-items:center;">
            
            <div class="pop-content3" style=" width:350px;
             height: 410px;
             background: #fff;
             padding:20px;
             border-radius: 30px;
             margin-top: -100x;
             text-align: center;
             border: 2px solid grey;
             position:absolute;
             left: 530px;
             top: 1130px;
             box-shadow: 6px 6px 50px -4px rgba(0,0,0,0.75);
             z-index:9999;" >
                
             <img src="tasty.png" alt="Photo" style="width:100px; height:90px">
             <img src="close-480.png" alt="new-recipe_pic"  class="close3" style="width:30px; height:30px;
                position: absolute;
                background-color:#fff; 
                top:-15px;
                right:-15px;
                border-radius: 10px;
                box-shadow: 6px 6px 29px -4px rgba(0,0,0,0.75);
                cursor: pointer;"> 
                
                <form><!--Sign in Form-->
                     <br><br>
                    <table>
                     <tr> <!--First row-->
                        <td>
                          <label for="name"><b>Name</b> </label>
                        </td>
                        <td> 
                           <input type="text" name="name" id="name1_text_signup">
                        </td>
                    </tr>
                    <tr> <!--Second row-->
                        <td>
                          <label for="email"><b>Email</b> </label>
                        </td>
                        <td> 
                           <input type="email" name="email" id="email1_text_signup">
                        </td>
                    </tr>
                    <tr> <!--Third row-->
                        <td>
                            <label for="password"><b>Password</b></label>
                        </td>
                        <td>
                            <input type="password" name="password" id="pass1_text_signup">
                        </td>
                    </tr>
                  </table>
              </form> <!--End of Sign in Form-->
                <br><br> 
                <a href="javascript:void()" id="btn_sign3" style="
                     background-color: #800000;
                           color:#fff;
                           width:40px;
                           height: 50px;
                           padding:10px 15px;
                           text-decoration: none;
                           border-radius: 5px;
                           cursor: pointer;
                           box-shadow: 6px 6px 10px -4px rgba(0,0,0,0.75);
                   
                   ">Sign up</a>
                <br>
                <span id="error3" style=" position:absolute;
            color: red;
            font-size: 14px;
            visibility: hidden;
            position: absolute;
            top:425px;
            left: 110px;">
             
                    * Fill all required fields</span>
            </div>             
        </div> <!-- End of Sign Up code ----->
        
    <!-----------------------------Slider Show--------------------------------->


<div class="slideshow-container">
<!--slide1-->
<div class="mySlides fade" style="width:1503px; height:400px;" >
  <div class="numbertext"><b>1 / 3</b></div>
  <img src="saw.jpg" alt="Slide1" >
</div>
<!--slide2-->
<div class="mySlides fade" style="width:1503px; height:400px;">
    <div class="numbertext"><b>2 / 3</b></div>
    <img src="ss.jpg" alt="slide2" >
  
</div>
<!--slide3-->
<div class="mySlides fade" style="width:1503px; height:400px;">
  <div class="numbertext"><b>3 / 3</b></div>
  <img src="logt.jpg" alt="Slide3" >
  
</div>

</div>
<br>
<!--dots-->
<div style="text-align:right; position: absolute; top: 600px;  right: 700px; ">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
</div>

   <!-----------------------------recipes-------------------------------------->
   <div id="recipes" style=" position: absolute;top: 650px;width: 1503px; height: 400px">
     
       
       <table>
           
           <!--captions-->
            <tr>
               <td><p>Pancake</p></td>
               <td><p>Italian Salad</p></td>
               <td><p>Creamy Seafood Chowder</p></td>
               
           </tr>
           
           <!--images-->
           <tr>
               <td><img src="pancake.jpg" style=""></td>
               <td><img src="salad.jpg" style=""></td>
               <td><img src="seaood.jpg" style=""></td>
           </tr>
           
          
           
       </table>
   </div>
   
   <!--------------------------- Text + Video ---------------------------------->
   <div id="video_container" class="V_container" style="background-color: #ADD8E6;
            position: absolute;
            top: 1050px;
            width: 1503px;
            height: 430px;">
       <!---insert the video-->
       <div id="video_content" >
           <video src="vid.mp4" controls 
                  poster="poster.jpg"
                  style="position:absolute; padding: -20px;width:700px; top:20px;right: 20px;">
                      
           </video>
           
       </div>
       <div id="text">
           <p><b>MostTasty</b></p>
           <p>is a daily food web celebrating life in the kitchen through home cooking.<br>
               This is a site for people who like to get their hands dirty while they cook.<br>
           It is for those who care about the quality of their food, and how it affects the<br>
           health of themselves and the planet</p>
           
       </div>
       
       <!--seperator-->
       <div id="seperator">
           <img src="sepertaor.png" style=" margin-bottom: -60px;">
       </div>
       
       
   </div>
   
   <!--------------------footer------------------------------------------------>
        <footer>
            <div id="column">
            <h2>Most Tasty</h2>
             <p>About Us</p>
             <p>Recipes</p>
             <p> Get Help</p>
            </div>
         <div id="column">
            <h2>Services</h2>
             <p id="optimal-weight">Optimal Weight</p>
             <p>_____</p>
             <p>_____</p>
            </div>
         <div id="column">
             <h2>Follow Us</h2>
                <div id="column2">
                   <img src="facebook.jpg" alt="Facebook" title="@Most_Tasty">
                </div>
                <div id="column2">
                   <img src="Twitter-icon.png" alt="Tweeter"title="@Most_Tasty">
                </div>
                 <div id="column2">
                   <img src="instagram2.png" alt="Instagram" title="@Most_Tasty">
                </div>
            </div>
            <div id="column">
               <h2>Contact Us</h2>
               <p> Most Tasty</p>
               <p><a href="#">WWW.MostTasty.com</a></p>
               <p>+966 530 639 703</p>
            </div>
            <div id="column">
            <br><br><br>
            <button type="button" id="btn2_sginUp">Sign Up</button>
            
            </div>
        </footer>
   <!---------------------optimal weight form--------------------------------->
    <div class="popup" 
         style="background: rgba (0,0,0,0.50);
             width:500px;
             height: 300px;
             margin-top: 100px;
            
             display:none;
             justify-content:center;
             align-items:center;">
        
        
        <div class="pop-content" 
             style="height: 450px;
             width:450px;
             background: #fff;
             padding:20px;
             border-radius: 10px;
             margin-top: -100x;
             text-align: center;
             border: 1px solid grey;
             position: absolute;
             left: 530px;
             top: 1130px;">
            
            <img src="weight.png" alt="Optimal weight icon" style="width:60px; height:60px">
                   <img src="close-480.png" alt="new-recipe_pic"  class="close" style="width:30px; height:30px">  
                 <h4 >Calculate Optimal weight</h4>
                 <hr>
                 <div id="form_div">
                     <form name="optimal-weight-form" id="optimal-weight-form">
                         <label for="weight"> Weight*</label>
                         <input type="text" name="weight" id="weighid" placeholder="Kg">
                         
                         <br><br><br>
                         
                         
                         <label for="gender"> Gender*</label>
                         <input type="radio" name="gender" id="gender" >Female
                         <input type="radio" name="gender" id="gender">Male
                        
                         
                         <br><br><br>
                         <label for="Height">Height*</label>
                         <input type="text" name="Height" placeholder="Cm" id="heightid">
                         
                         <br><br><br>
                         <a href="javascript:void()" id="button1_add" class="cal_class" onclick="calculate_fun()" > Calculate</a>
                         <input type="reset" id="button1_add" class="clear_class" value="clear" onclick="reset()" 
                                style="width: 150px; height: 43px;
                                border-radius: 5px;
                                font-size: 18px;
                                padding:5px 5px;" >
                         
                         
                         <br><br>
                        
                         <span id="error" style="
                                color: red;
                                font-size: 14px;
                                visibility: hidden;">
                             * Fill all required fields</span>
                     </form>
                     
                 </div>
            
        </div>
    </div>
   
   </div><!--wrapper-->
    
   
   
   
   
   
   
   
   
   <!-----------------------------Script---------------------------------------> 
   
   
       <script>
    function dropFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
     }
        
    window.onclick = function(event) {
    if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("drop-content");
        
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

//Slideshow

var slideIndex = 0;
showSlides();
function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}

//-----------------Sign in Function---------------------------------------------
           /*document.getElementById('btn_sign').addEventListener("click",function(){
              var email_get=document.getElementById("email_text").value;
              var pass_get=document.getElementById("pass_text").value;
              var message1=document.getElementById("error1");
              
              if(email_get=="" || pass_get==""){
                  message1.style.visibility="visible";
                  
              }
              
         })*/
     
          document.getElementById("button").addEventListener("click",function(){
              document.querySelector(".popup1").style.display="flex";
         })
         
          document.querySelector(".close1").addEventListener("click",function(){
             document.querySelector(".popup1").style.display="none";
             document.getElementById("error1").style.visibility="hidden";
         })
         
        
       
          
//-------------------------sign up--------------------------------------------

//<<----------------Sign Up Function for header------------------------------->>

          //if the user clicks on sign up at the header..
          document.getElementById("btn_signUp").addEventListener("click",function(){
              document.querySelector(".popup2").style.display="flex";
              document.querySelector(".popup1").style.display="none";
         })
         
         //if the user clicks on sign in
           document.getElementById("btn_sign2").addEventListener("click",function(){
              var get_name=document.getElementById("name_text_signup");
              var get_email=document.getElementById("email_text_signup");
              var get_pass=document.getElementById("pass_text_signup");
              var message2=document.getElementById("error2");
              
              if(get_email.value=="" || get_pass.value=="" || get_name.value=="" ){
                  message2.style.visibility="visible";
                  
              }//if
              
               if(get_pass.value!="" && get_email.value!="" && get_name.value!="" ){
                  document.querySelector(".popup2").style.display="none";
                  message2.style.visibility="hidden";
                 
             }
             
         })
         
         //if the user click on sign in on sign up window..
          document.querySelector(".close2").addEventListener("click",function(){
             document.querySelector(".popup2").style.display="none";
             document.getElementById("error2").style.visibility="hidden";
         })
      
  //<<----------------Sign Up Function for footer-------------------------------
  
  //sign up in footer
            document.getElementById("btn2_sginUp").addEventListener("click",function(){
                document.querySelector(".popup3").style.display="flex";
               
            })
         
         
           //if the user clicks on sign in
           document.getElementById("btn_sign3").addEventListener("click",function(){
              var get_name=document.getElementById("name1_text_signup");
              var get_email=document.getElementById("email1_text_signup");
              var get_pass=document.getElementById("pass1_text_signup");
              var message3=document.getElementById("error3");
              
              if(get_email.value=="" || get_pass.value=="" || get_name.value=="" ){
                  message3.style.visibility="visible";
                  
              }//if
              
               if(get_pass.value!="" && get_email.value!="" && get_name.value!="" ){
                 document.querySelector(".popup3").style.display="none";
                 message3.style.visibility="hidden";
                 
             }
             
         })
         
         
         //if the user click on sign in on sign up window..
          document.querySelector(".close3").addEventListener("click",function(){
             document.querySelector(".popup3").style.display="none";
            document.getElementById("error3").style.visibility="hidden";
         })
          
             

//-------------------Optimal weight form actions--------------------------------

 document.getElementById("optimal-weight").addEventListener("click",function(){
               
              document.querySelector(".popup").style.display="flex"; 
             
    })
  
 //to make it clear and empty

 document.querySelector(".close").addEventListener("click",function(){
             var error_optimal= document.getElementById("error");
             document.querySelector(".popup").style.display="none";
            error_optimal.style.visibility='hidden';
              
         })
         
       
    
//-------------------Optimal weight form actions for contents-------------------
    //when press on calculate button
  
          function calculate_fun(){
               
              var weight_kg=document.getElementById("weighid");
              var height_kg=document.getElementById("heightid");
              var gend=document.getElementById("gender");
              var message=document.getElementById("error");
              
             if(weight_kg.value=="" || height_kg.value=="" || gend.value=="" ){
                 message.style.visibility="visible";
                 
             }
             
              if(weight_kg.value!="" && height_kg.value!="" && gend.value!="" ){
                 document.querySelector(".popup").style.display="none"; 
                 message.style.visibility="hidden";
                 
             }
             
             
    }//calculate_fun()
    













</script>
      
    </body>
    

   
</html>
