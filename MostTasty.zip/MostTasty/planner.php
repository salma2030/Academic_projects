<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>My planner</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <style>
         
 #menuBar{
         background-color: #FFE4C4; 
         height: 130px;
          
      }
      #Pic_Name{
        width: 550px; 
        height: 60px;
        margin-left: 50px;
        margin-top: 11px;
         
      }  
      #services{
     
      width: 500px;  
      float:right;
      margin-top: -110px;
      margin-right: -138px;
     
        
      }
      
      #services img{
          //margin-right: -180px;
          cursor: pointer;
      }
      .profile_pic{
          
       width: 107px;
       height: 107px;   
       margin-top: 14px;   
      } 
      .user_name{
        color: grey; 
        font-size: 26px; 
        font-weight: bold;
         padding-top: 27px;
         float: right;
         margin-right: 230px;
         
      }
         #planner_word{
          position: absolute;
          top:130px;
          left:150px;
          font-size: 30px; 
          font-weight: bold;
          padding-left: -70px;
      }
      #plan_meals{
          width: 100px;
          height: 100px;
          padding: 10px;
      }
      
      .circle{
         width:190px;
         height: 100px;
         background-color: #90EE90;
         margin: 10% auto;
         border-radius: 50%;
         float: right;
         border: 1px solid black;
         margin-left: 50px;
         padding: -1000px;
         
      }
     
      
      .Frist_row{
         
          margin-top: 100px;
          width:900px;
         
         margin-left:-120px;
        
         
      }
      .second_row{
        
         width:900px;
         
         margin-left:-120px;
      } 
      .meal{
        margin-top: 55px;  
         margin-left: 70px;
         font-size: 20px;
         width: 200px;
      }
      
      .Cal{
        margin-top: 50px;
         font-size: 20px;
        margin-left: 65px;
      }
      
       #return_pic{
                transition: 0.4s;
                cursor: pointer;   
            }
            .date_tracker{
                float: right;
                
            }
           
            
            .date{
                position: absolute;
                top:230px;
                right: 400px;
                font-size: 20px;
            }
            #button_previous{
                width:70px;
                height: 70px;
                border-radius: 20%;
                background-color: grey;
                color: white; 
                margin-right: 30px;
                font-size:40px; 
                 cursor: pointer; 
            }
            #button_next{
                width:70px;
                height:70px;
                border-radius: 20%;
                background-color: grey;
                color: white;
                margin-left: 30px;
                font-size:40px;
                cursor: pointer; 
            }
            
            svg {
             position: relative;
             width:150px;
             height: 150;
             z-index: 1000;
            }
            svg circle{
               width:70px;
               height: 70px;
               stroke:#191919;
               stroke-width:20;
               stroke-linecap:round;
               fill:none;
               transform: translate(5px,5px);
               stroke-dasharray:440;
               stroke-dashoffset:440;
               /*to make the circle complete*/
            }
            
            svg circle:nth-child(1){
              stroke-dashoffset:0; 
              stroke:#f3f3f3;
            }
             svg circle:nth-child(2){
              stroke-dashoffset:calc(1895 - ( 1895 *50)/100); 
              stroke:#03a9f4;
            }
            
            .container{
                position: absolute;
                
                top:400px;
                right: 30px;
                width: 900px;
                display: flex;
                justify-content:space-around;
            }
            
            .meal_cal_number{
                position: absolute;
                top:65px;
                right: 200px;
                width:400px;
                height: 100px;
                display: flex;
                justify-content:center;
                align-items:center;
                border-radius: 50%;
                font-size: 15px;
            }
            .meal_cal_number h2 span{
                font-size: 35px;
                color:red;
                transition:0.5s;
            }
            
            .pop-content{
                height: 450px;
             width:450px;
             background: #fff;
             padding:20px;
             border-radius: 10px;
             margin-top: -100x;
             text-align: center;
             border: 1px solid grey;
             position: absolute;
             left: 530px;
             top: 200px;
             z-index:9999;
             
            }
            
            .popup{
                background: rgba (0,0,0,0.50);
             width:500px;
             height: 300px;
             margin-top: 100px;
            
             display:none;
             justify-content:center;
             align-items:center;
             
            }
            
            .close_optimal{
                position:absolute;
                background-color:#fff; 
                top:-15px;
                right:-15px;
                border-radius: 10px;
                box-shadow: 6px 6px 29px -4px rgba(0,0,0,0.75);
                cursor: pointer;}
            
            #button1_add{
            background-color: #FF8C00;
            color:#fff;
            width:400px;
            height: 50px;
           padding:10px 15px;
           text-decoration: none;
           border-radius: 5px;
           cursor: pointer;
           
            }
              #button1_add:hover{
            background-color: #D2691E;
           
           
            }
            
           
        </style>
    </head>
    <body style=" overflow-x: hidden">
          <?php 
            include("profile_header.php");
       ?>
        
              <!--end menuBar-->
              <a href="Profile.php"><img src="return-icon.png" alt="add"  id="return_pic" style="width: 45px; height: 45px; padding-left: 70px; padding-top: 10px"> </a> 
          <h2 id="planner_word">Make a Planner</h2>
         
          
          
          <div class="Frist_row">
              <div class="circle" >
              <div class="content">
                  <h3 class="Cal">0 Cal</h3> 
              </div>  
              <h2 class="meal">Dinner</h2> 
          </div>
          
           <div class="circle">
              <div class="content">
                  <h3 class="Cal">0 Cal</h3> 
              </div>  
               <h2 class="meal">Lunch</h2> 
          </div>
          
          
           <div class="circle" >
              <div class="content">
                  <h3 class="Cal">100 Cal</h3> 
              </div>  
              <h2 class="meal">Breakfast</h2> 
          </div>
          
          </div>
          <!--frist row-->
          
          <div class="second_row">
           <div class="circle">
              <div class="content">
                  <h3 class="Cal">0 Cal</h3> 
              </div>  
              <h2 class="meal"  style=" right:694px; bottom: -130px ;position: absolute">Snack After Dinner</h2> 
          </div>
          
          
           <div class="circle">
              <div class="content">
                  <h3 class="Cal">0 Cal</h3> 
              </div>  
              <h2 class="meal" style=" right: 955px ;bottom: -130px ; position: absolute">Snack After Lunch</h2> 
          </div>
          
          
           <div class="circle">
              <div class="content">
                  <h3 class="Cal">0 Cal</h3> 
              </div>  
              <h2 class="meal" style="right: 1220px ;bottom: -130px ; position: absolute">Snack After Breackfast</h2> 
          </div>
          
          </div>
          
          
          
          <div class="date">
              <input type="button" value=">>" class="date_tracker"  id="button_next" onclick="next_date()">
          <p class="date_tracker" id="demo"></p>
          <input type="button" value="<<"  class="date_tracker" id="button_previous" onclick="previous_date()">
          
          
         </div>
          
         
          <div  class="container">
              <div class="card">
                  <div class="box">
                      <div class="percent">
                          <svg>
                          <circle cx="120" cy="120" r="120" style=""></circle>
                          <circle cx="120" cy="120" r="120"></circle>
                          </svg> 
                          <div class="meal_cal_number">
                              <h2>Calories 1600/<span>150</span></h2> 
                          </div>
                      </div>
                      
                  </div>
              </div>
          </div>
          
           <!---------------------optimal weight form--------------------------------->
    <div class="popup" 
         style="">
        
        
        <div class="pop-content" 
             style="">
            
            <img src="weight.png" alt="Optimal weight icon" style="width:60px; height:60px">
                   <img src="close-480.png" alt="new-recipe_pic"  class="close_optimal" style="width:30px; height:30px">  
                 <h4 >Calculate Optimal weight</h4>
                 <hr>
                 <div id="form_div">
                     <form name="optimal-weight-form" id="optimal-weight-form">
                         <label for="weight"> Weight*</label>
                         <input type="text" name="weight" id="weighid" placeholder="Kg">
                         
                         <br><br><br>
                         
                         
                         <label for="gender"> Gender*</label>
                         <input type="radio" name="gender" id="gender" >Female
                         <input type="radio" name="gender" id="gender">Male
                        
                         
                         <br><br><br>
                         <label for="Height">Height*</label>
                         <input type="text" name="Height" placeholder="Cm" id="heightid">
                         
                         <br><br><br>
                         <a href="javascript:void()" id="button1_add" class="cal_class" onclick="calculate_fun()" > Calculate</a>
                         <input type="reset" id="button1_add" class="clear_class" value="clear" onclick="reset()" 
                                style="width: 150px; height: 43px;
                                border-radius: 5px;
                                font-size: 18px;
                                padding:5px 5px;" >
                         
                         
                         <br><br>
                        
                         <span id="error" style="
                                color: red;
                                font-size: 14px;
                                visibility: hidden;">
                             * Fill all required fields</span>
                     </form>
                     
                 </div>
            
        </div>
    </div>
          
          
          
          
          
        <script>
            
   var d = new Date();
   
  document.getElementById("demo").innerHTML = d;
  
  function next_date(){
   var d = new Date();
   d.setDate(d.getDate() +1);
  document.getElementById("demo").innerHTML = d;
     
      
  }
   function previous_date(){
   var d = new Date();
   d.setDate(d.getDate() -1);
  document.getElementById("demo").innerHTML = d;
     
      
  }
  
  //-------------------Optimal weight form actions--------------------------------

    
    document.getElementById("weight_logo").addEventListener("click",function(){
               
              document.querySelector(".popup").style.display="flex"; 
             
    })
  
 //to make it clear and empty

 document.querySelector(".close_optimal").addEventListener("click",function(){
             var error_optimal= document.getElementById("error");
             document.querySelector(".popup").style.display="none";
            error_optimal.style.visibility='hidden';
              
         })
  
 
         
       
    
//-------------------Optimal weight form actions for contents-------------------
    //when press on calculate button
  
          function calculate_fun(){
               
              var weight_kg=document.getElementById("weighid");
              var height_kg=document.getElementById("heightid");
              var gend=document.getElementById("gender");
              var message=document.getElementById("error");
              
             if(weight_kg.value=="" || height_kg.value=="" || gend.value=="" ){
                 message.style.visibility="visible";
                 
             }
             
              if(weight_kg.value!="" && height_kg.value!="" && gend.value!="" ){
                 document.querySelector(".popup").style.display="none"; 
                 message.style.visibility="hidden";
                 
             }
             
             
    }//calculate_fun()
  
  </script>
    </body>
</html>
