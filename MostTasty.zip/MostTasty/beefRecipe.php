<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Beef Recipe</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <link rel="stylesheet" href="Recipe_Design.css" type="text/css">
    </head>
    <body style="overflow-x: hidden">
       <header>
             <div id="menuBar">
                <div id="Pic_Name" >
                 <img src="pic.png" class="profile_pic" alt="profile_pic" >
                 <img src="pencil.png"  id="edit" alt="profile_pic" style="width: 35px; height:35px">
                 <h4  class="user_name" style=" padding-left: -30px">Mohammed</h4>
                </div>
    
                <div id="services" >
                    <a href="favorite.html"><img src="f.png" alt="profile_pic" style="width: 80px; height: 80px;"></a>
                    <a href="javascript:void()" id="weight_logo">
                        <img src="weight.png" alt="profile_pic" style="width: 70px; height: 70px;"></a> 
                  
                    <a href="planner.html"><img src="planner.png" alt="profile_pic" style="width:70px; height: 70px"></a>
                  <a href="Home_After_signin.html"><img src="Home-icon.png" alt="profile_pic" style="width:70px; height:70px"></a>
                </div>
      
           </div>
      </header>  
         <a href="Profile.html"><img src="return-icon.png" alt="add"  id="return_pic" style="width: 45px; height: 45px; padding-left: 70px; padding-top: 10px"> </a>
        <h2 id="p_name">Beef</h2>
        
        <hr>
        <div class="columncenter" id="column1">
                    
                    <img src="beef.jpg" >
                      <img   id="like" onclick="Like_counter()" src="like.jpg" >
                    <p id="like_num"  ></p>
                    
                      <p>Rating:</p>
                   <div class="stars" data-rating="0">
                   <span class="star">&nbsp;</span>
                   <span class="star">&nbsp;</span>
                   <span class="star">&nbsp;</span>
                  <span class="star">&nbsp;</span>
                  <span class="star">&nbsp;</span>
                </div>
               <div id="meal_cook_time">
                <h3> COOK TIME 2 hour </h3> 
             </div>  
                      
                 
                     
                     <a href="javascript:void()" id="comment_button">Write a comment</a>
                
                    
                </div>
        
        
        <div class="columncenter" id="column2"  >
            
            <div id="num_cal"><h3>cal:1000</h3></div>
              
            <h3>For the Beef Tenderloin:</h3>  
                
            
            <ul>
                <li>1 center-cut beef tenderloin, 3 pounds</li>
                <li>Salt</li>
                <li>1 ounce dried porcini mushrooms</li>
                <li>2 tablespoons fresh rosemary leaves, finely chopped</li>
                <li> 1 teaspoon black peppercorns</li>
                <li>Olive oil</li>
               
            </ul>
                <h3>For the Port Wine Sauce:</h3>
                <ul>
                <li>1/2 ounce dried porcini mushrooms, reconstituted in 3/4 cup water, liquid reserved</li>
                <li>3 tablespoons unsalted butter, divided</li>
                <li>1 medium shallot, finely chopped</li>
                <li>1 cup port wine</li>
                 <li>1 cup heavy bodied red wine</li>
                 <li>2 rosemary sprigs</li>
                 <li>1/2 teaspoon salt, or to taste</li>
          
            </ul> 
            

        </div>
        
                    <!---------------------optimal weight form--------------------------------->
    <div class="popup" 
         style="">
        
        
        <div class="pop-content" 
             style="">
            
            <img src="weight.png" alt="Optimal weight icon" style="width:60px; height:60px">
                   <img src="close-480.png" alt="new-recipe_pic"  class="close_optimal" style="width:30px; height:30px">  
                 <h4 >Calculate Optimal weight</h4>
                 <hr>
                 <div id="form_div">
                     <form name="optimal-weight-form" id="optimal-weight-form">
                         <label for="weight"> Weight*</label>
                         <input type="text" name="weight" id="weighid" placeholder="Kg">
                         
                         <br><br><br>
                         
                         
                         <label for="gender"> Gender*</label>
                         <input type="radio" name="gender" id="gender" >Female
                         <input type="radio" name="gender" id="gender">Male
                        
                         
                         <br><br><br>
                         <label for="Height">Height*</label>
                         <input type="text" name="Height" placeholder="Cm" id="heightid">
                         
                         <br><br><br>
                         <a href="javascript:void()" id="button1_add" class="cal_class" onclick="calculate_fun()" > Calculate</a>
                         <input type="reset" id="button1_add" class="clear_class" value="clear" onclick="reset()" 
                                style="width: 150px; height: 43px;
                                border-radius: 5px;
                                font-size: 18px;
                                padding:5px 5px;" >
                         
                         
                         <br><br>
                        
                         <span id="error" style="
                                color: red;
                                font-size: 14px;
                                visibility: hidden;">
                             * Fill all required fields</span>
                     </form>
                     
                 </div>
            
        </div>
    </div>
         <script>
            
         function Like_counter(){
             
             var i=0;
            
             i++;
              
             
            document.getElementById("like_num").innerHTML =i; 
        }
        
        
         document.addEventListener('DOMContentLoaded', function(){
         addListeners();
         setRating(); //based on value inside the div
        });

      function addListeners(){
       var stars = document.querySelectorAll('.star');
       [].forEach.call(stars, function(star, index){
       star.addEventListener('click', (function(idx){
       console.log('adding rating on', index);
       document.querySelector('.stars').setAttribute('data-rating',  idx + 1);  
       console.log('Rating is now', idx+1);
      setRating();
      }).bind(window,index) );
      });
  
        }

      function setRating(){
        var stars = document.querySelectorAll('.star');
        var rating = parseInt( document.querySelector('.stars').getAttribute('data-rating') );
        [].forEach.call(stars, function(star, index){
        if(rating > index){
        star.classList.add('rated');
        console.log('added rated on', index );
       }else{
       star.classList.remove('rated');
       console.log('removed rated on', index );
         }
        });
        }
         //-------------------Optimal weight form actions--------------------------------

    
    document.getElementById("weight_logo").addEventListener("click",function(){
               
              document.querySelector(".popup").style.display="flex"; 
             
    })
  
 //to make it clear and empty

 document.querySelector(".close_optimal").addEventListener("click",function(){
             var error_optimal= document.getElementById("error");
             document.querySelector(".popup").style.display="none";
            error_optimal.style.visibility='hidden';
              
         })
  
 
         
       
    
//-------------------Optimal weight form actions for contents-------------------
    //when press on calculate button
  
          function calculate_fun(){
               
              var weight_kg=document.getElementById("weighid");
              var height_kg=document.getElementById("heightid");
              var gend=document.getElementById("gender");
              var message=document.getElementById("error");
              
             if(weight_kg.value=="" || height_kg.value=="" || gend.value=="" ){
                 message.style.visibility="visible";
                 
             }
             
              if(weight_kg.value!="" && height_kg.value!="" && gend.value!="" ){
                 document.querySelector(".popup").style.display="none"; 
                 message.style.visibility="hidden";
                 
             }
             
             
    }//calculate_fun()
         
         </script> 
       
    </body>
</html>
