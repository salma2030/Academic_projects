<?php
ob_start();

include("db_config.php");
    if(isset($_POST['signup'])){
        
       // echo 'nnnnnnnnnnnn';  
        if(empty($_POST['name']) || empty($_POST['email']) || empty($_POST['password'])){
            header("location:Home.php?Emptyfield=**Please Fill All the Blanks to Sign up**");
        }
        else{
        $username=$_POST['name'];
        $userEmail=$_POST['email'];
        $userpassword=$_POST['password'];
        
       $query="INSERT INTO user SET name='$username', email='$userEmail', password='$userpassword'";
       $result=  mysqli_query($con, $query);
           if($result){
           //echo"your infoemation inserted Successfully";
          
            header("Location:Home_After_signin.php");
            exit();
            }
            else{
                header("location:Home.php?notsuccess=**The information is not inserted successfully.Please Try again**");
                exit();
            }
        }
 
      
    }
       




?>