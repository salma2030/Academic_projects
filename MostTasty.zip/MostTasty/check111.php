<?php

ob_start();
session_start();

include("db_config.php");

if(isset($_POST['add'])){//recipe
    
   //$recipe_name=$_POST['recipe_name'];
   //$recipe_cal=$_POST['recipe_cal'];
   //$recipe_type=$_POST['select_type'];
    
    if(empty($_POST['recipe_name']) || empty($_FILES)|| empty($_POST['recipe_cal'])  || $_POST['select_type']=="default"
          || empty($_POST['recipe_details'])  ){
            header("location:Profile.php?Emptyfield=**Please Fill All the Blanks**");
    } 
        
    else{
        $recipe_name=$_POST['recipe_name'];
        $recipe_time=$_POST['recipe_time'];
        $recipe_cal=$_POST['recipe_cal'];
        $recipe_type=$_POST['select_type'];
        $recipe_details=$_POST['recipe_details'];
        $user_email=$_SESSION['User'];
       
        //for pic file
        $file_name=  basename($_FILES['recipe_pic']['name']);
        $tmp=$_FILES['recipe_pic']['tmp_name'];
        $type=$_FILES['recipe_pic']['type'];
        $size=$_FILES['recipe_pic']['size'];
        $error=$_FILES['recipe_pic']["error"];
        
        
        //destination location
        $extension=  explode(".",$file_name );
        $end_ex=end( $extension);
        $dest="img/recipes/recipe-$recipe_type.$end_ex";
        
        //check for issue
        $accept_img=array('png','jpg','jpeg');
          //check if there is no error and the size of img no more 500k and the type is accepted
        if(!$error and $size <= 500000 and in_array($end_ex,$accept_img)){
           
          //move the file to destination for temp loation to pirm location
           $move_file=  move_uploaded_file($tmp,  $dest);//return boolean 
            if($move_file){
               //run query
                $query="INSERT INTO recipe SET email='$user_email', recipe_name='$recipe_name', recipe_pic='$dest',recipe_time='$recipe_time',
                recipe_cal=$recipe_cal ,recipe_type='$recipe_type' ,recipe_details='$recipe_details'";
                
                $result=  mysqli_query($con, $query); 
                 
                if($result){
                     header("location:Profile.php?added=**recipe's information added Successfully**");
                   exit();
                }
                
                else{
                  header("location:Profile.php?notsuccess=**The information is not inserted successfully.Please Try again**");
                exit();  
                }
                }
                
            // else{
             //    $result=0;
            // }
       
                }
       // else { 
         //   $result=0;
            
       // }
        
         
    }//else1    
        
        
    
}//end big if 




?>
