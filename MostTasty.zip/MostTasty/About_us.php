<!Document html>
<html>
 
    <head>
         <link rel="stylesheet" href="About_css.css" type="text/css">
        
    </head>
    
    <header>
       <input type ="text" name="search" placeholder="Search ...">
       <img src="tasty.png" alt="About us" >
       <button type="button"> Sign in/ Sign up</button>   
    </header>
    
    <nav>
      <ul>
        <li> <a href="Home.html"> Home </a></li>
          <li><a href="">Recipes</a></li>
          <li><a href="">About us</a></li> 
      </ul>
    </nav>
    
    
    <body>
        
        <div id="about">
            <h2> About Us</h2>
        </div>
        
        <hr>
        <br><br>
          <div id="column">
            <img src="Sweet.jpg" alt="photo">
          </div>
        
        <div id="column">
        
        <h1> Welcome to our Most Tasty</h1>
        <h3> Here we cook and eat different kind of</h3> <h3>food. We publish delicious kind of food,</h3>
        <h3>including main dishes, drinks, dessert</h3> 
            <h3>and sea food.</h3>
        
        </div>
        
       
    
    </body>
</html>