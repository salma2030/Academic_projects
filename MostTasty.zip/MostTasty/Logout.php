<?php

ob_start();
session_start();


 if(isset($_GET['logout'])){
     
     session_destroy();
     header("location: Home.php");
     
 }
 
?>
